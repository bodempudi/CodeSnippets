
using System;
using System.Data.SqlClient;

class Program
{
    static void Main()
    {
        string sourceConnection = "your_source_connection_string";
        string targetConnection = "your_target_connection_string";

        decimal totalAmount = 0;
        long totalRows = 0;

        using (SqlConnection sourceConn = new SqlConnection(sourceConnection))
        using (SqlConnection targetConn = new SqlConnection(targetConnection))
        {
            sourceConn.Open();
            targetConn.Open();

            SqlCommand cmd = new SqlCommand("SELECT Id, Name, Amount FROM SourceTable WHERE LoadFlag = 'READY'", sourceConn);
            SqlDataReader rawReader = cmd.ExecuteReader();

            using (var reader = new SummingReader(rawReader, "Amount", out Func<decimal> getSum))
            {
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(targetConn))
                {
                    bulkCopy.DestinationTableName = "YourTargetTable";
                    bulkCopy.BatchSize = 10000;
                    bulkCopy.NotifyAfter = 5000;
                    bulkCopy.EnableStreaming = true;

                    bulkCopy.SqlRowsCopied += (s, e) =>
                    {
                        totalRows = e.RowsCopied;
                        Console.WriteLine($"Copied {e.RowsCopied:N0} rows so far...");
                    };

                    bulkCopy.WriteToServer(reader);
                }

                totalAmount = getSum();
            }
        }

        Console.WriteLine($"\n✅ Total Rows Copied: {totalRows:N0}");
        Console.WriteLine($"🧾 Total Amount Copied: {totalAmount:N2}");
    }
}
