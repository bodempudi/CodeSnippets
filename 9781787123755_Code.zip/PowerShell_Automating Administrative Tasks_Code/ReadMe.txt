In Module 1: There is no code files for Chapters 01, 02, 03, 04, 05, and 10. 

In Module 2: There is code files for all the chapters.

In Module 3: All the chapters have script files. Please refer to the software/hardware list for installation steps.