﻿Import-Module C:\Temp\ClassLibrary2\ClassLibrary2\bin\Debug\ClassLibrary2.dll
[ClassLibrary2.Class1]::sum(45,56)