﻿Get-MailboxFolderStatistics -Identity "TargetMailBoxID" | 
Select FolderType , Name , ItemsinFolder