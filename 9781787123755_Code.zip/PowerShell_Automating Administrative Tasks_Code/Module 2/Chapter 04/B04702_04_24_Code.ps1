﻿$json = @"
{
    "Title":  "Mr.",
    "Name":  "Scripting"
}
"@
$json | ConvertFrom-Json
