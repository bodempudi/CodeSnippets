﻿#Windows PowerShell Script to Retrieve Windows Services

Write-Host "Hello, World!" -ForegroundColor Green