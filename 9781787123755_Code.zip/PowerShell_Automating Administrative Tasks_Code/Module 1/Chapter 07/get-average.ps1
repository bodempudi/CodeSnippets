﻿function get-average{
param([int]$a,[int]$b)
   return ($a+$b)/2
}