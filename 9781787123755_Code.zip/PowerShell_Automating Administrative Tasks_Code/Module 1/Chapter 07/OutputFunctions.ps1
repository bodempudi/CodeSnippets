﻿function test-output1{
return 100
}

function test-output2{
100
return
}

function test-output3{
100
}

function test-output4{
Write-Output 100
}