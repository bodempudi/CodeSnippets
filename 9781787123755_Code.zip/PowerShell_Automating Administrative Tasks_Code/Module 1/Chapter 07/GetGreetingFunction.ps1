﻿function get-greeting{
Param($subject='World')
   write-host "Hello $subject"
} 