﻿function get-twovalues{
100
"Hello World"
}
function get-four{
100
"Hello world"
(get-date)
dir c:\temp | select-object -first 1 -Property FullName
}