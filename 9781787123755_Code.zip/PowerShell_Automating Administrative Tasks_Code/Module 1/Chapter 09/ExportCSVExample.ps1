﻿dir c:\temp | select-object -Property Name,Length |
   Export-csv C:\temp\FileList.csv