﻿Param($path)
new-item -ItemType Directory -Name $path
cd $path