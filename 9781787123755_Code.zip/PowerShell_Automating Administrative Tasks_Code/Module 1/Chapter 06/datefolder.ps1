﻿cd (new-item -ItemType Directory -Path c:\temp\$(get-date -format yyyyMMdd) )
