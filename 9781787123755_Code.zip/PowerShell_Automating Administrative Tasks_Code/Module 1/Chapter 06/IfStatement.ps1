﻿Param($number)
if($number -eq 5){
    write-Output 'You guessed the magic number'
}