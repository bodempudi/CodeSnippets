﻿$name='Mike'
write-host "Your name is $name"