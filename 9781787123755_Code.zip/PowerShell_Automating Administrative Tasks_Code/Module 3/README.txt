All the chapters have script files.
*******please refer to the software/hardware list for installation steps*******

