using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting
{
    public static class QueryIndentResolver
    {
        public static int GetQueryBaseIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            if (node == null ||
                layoutContext == null ||
                layoutContext.Walker == null)
            {
                return 0;
            }

            QuerySpecification query =
                FindOwningQuery(
                    node,
                    layoutContext);

            if (query == null)
            {
                /*
                 * DML/statement-owned clauses (for example UPDATE
                 * WHERE) do not have an owning QuerySpecification.
                 * Fall back to the structural statement indentation.
                 */
                return
                    StatementIndentResolver
                        .GetStatementIndent(
                            node,
                            layoutContext);
            }

            /*
             * ======================================================
             * FIRST CHOICE:
             * USE AN ALREADY-ESTABLISHED QUERY INDENT
             * ======================================================
             *
             * SubqueryLayoutPolicy runs on the ScalarSubquery /
             * EXISTS / IN structure before the child
             * QuerySpecification is visited.
             *
             * It already creates:
             *
             *     SELECT token -> correct structural indentation
             *
             * Therefore this becomes the most reliable query base.
             *
             * Examples:
             *
             * EXISTS:
             *
             *     (
             *         select        <- indent 2
             *
             * Query base = 2
             *
             * CASE THEN scalar subquery:
             *
             *         then
             *             (
             *                 select    <- indent 5
             *
             * Query base = 5
             */

            int establishedIndent =
                FindEstablishedQueryIndent(
                    query,
                    layoutContext);

            if (establishedIndent >= 0)
            {
                return establishedIndent;
            }

            /*
             * ======================================================
             * STRUCTURAL STATEMENT INDENT
             * ======================================================
             *
             * A query can be top-level SQL, a statement inside a
             * BEGIN/TRY/IF body, or the source of INSERT ... SELECT.
             * If no subquery policy has already established SELECT's
             * indent, inherit the surrounding statement structure.
             *
             * Top-level SELECT still resolves to 0, while a SELECT
             * inside a procedure/IF/TRY or INSERT source keeps the
             * same base indentation as its owning statement.
             */

            return
                StatementIndentResolver
                    .GetStatementIndent(
                        query,
                        layoutContext);
        }

        /*
         * ==========================================================
         * FIND OWNING QUERY
         * ==========================================================
         */

        private static QuerySpecification FindOwningQuery(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            TSqlFragment current =
                node;

            while (current != null)
            {
                QuerySpecification query =
                    current as QuerySpecification;

                if (query != null)
                {
                    return query;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return null;
        }

        /*
         * ==========================================================
         * FIND ESTABLISHED QUERY INDENT
         * ==========================================================
         */

        private static int FindEstablishedQueryIndent(
            QuerySpecification query,
            LayoutContext layoutContext)
        {
            if (query == null ||
                layoutContext == null ||
                layoutContext.Plan == null)
            {
                return -1;
            }

            /*
             * QuerySpecification.FirstTokenIndex should represent
             * SELECT for our current query forms.
             *
             * Find an instruction already created for that token.
             */

            int queryStartTokenIndex =
                query.FirstTokenIndex;

            foreach (
                LayoutInstruction instruction
                in layoutContext.Plan.Instructions)
            {
                if (instruction.TokenIndex !=
                    queryStartTokenIndex)
                {
                    continue;
                }

                return
                    instruction.IndentLevel;
            }

            return -1;
        }
    }
}