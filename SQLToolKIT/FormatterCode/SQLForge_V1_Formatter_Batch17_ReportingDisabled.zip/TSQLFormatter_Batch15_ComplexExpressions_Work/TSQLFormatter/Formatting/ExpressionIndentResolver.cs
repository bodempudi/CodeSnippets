﻿using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting
{
    public static class ExpressionIndentResolver
    {
        public static int GetExpressionBaseIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            if (node == null ||
                layoutContext == null ||
                layoutContext.Walker == null)
            {
                return 0;
            }

            AstNodeContext context =
                layoutContext.Walker.GetContext(
                    node);

            if (context == null)
            {
                return
                    GetQueryExpressionIndent(
                        node,
                        layoutContext);
            }

            /*
             * ======================================================
             * THEN EXPRESSION
             * ======================================================
             *
             * case
             *     when ...
             *         then
             *         (
             *             ...
             *         )
             *
             * Expression aligns with THEN.
             */

            if (context.Relationship ==
                "ThenExpression")
            {
                int thenIndent =
                    GetWhenKeywordIndent(
                        context.Parent,
                        layoutContext,
                        TSqlTokenType.Then);

                if (thenIndent >= 0)
                {
                    return
                        thenIndent;
                }
            }

            /*
             * ======================================================
             * ELSE EXPRESSION
             * ======================================================
             *
             * case
             *     else
             *     (
             *         ...
             *     )
             *
             * Expression aligns with ELSE.
             */

            if (context.Relationship ==
                "ElseExpression")
            {
                int elseIndent =
                    GetElseKeywordIndent(
                        context.Parent,
                        layoutContext);

                if (elseIndent >= 0)
                {
                    return
                        elseIndent;
                }
            }

            /*
             * ======================================================
             * SELECT ELEMENT
             * ======================================================
             */

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "SelectElements"))
            {
                return
                    QueryIndentResolver
                        .GetQueryBaseIndent(
                            node,
                            layoutContext) +
                    1;
            }

            /*
             * ======================================================
             * GENERAL EXPRESSION
             * ======================================================
             *
             * Start one level inside the owning query.
             *
             * Then inherit every surrounding Boolean
             * parenthesis level.
             *
             * Example:
             *
             * where
             *     A=1
             *     and
             *     (
             *         B=2
             *         or Balance>(
             *             select ...
             *         )
             *     )
             *
             * Query base                = 0
             * Expression base           = 1
             * Boolean parenthesis       = +1
             * Final scalar base         = 2
             */

            return
                GetQueryExpressionIndent(
                    node,
                    layoutContext);
        }

        /*
         * ==========================================================
         * QUERY-RELATIVE EXPRESSION INDENT
         * ==========================================================
         */

        private static int GetQueryExpressionIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            int indent =
                QueryIndentResolver
                    .GetQueryBaseIndent(
                        node,
                        layoutContext) +
                1;

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    node);

            while (current != null)
            {
                if (current is
                    BooleanParenthesisExpression)
                {
                    indent++;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return indent;
        }

        /*
         * ==========================================================
         * WHEN KEYWORD INDENT
         * ==========================================================
         */

        private static int GetWhenKeywordIndent(
            TSqlFragment whenClause,
            LayoutContext layoutContext,
            TSqlTokenType tokenType)
        {
            if (whenClause == null ||
                layoutContext == null ||
                layoutContext.Plan == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            int tokenIndex =
                FindToken(
                    layoutContext,
                    whenClause.FirstTokenIndex,
                    whenClause.LastTokenIndex,
                    tokenType);

            if (tokenIndex < 0)
            {
                return -1;
            }

            return
                GetEstablishedIndent(
                    tokenIndex,
                    layoutContext);
        }

        /*
         * ==========================================================
         * ELSE KEYWORD INDENT
         * ==========================================================
         */

        private static int GetElseKeywordIndent(
            TSqlFragment caseExpression,
            LayoutContext layoutContext)
        {
            if (caseExpression == null ||
                layoutContext == null ||
                layoutContext.Plan == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (!(caseExpression is
                    SearchedCaseExpression) &&
                !(caseExpression is
                    SimpleCaseExpression))
            {
                return -1;
            }

            int elseIndex =
                FindToken(
                    layoutContext,
                    caseExpression.FirstTokenIndex,
                    caseExpression.LastTokenIndex,
                    TSqlTokenType.Else);

            if (elseIndex < 0)
            {
                return -1;
            }

            return
                GetEstablishedIndent(
                    elseIndex,
                    layoutContext);
        }

        /*
         * ==========================================================
         * EXISTING LAYOUT INDENT
         * ==========================================================
         */

        private static int GetEstablishedIndent(
            int tokenIndex,
            LayoutContext layoutContext)
        {
            if (layoutContext == null ||
                layoutContext.Plan == null)
            {
                return -1;
            }

            foreach (
                LayoutInstruction instruction
                in layoutContext.Plan.Instructions)
            {
                if (instruction.TokenIndex ==
                    tokenIndex)
                {
                    return
                        instruction.IndentLevel;
                }
            }

            return -1;
        }

        /*
         * ==========================================================
         * FIND TOKEN
         * ==========================================================
         */

        private static int FindToken(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null ||
                layoutContext.Tokens.Count == 0)
            {
                return -1;
            }

            if (start < 0)
            {
                start =
                    0;
            }

            if (end >=
                layoutContext.Tokens.Count)
            {
                end =
                    layoutContext.Tokens.Count - 1;
            }

            if (start > end)
            {
                return -1;
            }

            for (int i = start;
                 i <= end;
                 i++)
            {
                if (layoutContext
                        .Tokens[i]
                        .TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }
    }
}