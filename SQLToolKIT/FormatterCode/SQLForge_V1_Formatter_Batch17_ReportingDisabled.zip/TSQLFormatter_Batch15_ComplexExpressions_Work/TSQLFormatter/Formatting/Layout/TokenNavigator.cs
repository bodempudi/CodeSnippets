using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections.Generic;

namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class TokenNavigator
    {
        private readonly IList<TSqlParserToken> _tokens;

        public TokenNavigator(IList<TSqlParserToken> tokens)
        {
            if (tokens == null) throw new ArgumentNullException("tokens");
            _tokens = tokens;
        }

        public int FindPreviousToken(int startIndex, TSqlTokenType tokenType)
        {
            for (int i = startIndex - 1; i >= 0; i--)
            {
                TSqlParserToken token = _tokens[i];
                if (token.TokenType == TSqlTokenType.WhiteSpace ||
                    token.TokenType == TSqlTokenType.SingleLineComment ||
                    token.TokenType == TSqlTokenType.MultilineComment)
                    continue;

                return token.TokenType == tokenType ? i : -1;
            }
            return -1;
        }

        public bool HasCommentBetween(
            int startIndex,
            int endIndex)
        {
            if (startIndex < 0)
            {
                startIndex = 0;
            }

            if (endIndex >= _tokens.Count)
            {
                endIndex = _tokens.Count - 1;
            }

            for (int i = startIndex;
                 i <= endIndex;
                 i++)
            {
                if (_tokens[i].TokenType ==
                        TSqlTokenType.SingleLineComment ||
                    _tokens[i].TokenType ==
                        TSqlTokenType.MultilineComment)
                {
                    return true;
                }
            }

            return false;
        }

        public int FindTokenBetween(int start, int end, TSqlTokenType tokenType)
        {
            if (start < 0) start = 0;
            if (end > _tokens.Count) end = _tokens.Count;

            for (int i = start; i < end; i++)
                if (_tokens[i].TokenType == tokenType) return i;

            return -1;
        }

        public int FindBooleanOperatorBetween(int firstEnd, int secondStart)
        {
            for (int i = firstEnd + 1; i < secondStart && i < _tokens.Count; i++)
                if (_tokens[i].TokenType == TSqlTokenType.And ||
                    _tokens[i].TokenType == TSqlTokenType.Or)
                    return i;
            return -1;
        }

        public int FindJoinStart(TSqlFragment join, TSqlFragment secondTable)
        {
            int joinIndex = FindTokenBetween(
                join.FirstTokenIndex,
                secondTable.FirstTokenIndex,
                TSqlTokenType.Join);

            if (joinIndex < 0) return -1;

            for (int i = joinIndex - 1; i >= join.FirstTokenIndex; i--)
            {
                TSqlParserToken token = _tokens[i];
                if (token.TokenType == TSqlTokenType.WhiteSpace) continue;

                if (token.TokenType == TSqlTokenType.Inner ||
                    token.TokenType == TSqlTokenType.Left ||
                    token.TokenType == TSqlTokenType.Right ||
                    token.TokenType == TSqlTokenType.Full)
                    return i;

                break;
            }
            return joinIndex;
        }


        public int FindMeaningfulTokenByTextBetween(
            int start,
            int end,
            params string[] tokenTexts)
        {
            if (tokenTexts == null ||
                tokenTexts.Length == 0)
            {
                return -1;
            }

            if (start < 0) start = 0;
            if (end >= _tokens.Count) end = _tokens.Count - 1;

            for (int i = start; i <= end; i++)
            {
                TSqlParserToken token = _tokens[i];

                if (token.TokenType == TSqlTokenType.WhiteSpace ||
                    token.TokenType == TSqlTokenType.SingleLineComment ||
                    token.TokenType == TSqlTokenType.MultilineComment)
                {
                    continue;
                }

                string text = token.Text ?? string.Empty;

                foreach (string candidate in tokenTexts)
                {
                    if (string.Equals(
                            text,
                            candidate,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return i;
                    }
                }
            }

            return -1;
        }

        public int FindTokenSequenceByTextBetween(
            int start,
            int end,
            params string[] tokenTexts)
        {
            if (tokenTexts == null ||
                tokenTexts.Length == 0)
            {
                return -1;
            }

            if (start < 0) start = 0;
            if (end >= _tokens.Count) end = _tokens.Count - 1;

            for (int i = start; i <= end; i++)
            {
                if (IsTrivia(_tokens[i]))
                {
                    continue;
                }

                int cursor = i;
                bool matched = true;

                for (int part = 0;
                     part < tokenTexts.Length;
                     part++)
                {
                    while (cursor <= end &&
                           IsTrivia(_tokens[cursor]))
                    {
                        cursor++;
                    }

                    if (cursor > end ||
                        !string.Equals(
                            _tokens[cursor].Text ?? string.Empty,
                            tokenTexts[part],
                            StringComparison.OrdinalIgnoreCase))
                    {
                        matched = false;
                        break;
                    }

                    cursor++;
                }

                if (matched)
                {
                    return i;
                }
            }

            return -1;
        }

        private static bool IsTrivia(
            TSqlParserToken token)
        {
            return
                token.TokenType == TSqlTokenType.WhiteSpace ||
                token.TokenType == TSqlTokenType.SingleLineComment ||
                token.TokenType == TSqlTokenType.MultilineComment;
        }

        public int FindLastMeaningfulTokenByTextBetween(
            int start,
            int end,
            params string[] tokenTexts)
        {
            if (tokenTexts == null ||
                tokenTexts.Length == 0)
            {
                return -1;
            }

            if (start < 0) start = 0;
            if (end >= _tokens.Count) end = _tokens.Count - 1;

            for (int i = end; i >= start; i--)
            {
                TSqlParserToken token = _tokens[i];

                if (IsTrivia(token))
                {
                    continue;
                }

                string text = token.Text ?? string.Empty;

                foreach (string candidate in tokenTexts)
                {
                    if (string.Equals(
                            text,
                            candidate,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return i;
                    }
                }
            }

            return -1;
        }

        public int FindNextMeaningfulToken(
            int start,
            int end)
        {
            if (start < 0) start = 0;
            if (end >= _tokens.Count) end = _tokens.Count - 1;

            for (int i = start; i <= end; i++)
            {
                if (!IsTrivia(_tokens[i]))
                {
                    return i;
                }
            }

            return -1;
        }

        public string GetTokenText(int tokenIndex)
        {
            if (tokenIndex < 0 || tokenIndex >= _tokens.Count) return "";
            return _tokens[tokenIndex].Text ?? "";
        }

        public static bool IsIndexedRelationship(string relationship, string propertyName)
        {
            return !string.IsNullOrEmpty(relationship) &&
                   relationship.StartsWith(propertyName + "[", StringComparison.Ordinal);
        }

        public static int GetRelationshipIndex(string relationship)
        {
            if (string.IsNullOrEmpty(relationship)) return -1;
            int start = relationship.IndexOf('[');
            int end = relationship.IndexOf(']');
            if (start < 0 || end <= start) return -1;

            int value;
            return int.TryParse(
                relationship.Substring(start + 1, end - start - 1),
                out value) ? value : -1;
        }
    }
}
