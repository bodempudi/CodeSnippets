namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class LayoutInstruction
    {
        public int TokenIndex { get; set; }

        public int IndentLevel { get; set; }

        public LayoutAction Action { get; set; }

        public string PolicyName { get; set; }

        public string NodeType { get; set; }

        public string ParentType { get; set; }

        public string Relationship { get; set; }
    }
}