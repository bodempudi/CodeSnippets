using Microsoft.SqlServer.TransactSql.ScriptDom;
using NotepadPlusPlusPlugin.Formatting.Diagnostics;
using NotepadPlusPlusPlugin.Formatting.Policies;
using System;
using System.Collections.Generic;

namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class LayoutPolicyEngine
    {
        private readonly GenericAstWalker _walker;
        private readonly LayoutContext _layoutContext;
        private readonly IList<ILayoutPolicy> _policies;

        public LayoutPolicyEngine(
            IList<TSqlParserToken> tokens,
            GenericAstWalker walker,
            LayoutPlan plan,
            FormatterDiagnostics diagnostics)
        {
            if (tokens == null) throw new ArgumentNullException("tokens");
            if (walker == null) throw new ArgumentNullException("walker");
            if (plan == null) throw new ArgumentNullException("plan");
            if (diagnostics == null) throw new ArgumentNullException("diagnostics");

            _walker = walker;
            _layoutContext = new LayoutContext(tokens, walker, plan, diagnostics);

            _policies = new List<ILayoutPolicy>
            {
                new SelectLayoutPolicy(),
                new ClauseLayoutPolicy(),
                new JoinLayoutPolicy(),
                new BooleanLayoutPolicy(),
                new ComplexExpressionLayoutPolicy(),
                new CaseLayoutPolicy(),
                 new SubqueryLayoutPolicy(),
                new SetOperatorLayoutPolicy(),
                new StatementLayoutPolicy(),
                new StatementSpacingPolicy(),
                new CteLayoutPolicy(),
                new BlockLayoutPolicy(),
                new ControlFlowLayoutPolicy(),
                new TryCatchLayoutPolicy(),
                new DmlLayoutPolicy(),
                new DeclarationLayoutPolicy(),
                new DefinitionLayoutPolicy(),
                new TableDefinitionLayoutPolicy(),
                new MergeLayoutPolicy(),
                new OutputLayoutPolicy(),
                new ApplyPivotLayoutPolicy(),
                new WindowLayoutPolicy(),
                new ExecuteLayoutPolicy(),
                new QueryTailLayoutPolicy(),
                new IndexLayoutPolicy(),
                new HintLayoutPolicy(),
                new CursorLayoutPolicy()
            };
        }

        public void Analyze(TSqlFragment root)
        {
            _walker.Walk(root, ApplyPolicies);

            _layoutContext.Diagnostics.Add(
                "AST",
                "Nodes=" + _walker.NodeCount +
                ", MaxDepth=" + _walker.MaxDepth + ".");
        }

        private void ApplyPolicies(AstNodeContext context)
        {
            foreach (ILayoutPolicy policy in _policies)
                policy.Apply(context, _layoutContext);
        }
    }
}
