using Microsoft.SqlServer.TransactSql.ScriptDom;
using NotepadPlusPlusPlugin.Formatting.Parsing;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NotepadPlusPlusPlugin.Formatting.Validation
{
    public sealed class FormatterValidationResult
    {
        public bool TokensPreserved { get; set; }

        public bool OutputParses { get; set; }

        public string Message { get; set; }

        public bool Success
        {
            get
            {
                return
                    TokensPreserved &&
                    OutputParses;
            }
        }
    }

    public sealed class FormatterSafetyValidator
    {
        private readonly SqlParserService _parserService;

        public FormatterSafetyValidator(
            SqlParserService parserService)
        {
            _parserService =
                parserService;
        }

        public FormatterValidationResult Validate(
            IList<TSqlParserToken> originalTokens,
            string outputSql)
        {
            SqlParseResult outputParse =
                _parserService.Parse(
                    outputSql);

            bool outputParses =
                outputParse.Success;

            bool tokensPreserved =
                outputParses &&
                EquivalentMeaningfulTokens(
                    originalTokens,
                    outputParse.Tokens);

            return new FormatterValidationResult
            {
                TokensPreserved =
                    tokensPreserved,

                OutputParses =
                    outputParses,

                Message =
                    tokensPreserved &&
                    outputParses
                        ? "Token preservation and parsing passed (generated section separators excluded)."
                        : "Safety validation failed."
            };
        }

        private static bool EquivalentMeaningfulTokens(
            IList<TSqlParserToken> left,
            IList<TSqlParserToken> right)
        {
            IList<string> leftValues =
                MeaningfulTokenValues(
                    left);

            IList<string> rightValues =
                MeaningfulTokenValues(
                    right);

            return
                leftValues.SequenceEqual(
                    rightValues);
        }

        private static IList<string> MeaningfulTokenValues(
            IList<TSqlParserToken> tokens)
        {
            if (tokens == null)
            {
                return new List<string>();
            }

            return tokens
                .Where(
                    x =>
                        x.TokenType != TSqlTokenType.WhiteSpace &&
                        x.TokenType != TSqlTokenType.EndOfFile &&
                        !IsGeneratedSectionSeparator(x))
                .Select(
                    x =>
                        ((int)x.TokenType).ToString() +
                        "|" +
                        (x.Text ?? string.Empty))
                .ToList();
        }

        private static bool IsGeneratedSectionSeparator(
            TSqlParserToken token)
        {
            if (token == null ||
                token.TokenType != TSqlTokenType.SingleLineComment)
            {
                return false;
            }

            string text =
                (token.Text ?? string.Empty).Trim();

            return
                text.Length == 135 &&
                text.All(
                    x => x == '-');
        }
    }
}
