using Microsoft.SqlServer.TransactSql.ScriptDom;
using NotepadPlusPlusPlugin.Formatting.Diagnostics;
using NotepadPlusPlusPlugin.Formatting.Emission;
using NotepadPlusPlusPlugin.Formatting.Parsing;
using System;
using System.Collections.Generic;

namespace NotepadPlusPlusPlugin.Formatting.Validation
{
    public sealed class FormatterIdempotencyResult
    {
        public bool Passed { get; set; }

        public string SecondPassSql { get; set; }

        public string Message { get; set; }
    }

    public sealed class FormatterIdempotencyValidator
    {
        private readonly SqlParserService _parserService;

        public FormatterIdempotencyValidator(
            SqlParserService parserService)
        {
            if (parserService == null)
            {
                throw new ArgumentNullException("parserService");
            }

            _parserService = parserService;
        }

        public FormatterIdempotencyResult Validate(
            string formattedSql)
        {
            SqlParseResult parseResult =
                _parserService.Parse(
                    formattedSql ?? string.Empty);

            if (!parseResult.Success)
            {
                return new FormatterIdempotencyResult
                {
                    Passed = false,
                    SecondPassSql = formattedSql,
                    Message =
                        "Idempotency check could not parse the first formatted output."
                };
            }

            IList<TSqlParserToken> tokens =
                parseResult.Tokens ??
                new List<TSqlParserToken>();

            LayoutPlan plan =
                new LayoutPlan();

            GenericAstWalker walker =
                new GenericAstWalker();

            FormatterDiagnostics diagnostics =
                new FormatterDiagnostics();

            LayoutPolicyEngine engine =
                new LayoutPolicyEngine(
                    tokens,
                    walker,
                    plan,
                    diagnostics);

            engine.Analyze(
                parseResult.Fragment);

            TokenPreservingEmitter emitter =
                new TokenPreservingEmitter();

            string secondPass =
                emitter.Emit(
                    tokens,
                    plan);

            bool passed =
                string.Equals(
                    formattedSql,
                    secondPass,
                    StringComparison.Ordinal);

            return new FormatterIdempotencyResult
            {
                Passed = passed,
                SecondPassSql = secondPass,
                Message = passed
                    ? "Second formatting pass is identical to the first output."
                    : "Second formatting pass differs from the first output."
            };
        }
    }
}
