﻿using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Resolvers
{
    public static class BooleanExpressionStartResolver
    {
        public static int GetStartTokenIndex(
            BooleanExpression expression,
            LayoutContext layoutContext)
        {
            if (expression == null ||
                layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            BooleanBinaryExpression binary =
                expression as BooleanBinaryExpression;

            if (binary != null &&
                binary.FirstExpression != null)
            {
                return GetStartTokenIndex(
                    binary.FirstExpression,
                    layoutContext);
            }

            BooleanParenthesisExpression parenthesis =
                expression as BooleanParenthesisExpression;

            if (parenthesis != null)
            {
                return parenthesis.FirstTokenIndex;
            }

            ExistsPredicate existsPredicate =
                expression as ExistsPredicate;

            if (existsPredicate != null)
            {
                return FindExistsStartTokenIndex(
                    existsPredicate,
                    layoutContext);
            }

            return expression.FirstTokenIndex;
        }

        private static int FindExistsStartTokenIndex(
            ExistsPredicate existsPredicate,
            LayoutContext layoutContext)
        {
            int existsIndex =
                FindPreviousMeaningfulToken(
                    existsPredicate.FirstTokenIndex,
                    layoutContext);

            if (existsIndex < 0)
            {
                return existsPredicate.FirstTokenIndex;
            }

            if (layoutContext.Tokens[existsIndex].TokenType !=
                TSqlTokenType.Exists)
            {
                return existsPredicate.FirstTokenIndex;
            }

            int previousIndex =
                FindPreviousMeaningfulToken(
                    existsIndex,
                    layoutContext);

            if (previousIndex >= 0 &&
                layoutContext.Tokens[previousIndex].TokenType ==
                    TSqlTokenType.Not)
            {
                return previousIndex;
            }

            return existsIndex;
        }

        private static int FindPreviousMeaningfulToken(
            int tokenIndex,
            LayoutContext layoutContext)
        {
            for (int i = tokenIndex - 1;
                 i >= 0;
                 i--)
            {
                TSqlParserToken token =
                    layoutContext.Tokens[i];

                if (token.TokenType ==
                        TSqlTokenType.WhiteSpace ||
                    token.TokenType ==
                        TSqlTokenType.SingleLineComment ||
                    token.TokenType ==
                        TSqlTokenType.MultilineComment)
                {
                    continue;
                }

                return i;
            }

            return -1;
        }
    }
}