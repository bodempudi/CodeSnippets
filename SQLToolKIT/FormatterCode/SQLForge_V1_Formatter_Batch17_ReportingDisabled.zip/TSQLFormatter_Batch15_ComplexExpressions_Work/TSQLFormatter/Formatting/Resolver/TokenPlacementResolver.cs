﻿using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Resolvers
{
    public static class TokenPlacementResolver
    {
        public static LayoutAction ResolveSubqueryOpening(
            AstNodeContext context)
        {
            if (context == null ||
                context.Parent == null)
            {
                return LayoutAction.NewLine;
            }

            /*
             * ======================================================
             * LEFT SIDE OF COMPARISON
             * ======================================================
             *
             * where (
             *     select ...
             * )>0
             *
             * One space between WHERE and '('.
             */

            if (context.Parent is BooleanComparisonExpression &&
                context.Relationship == "FirstExpression")
            {
                return LayoutAction.Space;
            }

            /*
             * ======================================================
             * RIGHT SIDE OF COMPARISON
             * ======================================================
             *
             * where
             *     c.Balance>(
             *         select ...
             *     )
             *
             * '(' attaches directly to comparison operator.
             */

            if (context.Parent is BooleanComparisonExpression &&
                context.Relationship == "SecondExpression")
            {
                return LayoutAction.Tight;
            }

            /*
             * ======================================================
             * NORMAL MULTILINE SUBQUERY BLOCK
             * ======================================================
             *
             * Examples:
             *
             * then
             * (
             *     select ...
             * )
             *
             * Scalar subquery used as another structural
             * multiline expression.
             */

            return LayoutAction.NewLine;
        }
    }
}