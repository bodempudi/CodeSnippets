using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting
{
    public static class StatementIndentResolver
    {
        public static int GetStatementIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            if (node == null ||
                layoutContext == null ||
                layoutContext.Walker == null)
            {
                return 0;
            }

            int indent = 0;

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    node);

            while (current != null)
            {
                if (current is BeginEndBlockStatement)
                {
                    indent++;
                }

                /*
                 * TRY/CATCH owns a statement-list body even though
                 * it is not represented by BeginEndBlockStatement.
                 */
                if (current is TryCatchStatement)
                {
                    indent++;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return indent;
        }

        public static int GetControlBodyIndent(
            TSqlFragment controlStatement,
            LayoutContext layoutContext)
        {
            return
                GetStatementIndent(
                    controlStatement,
                    layoutContext) +
                1;
        }
    }
}
