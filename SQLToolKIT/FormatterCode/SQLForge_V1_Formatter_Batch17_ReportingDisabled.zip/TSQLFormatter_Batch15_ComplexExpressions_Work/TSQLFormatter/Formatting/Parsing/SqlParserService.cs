using Microsoft.SqlServer.TransactSql.ScriptDom;
using System.Collections.Generic;
using System.IO;

namespace NotepadPlusPlusPlugin.Formatting.Parsing
{
    public sealed class SqlParseResult
    {
        public TSqlFragment Fragment { get; set; }

        public IList<ParseError> Errors { get; set; }

        public IList<TSqlParserToken> Tokens { get; set; }

        public bool Success
        {
            get
            {
                return
                    Fragment != null &&
                    Errors != null &&
                    Errors.Count == 0;
            }
        }
    }

    public sealed class SqlParserService
    {
        public SqlParseResult Parse(
            string sql)
        {
            TSql160Parser parser =
                new TSql160Parser(true);

            IList<ParseError> errors;
            TSqlFragment fragment;

            using (StringReader reader =
                new StringReader(sql ?? string.Empty))
            {
                fragment =
                    parser.Parse(
                        reader,
                        out errors);
            }

            IList<TSqlParserToken> tokens =
                fragment == null ||
                fragment.ScriptTokenStream == null
                    ? new List<TSqlParserToken>()
                    : fragment.ScriptTokenStream;

            return new SqlParseResult
            {
                Fragment = fragment,
                Errors = errors ?? new List<ParseError>(),
                Tokens = tokens
            };
        }
    }
}
