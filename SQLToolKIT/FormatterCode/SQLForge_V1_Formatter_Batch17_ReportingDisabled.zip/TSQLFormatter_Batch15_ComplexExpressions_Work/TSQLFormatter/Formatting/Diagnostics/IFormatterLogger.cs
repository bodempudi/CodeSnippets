﻿namespace NotepadPlusPlusPlugin.Formatting.Diagnostics
{
    public interface IFormatterLogger
    {
        void Write(
            FormatterDiagnostics diagnostics);
    }
}