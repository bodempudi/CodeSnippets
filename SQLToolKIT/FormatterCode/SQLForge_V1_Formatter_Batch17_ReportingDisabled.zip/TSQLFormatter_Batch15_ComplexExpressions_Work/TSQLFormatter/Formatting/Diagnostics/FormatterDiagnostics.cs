using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace NotepadPlusPlusPlugin.Formatting.Diagnostics
{
    public sealed class FormatterDiagnostics
    {
        private readonly Stopwatch _stopwatch;
        private readonly List<FormatterDiagnosticEntry> _entries;

        public FormatterDiagnostics()
        {
            ExecutionId = Guid.NewGuid().ToString("N");
            StartedAt = DateTime.Now;
            _entries = new List<FormatterDiagnosticEntry>();
            _stopwatch = Stopwatch.StartNew();
        }

        public string ExecutionId { get; private set; }
        public DateTime StartedAt { get; private set; }
        public int InputLength { get; set; }
        public int OutputLength { get; set; }
        public int InputTokenCount { get; set; }
        public int OutputTokenCount { get; set; }
        public int LayoutInstructionCount { get; set; }
        public int ParseErrorCount { get; set; }
        public bool TokenPreservationPassed { get; set; }
        public bool OutputParsePassed { get; set; }
        public string ResultStatus { get; set; }

        public long ElapsedMilliseconds
        {
            get { return _stopwatch.ElapsedMilliseconds; }
        }

        public IList<FormatterDiagnosticEntry> Entries
        {
            get { return _entries.AsReadOnly(); }
        }

        public void Add(string stage, string message)
        {
            _entries.Add(new FormatterDiagnosticEntry
            {
                Timestamp = DateTime.Now,
                Stage = stage,
                Message = message
            });
        }

        public void Complete()
        {
            if (_stopwatch.IsRunning) _stopwatch.Stop();
        }
    }
}
