﻿using System;
using System.IO;
using System.Text;

namespace NotepadPlusPlusPlugin.Formatting.Diagnostics
{
    public sealed class FileFormatterLogger :
        IFormatterLogger
    {
        private readonly string _logDirectory;

        public FileFormatterLogger()
        {
            _logDirectory =
                Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.LocalApplicationData),
                    "TSQLFormatter",
                    "Logs");
        }

        public FileFormatterLogger(
            string logDirectory)
        {
            if (string.IsNullOrWhiteSpace(logDirectory))
            {
                throw new ArgumentException(
                    "Log directory is required.",
                    "logDirectory");
            }

            _logDirectory =
                logDirectory;
        }

        public void Write(
            FormatterDiagnostics diagnostics)
        {
            if (diagnostics == null)
            {
                throw new ArgumentNullException(
                    "diagnostics");
            }

            Directory.CreateDirectory(
                _logDirectory);

            string fileName =
                "Formatter_" +
                diagnostics.StartedAt.ToString(
                    "yyyyMMdd_HHmmss_fff") +
                "_" +
                diagnostics.ExecutionId +
                ".log";

            string filePath =
                Path.Combine(
                    _logDirectory,
                    fileName);

            StringBuilder builder =
                new StringBuilder();

            builder.AppendLine(
                "============================================================");

            builder.AppendLine(
                "Execution Id       : " +
                diagnostics.ExecutionId);

            builder.AppendLine(
                "Started            : " +
                diagnostics.StartedAt.ToString(
                    "yyyy-MM-dd HH:mm:ss.fff"));

            builder.AppendLine(
                "Input Length       : " +
                diagnostics.InputLength);

            builder.AppendLine(
                "Output Length      : " +
                diagnostics.OutputLength);

            builder.AppendLine(
                "Input Tokens       : " +
                diagnostics.InputTokenCount);

            builder.AppendLine(
                "Output Tokens      : " +
                diagnostics.OutputTokenCount);

            builder.AppendLine(
                "Layout Instructions: " +
                diagnostics.LayoutInstructionCount);

            builder.AppendLine(
                "Parse Errors       : " +
                diagnostics.ParseErrorCount);

            builder.AppendLine(
                "Tokens Preserved   : " +
                diagnostics.TokenPreservationPassed);

            builder.AppendLine(
                "Output Parses      : " +
                diagnostics.OutputParsePassed);

            builder.AppendLine(
                "Result             : " +
                diagnostics.ResultStatus);

            builder.AppendLine(
                "Elapsed            : " +
                diagnostics.ElapsedMilliseconds +
                " ms");

            builder.AppendLine();

            foreach (
                FormatterDiagnosticEntry entry
                in diagnostics.Entries)
            {
                builder.Append(
                    entry.Timestamp.ToString(
                        "HH:mm:ss.fff"));

                builder.Append(
                    " [");

                builder.Append(
                    entry.Stage);

                builder.Append(
                    "] ");

                builder.AppendLine(
                    entry.Message);
            }

            File.WriteAllText(
                filePath,
                builder.ToString(),
                Encoding.UTF8);
        }
    }
}