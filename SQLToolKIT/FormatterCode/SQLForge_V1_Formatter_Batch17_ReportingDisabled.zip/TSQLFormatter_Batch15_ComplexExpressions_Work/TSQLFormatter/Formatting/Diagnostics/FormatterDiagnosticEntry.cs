using System;

namespace NotepadPlusPlusPlugin.Formatting.Diagnostics
{
    public sealed class FormatterDiagnosticEntry
    {
        public DateTime Timestamp { get; set; }
        public string Stage { get; set; }
        public string Message { get; set; }
    }
}
