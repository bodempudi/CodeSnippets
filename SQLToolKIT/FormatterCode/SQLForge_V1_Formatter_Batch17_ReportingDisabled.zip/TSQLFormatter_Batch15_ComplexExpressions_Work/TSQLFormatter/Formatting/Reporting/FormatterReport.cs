using System;
using System.Collections.Generic;

namespace NotepadPlusPlusPlugin.Formatting.Reporting
{
    public sealed class FormatterReport
    {
        public string ExecutionId { get; set; }

        public DateTime StartedAt { get; set; }

        public long ElapsedMilliseconds { get; set; }

        public string ResultStatus { get; set; }

        public string OriginalSql { get; set; }

        public string FormattedSql { get; set; }

        public int InputLength { get; set; }

        public int OutputLength { get; set; }

        public int InputTokenCount { get; set; }

        public int OutputTokenCount { get; set; }

        public int LayoutInstructionCount { get; set; }

        public int ParseErrorCount { get; set; }

        public bool TokensPreserved { get; set; }

        public bool OutputParses { get; set; }

        public bool ValidationPassed { get; set; }

        public FormatterReportSummary Summary { get; set; }

        public IList<FormatterReportInstruction> Instructions
        {
            get;
            set;
        }

        public IList<FormatterReportDiagnostic> DiagnosticEntries
        {
            get;
            set;
        }
    }

    public sealed class FormatterReportSummary
    {
        public int SelectInstructionCount { get; set; }

        public int ClauseInstructionCount { get; set; }

        public int JoinInstructionCount { get; set; }

        public int BooleanInstructionCount { get; set; }

        public int MaximumIndentLevel { get; set; }
    }

    public sealed class FormatterReportInstruction
    {
        public int Number { get; set; }

        public int TokenIndex { get; set; }

        public string TokenText { get; set; }

        public string Action { get; set; }

        public int IndentLevel { get; set; }

        public string PolicyName { get; set; }

        public string NodeType { get; set; }

        public string ParentType { get; set; }

        public string Relationship { get; set; }

        public string Explanation { get; set; }
    }

    public sealed class FormatterReportDiagnostic
    {
        public DateTime Timestamp { get; set; }

        public string Stage { get; set; }

        public string Message { get; set; }
    }
}