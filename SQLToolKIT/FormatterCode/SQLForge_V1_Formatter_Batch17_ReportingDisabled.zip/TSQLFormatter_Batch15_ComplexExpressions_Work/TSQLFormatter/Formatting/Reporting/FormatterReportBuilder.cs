using Microsoft.SqlServer.TransactSql.ScriptDom;
using NotepadPlusPlusPlugin.Formatting.Diagnostics;
using System;
using System.Collections.Generic;

namespace NotepadPlusPlusPlugin.Formatting.Reporting
{
    public sealed class FormatterReportBuilder
    {
        public FormatterReport Build(
            string originalSql,
            string formattedSql,
            IList<TSqlParserToken> tokens,
            LayoutPlan layoutPlan,
            FormatterDiagnostics diagnostics,
            bool validationPassed)
        {
            if (layoutPlan == null)
            {
                throw new ArgumentNullException(
                    "layoutPlan");
            }

            if (diagnostics == null)
            {
                throw new ArgumentNullException(
                    "diagnostics");
            }

            FormatterReport report =
                new FormatterReport();

            report.ExecutionId =
                diagnostics.ExecutionId;

            report.StartedAt =
                diagnostics.StartedAt;

            report.ElapsedMilliseconds =
                diagnostics.ElapsedMilliseconds;

            report.ResultStatus =
                diagnostics.ResultStatus;

            report.OriginalSql =
                originalSql ?? string.Empty;

            report.FormattedSql =
                formattedSql ?? string.Empty;

            report.InputLength =
                diagnostics.InputLength;

            report.OutputLength =
                diagnostics.OutputLength;

            report.InputTokenCount =
                diagnostics.InputTokenCount;

            report.OutputTokenCount =
                diagnostics.OutputTokenCount;

            report.LayoutInstructionCount =
                diagnostics.LayoutInstructionCount;

            report.ParseErrorCount =
                diagnostics.ParseErrorCount;

            report.TokensPreserved =
                diagnostics.TokenPreservationPassed;

            report.OutputParses =
                diagnostics.OutputParsePassed;

            report.ValidationPassed =
                validationPassed;

            report.Summary =
                BuildSummary(
                    layoutPlan);

            report.Instructions =
                BuildInstructions(
                    tokens,
                    layoutPlan);

            report.DiagnosticEntries =
                BuildDiagnostics(
                    diagnostics);

            return report;
        }

        private static FormatterReportSummary BuildSummary(
            LayoutPlan layoutPlan)
        {
            FormatterReportSummary summary =
                new FormatterReportSummary();

            foreach (
                LayoutInstruction instruction
                in layoutPlan.Instructions)
            {
                string policy =
                    instruction.PolicyName ??
                    string.Empty;

                if (policy ==
                    "SelectLayoutPolicy")
                {
                    summary.SelectInstructionCount++;
                }
                else if (policy ==
                    "ClauseLayoutPolicy")
                {
                    summary.ClauseInstructionCount++;
                }
                else if (policy ==
                    "JoinLayoutPolicy")
                {
                    summary.JoinInstructionCount++;
                }
                else if (policy ==
                    "BooleanLayoutPolicy")
                {
                    summary.BooleanInstructionCount++;
                }

                if (instruction.IndentLevel >
                    summary.MaximumIndentLevel)
                {
                    summary.MaximumIndentLevel =
                        instruction.IndentLevel;
                }
            }

            return summary;
        }

        private static IList<FormatterReportInstruction>
            BuildInstructions(
                IList<TSqlParserToken> tokens,
                LayoutPlan layoutPlan)
        {
            List<FormatterReportInstruction> result =
                new List<FormatterReportInstruction>();

            int number =
                1;

            foreach (
                LayoutInstruction instruction
                in layoutPlan.Instructions)
            {
                string tokenText =
                    GetTokenText(
                        tokens,
                        instruction.TokenIndex);

                result.Add(
                    new FormatterReportInstruction
                    {
                        Number =
                            number,

                        TokenIndex =
                            instruction.TokenIndex,

                        TokenText =
                            tokenText,

                        Action =
                            instruction.Action.ToString(),

                        IndentLevel =
                            instruction.IndentLevel,

                        PolicyName =
                            instruction.PolicyName,

                        NodeType =
                            instruction.NodeType,

                        ParentType =
                            instruction.ParentType,

                        Relationship =
                            instruction.Relationship,

                        Explanation =
                            BuildExplanation(
                                instruction,
                                tokenText)
                    });

                number++;
            }

            return result;
        }

        private static IList<FormatterReportDiagnostic>
            BuildDiagnostics(
                FormatterDiagnostics diagnostics)
        {
            List<FormatterReportDiagnostic> result =
                new List<FormatterReportDiagnostic>();

            foreach (
                FormatterDiagnosticEntry entry
                in diagnostics.Entries)
            {
                result.Add(
                    new FormatterReportDiagnostic
                    {
                        Timestamp =
                            entry.Timestamp,

                        Stage =
                            entry.Stage,

                        Message =
                            entry.Message
                    });
            }

            return result;
        }

        private static string BuildExplanation(
            LayoutInstruction instruction,
            string tokenText)
        {
            string policy =
                instruction.PolicyName ??
                string.Empty;

            if (policy ==
                "SelectLayoutPolicy")
            {
                return
                    "SELECT-list token '" +
                    tokenText +
                    "' was placed on a new line at indentation level " +
                    instruction.IndentLevel +
                    ".";
            }

            if (policy ==
                "ClauseLayoutPolicy")
            {
                return
                    "Clause token '" +
                    tokenText +
                    "' was placed on a new line at indentation level " +
                    instruction.IndentLevel +
                    ".";
            }

            if (policy ==
                "JoinLayoutPolicy")
            {
                return
                    "JOIN structure token '" +
                    tokenText +
                    "' was placed on a new line at indentation level " +
                    instruction.IndentLevel +
                    ".";
            }

            if (policy ==
                "BooleanLayoutPolicy")
            {
                return
                    "Boolean structure token '" +
                    tokenText +
                    "' was positioned according to Boolean nesting at indentation level " +
                    instruction.IndentLevel +
                    ".";
            }

            return
                "Token '" +
                tokenText +
                "' received layout action '" +
                instruction.Action +
                "' at indentation level " +
                instruction.IndentLevel +
                ".";
        }

        private static string GetTokenText(
            IList<TSqlParserToken> tokens,
            int tokenIndex)
        {
            if (tokens == null ||
                tokenIndex < 0 ||
                tokenIndex >= tokens.Count)
            {
                return string.Empty;
            }

            return
                tokens[tokenIndex].Text ??
                string.Empty;
        }
    }
}