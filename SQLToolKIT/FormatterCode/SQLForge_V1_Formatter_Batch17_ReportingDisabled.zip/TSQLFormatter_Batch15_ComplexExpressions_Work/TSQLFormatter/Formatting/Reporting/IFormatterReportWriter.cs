namespace NotepadPlusPlusPlugin.Formatting.Reporting
{
    public interface IFormatterReportWriter
    {
        string Write(
            FormatterReport report);
    }
}
