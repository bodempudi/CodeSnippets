using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace NotepadPlusPlusPlugin.Formatting.Reporting
{
    public sealed class PdfFormatterReportWriter :
        IFormatterReportWriter
    {
        private const double PageWidth = 595.0;
        private const double PageHeight = 842.0;

        private const double MarginLeft = 42.0;
        private const double MarginTop = 44.0;
        private const double MarginBottom = 44.0;

        private readonly string _outputDirectory;

        public PdfFormatterReportWriter()
        {
            _outputDirectory =
                Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.LocalApplicationData),
                    "TSQLFormatter",
                    "Reports");
        }

        public PdfFormatterReportWriter(
            string outputDirectory)
        {
            if (string.IsNullOrWhiteSpace(
                    outputDirectory))
            {
                throw new ArgumentException(
                    "Output directory is required.",
                    "outputDirectory");
            }

            _outputDirectory =
                outputDirectory;
        }

        public string Write(
            FormatterReport report)
        {
            if (report == null)
            {
                throw new ArgumentNullException(
                    "report");
            }

            Directory.CreateDirectory(
                _outputDirectory);

            string fileName =
                "FormatterReport_" +
                report.StartedAt.ToString(
                    "yyyyMMdd_HHmmss") +
                "_" +
                report.ExecutionId +
                ".pdf";

            string filePath =
                Path.Combine(
                    _outputDirectory,
                    fileName);

            IList<PdfPageModel> pages =
                BuildPages(
                    report);

            WritePdf(
                filePath,
                pages);

            return
                filePath;
        }

        /*
         * ==========================================================
         * BUILD REPORT CONTENT
         * ==========================================================
         */

        private static IList<PdfPageModel> BuildPages(
            FormatterReport report)
        {
            PdfDocumentComposer composer =
                new PdfDocumentComposer();

            /*
             * ======================================================
             * TITLE
             * ======================================================
             */

            composer.AddTitle(
                "T-SQL FORMATTING REPORT");

            composer.AddKeyValue(
                "Execution ID",
                report.ExecutionId);

            composer.AddKeyValue(
                "Started",
                report.StartedAt.ToString(
                    "yyyy-MM-dd HH:mm:ss.fff"));

            composer.AddKeyValue(
                "Elapsed",
                report.ElapsedMilliseconds +
                " ms");

            composer.AddKeyValue(
                "Result",
                report.ResultStatus);

            composer.AddBlankLine();

            /*
             * ======================================================
             * 1. EXECUTION SUMMARY
             * ======================================================
             */

            composer.AddHeading(
                "1. Execution Summary");

            composer.AddKeyValue(
                "Input Length",
                report.InputLength.ToString());

            composer.AddKeyValue(
                "Output Length",
                report.OutputLength.ToString());

            composer.AddKeyValue(
                "Input Tokens",
                report.InputTokenCount.ToString());

            composer.AddKeyValue(
                "Output Tokens",
                report.OutputTokenCount.ToString());

            composer.AddKeyValue(
                "Layout Instructions",
                report.LayoutInstructionCount.ToString());

            composer.AddKeyValue(
                "Parse Errors",
                report.ParseErrorCount.ToString());

            composer.AddKeyValue(
                "Tokens Preserved",
                report.TokensPreserved
                    ? "PASS"
                    : "FAIL");

            composer.AddKeyValue(
                "Output Parses",
                report.OutputParses
                    ? "PASS"
                    : "FAIL");

            composer.AddKeyValue(
                "Validation",
                report.ValidationPassed
                    ? "PASS"
                    : "FAIL");

            /*
             * ======================================================
             * 2. FORMATTING SUMMARY
             * ======================================================
             */

            composer.AddHeading(
                "2. Formatting Summary");

            if (report.Summary == null)
            {
                composer.AddParagraph(
                    "Formatting summary information is not available.");
            }
            else
            {
                composer.AddKeyValue(
                    "SELECT Layout Decisions",
                    report.Summary
                        .SelectInstructionCount
                        .ToString());

                composer.AddKeyValue(
                    "Clause Layout Decisions",
                    report.Summary
                        .ClauseInstructionCount
                        .ToString());

                composer.AddKeyValue(
                    "JOIN Layout Decisions",
                    report.Summary
                        .JoinInstructionCount
                        .ToString());

                composer.AddKeyValue(
                    "Boolean Layout Decisions",
                    report.Summary
                        .BooleanInstructionCount
                        .ToString());

                composer.AddKeyValue(
                    "Maximum Indentation Level",
                    report.Summary
                        .MaximumIndentLevel
                        .ToString());

                composer.AddBlankLine();

                composer.AddParagraph(
                    BuildFormattingSummaryText(
                        report));
            }

            /*
             * ======================================================
             * 3. ORIGINAL SQL
             * ======================================================
             */

            composer.AddHeading(
                "3. Original SQL");

            composer.AddCodeBlock(
                report.OriginalSql);

            /*
             * ======================================================
             * 4. FORMATTED SQL
             * ======================================================
             */

            composer.AddHeading(
                "4. Formatted SQL");

            composer.AddCodeBlock(
                report.FormattedSql);

            /*
             * ======================================================
             * 5. FORMATTING DECISIONS
             * ======================================================
             */

            composer.AddHeading(
                "5. Formatting Decisions");

            if (report.Instructions == null ||
                report.Instructions.Count == 0)
            {
                composer.AddParagraph(
                    "No layout instructions were generated. " +
                    "The SQL remained unchanged.");
            }
            else
            {
                foreach (
                    FormatterReportInstruction instruction
                    in report.Instructions)
                {
                    composer.AddParagraph(
                        instruction.Number +
                        ". " +
                        instruction.Explanation);
                }
            }

            /*
             * ======================================================
             * 6. DETAILED LAYOUT INSTRUCTIONS
             * ======================================================
             */

            composer.AddHeading(
                "6. Detailed Layout Instructions");

            if (report.Instructions == null ||
                report.Instructions.Count == 0)
            {
                composer.AddParagraph(
                    "No detailed layout instructions are available.");
            }
            else
            {
                foreach (
                    FormatterReportInstruction instruction
                    in report.Instructions)
                {
                    composer.AddSubHeading(
                        "Instruction #" +
                        instruction.Number);

                    composer.AddKeyValue(
                        "Policy",
                        instruction.PolicyName);

                    composer.AddKeyValue(
                        "Token Index",
                        instruction.TokenIndex.ToString());

                    composer.AddKeyValue(
                        "Token",
                        instruction.TokenText);

                    composer.AddKeyValue(
                        "Action",
                        instruction.Action);

                    composer.AddKeyValue(
                        "Indent",
                        instruction.IndentLevel.ToString());

                    composer.AddKeyValue(
                        "Node",
                        instruction.NodeType);

                    composer.AddKeyValue(
                        "Parent",
                        instruction.ParentType);

                    composer.AddKeyValue(
                        "Relationship",
                        instruction.Relationship);

                    composer.AddParagraph(
                        "Explanation: " +
                        instruction.Explanation);

                    composer.AddBlankLine();
                }
            }

            /*
             * ======================================================
             * 7. SAFETY VALIDATION
             * ======================================================
             */

            composer.AddHeading(
                "7. Safety Validation");

            composer.AddKeyValue(
                "Meaningful Tokens Preserved",
                report.TokensPreserved
                    ? "PASS"
                    : "FAIL");

            composer.AddKeyValue(
                "Formatted SQL Parses",
                report.OutputParses
                    ? "PASS"
                    : "FAIL");

            composer.AddKeyValue(
                "Overall Validation",
                report.ValidationPassed
                    ? "PASS"
                    : "FAIL");

            composer.AddBlankLine();

            if (report.ValidationPassed)
            {
                composer.AddParagraph(
                    "Safety validation passed. " +
                    "The meaningful SQL token sequence was preserved " +
                    "and the formatted output parsed successfully.");
            }
            else
            {
                composer.AddParagraph(
                    "Safety validation failed. " +
                    "The formatted candidate should not replace the " +
                    "developer's original SQL.");
            }

            /*
             * ======================================================
             * 8. EXECUTION TIMELINE
             * ======================================================
             */

            composer.AddHeading(
                "8. Execution Timeline");

            if (report.DiagnosticEntries == null ||
                report.DiagnosticEntries.Count == 0)
            {
                composer.AddParagraph(
                    "No execution timeline entries are available.");
            }
            else
            {
                foreach (
                    FormatterReportDiagnostic entry
                    in report.DiagnosticEntries)
                {
                    composer.AddParagraph(
                        entry.Timestamp.ToString(
                            "HH:mm:ss.fff") +
                        " [" +
                        entry.Stage +
                        "] " +
                        entry.Message);
                }
            }

            /*
             * ======================================================
             * 9. CONCLUSION
             * ======================================================
             */

            composer.AddHeading(
                "9. Conclusion");

            if (report.ValidationPassed)
            {
                composer.AddParagraph(
                    "The formatting operation completed safely. " +
                    "Only layout decisions represented by the layout " +
                    "plan were applied. The report above provides both " +
                    "a high-level formatting summary and the detailed " +
                    "engineering-level decisions used during formatting.");
            }
            else
            {
                composer.AddParagraph(
                    "The formatting operation did not pass safety " +
                    "validation. Review the detailed layout instructions " +
                    "and execution timeline to identify the cause.");
            }

            return
                composer.Pages;
        }

        /*
         * ==========================================================
         * HUMAN READABLE SUMMARY
         * ==========================================================
         */

        private static string BuildFormattingSummaryText(
            FormatterReport report)
        {
            if (report == null ||
                report.Summary == null)
            {
                return
                    string.Empty;
            }

            StringBuilder builder =
                new StringBuilder();

            if (report.Summary.SelectInstructionCount > 0)
            {
                builder.Append(
                    report.Summary.SelectInstructionCount);

                builder.Append(
                    " SELECT-list layout decision(s) were applied. ");
            }

            if (report.Summary.ClauseInstructionCount > 0)
            {
                builder.Append(
                    report.Summary.ClauseInstructionCount);

                builder.Append(
                    " clause layout decision(s) were applied. ");
            }

            if (report.Summary.JoinInstructionCount > 0)
            {
                builder.Append(
                    report.Summary.JoinInstructionCount);

                builder.Append(
                    " JOIN-related layout decision(s) were applied. ");
            }

            if (report.Summary.BooleanInstructionCount > 0)
            {
                builder.Append(
                    report.Summary.BooleanInstructionCount);

                builder.Append(
                    " Boolean layout decision(s) were applied. ");
            }

            builder.Append(
                "The maximum indentation level used by the layout plan was ");

            builder.Append(
                report.Summary.MaximumIndentLevel);

            builder.Append(
                ".");

            return
                builder.ToString();
        }

        /*
         * ==========================================================
         * PDF FILE WRITER
         * ==========================================================
         */

        private static void WritePdf(
            string path,
            IList<PdfPageModel> pages)
        {
            Encoding encoding =
                Encoding.GetEncoding(
                    1252);

            List<byte[]> objects =
                new List<byte[]>();

            int pageCount =
                pages.Count;

            int catalogObject =
                1;

            int pagesObject =
                2;

            int helveticaObject =
                3;

            int courierObject =
                4;

            int firstPageObject =
                5;

            List<int> pageObjects =
                new List<int>();

            List<int> contentObjects =
                new List<int>();

            for (int i = 0;
                 i < pageCount;
                 i++)
            {
                pageObjects.Add(
                    firstPageObject +
                    (i * 2));

                contentObjects.Add(
                    firstPageObject +
                    (i * 2) +
                    1);
            }

            /*
             * Catalog
             */

            objects.Add(
                Encode(
                    encoding,
                    "<< /Type /Catalog /Pages " +
                    pagesObject +
                    " 0 R >>"));

            /*
             * Pages root
             */

            StringBuilder kids =
                new StringBuilder();

            foreach (
                int pageObject
                in pageObjects)
            {
                kids.Append(
                    pageObject);

                kids.Append(
                    " 0 R ");
            }

            objects.Add(
                Encode(
                    encoding,
                    "<< /Type /Pages /Count " +
                    pageCount +
                    " /Kids [ " +
                    kids +
                    "] >>"));

            /*
             * Helvetica
             */

            objects.Add(
                Encode(
                    encoding,
                    "<< /Type /Font " +
                    "/Subtype /Type1 " +
                    "/BaseFont /Helvetica " +
                    "/Encoding /WinAnsiEncoding >>"));

            /*
             * Courier
             */

            objects.Add(
                Encode(
                    encoding,
                    "<< /Type /Font " +
                    "/Subtype /Type1 " +
                    "/BaseFont /Courier " +
                    "/Encoding /WinAnsiEncoding >>"));

            /*
             * Page objects + content streams
             */

            for (int i = 0;
                 i < pageCount;
                 i++)
            {
                int contentObject =
                    contentObjects[i];

                string pageDictionary =
                    "<< /Type /Page" +
                    " /Parent " +
                    pagesObject +
                    " 0 R" +
                    " /MediaBox [0 0 " +
                    PdfNumber(PageWidth) +
                    " " +
                    PdfNumber(PageHeight) +
                    "]" +
                    " /Resources << /Font << /F1 " +
                    helveticaObject +
                    " 0 R /F2 " +
                    courierObject +
                    " 0 R >> >>" +
                    " /Contents " +
                    contentObject +
                    " 0 R >>";

                objects.Add(
                    Encode(
                        encoding,
                        pageDictionary));

                byte[] streamBytes =
                    Encode(
                        encoding,
                        pages[i].Content);

                string streamHeader =
                    "<< /Length " +
                    streamBytes.Length +
                    " >>\nstream\n";

                byte[] headerBytes =
                    Encode(
                        encoding,
                        streamHeader);

                byte[] footerBytes =
                    Encode(
                        encoding,
                        "\nendstream");

                byte[] fullStream =
                    new byte[
                        headerBytes.Length +
                        streamBytes.Length +
                        footerBytes.Length];

                Buffer.BlockCopy(
                    headerBytes,
                    0,
                    fullStream,
                    0,
                    headerBytes.Length);

                Buffer.BlockCopy(
                    streamBytes,
                    0,
                    fullStream,
                    headerBytes.Length,
                    streamBytes.Length);

                Buffer.BlockCopy(
                    footerBytes,
                    0,
                    fullStream,
                    headerBytes.Length +
                    streamBytes.Length,
                    footerBytes.Length);

                objects.Add(
                    fullStream);
            }

            /*
             * Write PDF
             */

            using (
                FileStream stream =
                    new FileStream(
                        path,
                        FileMode.Create,
                        FileAccess.Write,
                        FileShare.Read))
            {
                byte[] header =
                    Encoding.ASCII.GetBytes(
                        "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");

                stream.Write(
                    header,
                    0,
                    header.Length);

                List<long> offsets =
                    new List<long>();

                offsets.Add(
                    0);

                for (int i = 0;
                     i < objects.Count;
                     i++)
                {
                    offsets.Add(
                        stream.Position);

                    byte[] objectHeader =
                        Encoding.ASCII.GetBytes(
                            (i + 1) +
                            " 0 obj\n");

                    stream.Write(
                        objectHeader,
                        0,
                        objectHeader.Length);

                    stream.Write(
                        objects[i],
                        0,
                        objects[i].Length);

                    byte[] objectFooter =
                        Encoding.ASCII.GetBytes(
                            "\nendobj\n");

                    stream.Write(
                        objectFooter,
                        0,
                        objectFooter.Length);
                }

                long xrefOffset =
                    stream.Position;

                StringBuilder xref =
                    new StringBuilder();

                xref.Append(
                    "xref\n");

                xref.Append(
                    "0 " +
                    (objects.Count + 1) +
                    "\n");

                xref.Append(
                    "0000000000 65535 f \n");

                for (int i = 1;
                     i < offsets.Count;
                     i++)
                {
                    xref.Append(
                        offsets[i].ToString(
                            "0000000000",
                            CultureInfo.InvariantCulture));

                    xref.Append(
                        " 00000 n \n");
                }

                xref.Append(
                    "trailer\n");

                xref.Append(
                    "<< /Size " +
                    (objects.Count + 1) +
                    " /Root " +
                    catalogObject +
                    " 0 R >>\n");

                xref.Append(
                    "startxref\n");

                xref.Append(
                    xrefOffset);

                xref.Append(
                    "\n%%EOF");

                byte[] xrefBytes =
                    Encoding.ASCII.GetBytes(
                        xref.ToString());

                stream.Write(
                    xrefBytes,
                    0,
                    xrefBytes.Length);
            }
        }

        private static byte[] Encode(
            Encoding encoding,
            string value)
        {
            return
                encoding.GetBytes(
                    value ?? string.Empty);
        }

        private static string PdfNumber(
            double value)
        {
            return
                value.ToString(
                    "0.###",
                    CultureInfo.InvariantCulture);
        }

        /*
         * ==========================================================
         * DOCUMENT COMPOSER
         * ==========================================================
         */

        private sealed class PdfDocumentComposer
        {
            private const double NormalFontSize = 9.0;
            private const double CodeFontSize = 8.0;
            private const double TitleFontSize = 16.0;
            private const double HeadingFontSize = 12.0;
            private const double SubHeadingFontSize = 10.0;

            private readonly List<PdfPageModel> _pages;

            private PdfPageModel _currentPage;

            private double _y;

            public PdfDocumentComposer()
            {
                _pages =
                    new List<PdfPageModel>();

                StartNewPage();
            }

            public IList<PdfPageModel> Pages
            {
                get
                {
                    return
                        _pages;
                }
            }

            public void AddTitle(
                string text)
            {
                AddWrappedText(
                    text,
                    "F1",
                    TitleFontSize,
                    20.0,
                    0.0,
                    55);

                AddBlankLine();
            }

            public void AddHeading(
                string text)
            {
                EnsureSpace(
                    32.0);

                _y -=
                    5.0;

                AddWrappedText(
                    text,
                    "F1",
                    HeadingFontSize,
                    17.0,
                    0.0,
                    75);
            }

            public void AddSubHeading(
                string text)
            {
                EnsureSpace(
                    24.0);

                AddWrappedText(
                    text,
                    "F1",
                    SubHeadingFontSize,
                    14.0,
                    0.0,
                    80);
            }

            public void AddKeyValue(
                string key,
                string value)
            {
                AddWrappedText(
                    key +
                    ": " +
                    (value ?? string.Empty),
                    "F1",
                    NormalFontSize,
                    12.0,
                    0.0,
                    95);
            }

            public void AddParagraph(
                string text)
            {
                AddWrappedText(
                    text,
                    "F1",
                    NormalFontSize,
                    12.0,
                    0.0,
                    95);
            }

            public void AddBlankLine()
            {
                _y -=
                    8.0;

                if (_y <
                    MarginBottom)
                {
                    StartNewPage();
                }
            }

            /*
             * ======================================================
             * SQL CODE
             * ======================================================
             */

            public void AddCodeBlock(
                string sql)
            {
                EnsureSpace(
                    24.0);

                string normalized =
                    (sql ?? string.Empty)
                        .Replace(
                            "\r\n",
                            "\n")
                        .Replace(
                            "\r",
                            "\n");

                string[] lines =
                    normalized.Split(
                        '\n');

                foreach (
                    string sourceLine
                    in lines)
                {
                    IList<string> wrapped =
                        WrapCodeLine(
                            sourceLine,
                            88);

                    foreach (
                        string line
                        in wrapped)
                    {
                        EnsureSpace(
                            11.0);

                        AddTextLine(
                            line,
                            "F2",
                            CodeFontSize,
                            MarginLeft + 8.0,
                            _y);

                        _y -=
                            10.5;
                    }
                }

                _y -=
                    5.0;
            }

            /*
             * ======================================================
             * WRAPPED NORMAL TEXT
             * ======================================================
             */

            private void AddWrappedText(
                string text,
                string font,
                double fontSize,
                double lineHeight,
                double extraIndent,
                int maxCharacters)
            {
                IList<string> lines =
                    WrapText(
                        text ?? string.Empty,
                        maxCharacters);

                foreach (
                    string line
                    in lines)
                {
                    EnsureSpace(
                        lineHeight);

                    AddTextLine(
                        line,
                        font,
                        fontSize,
                        MarginLeft +
                        extraIndent,
                        _y);

                    _y -=
                        lineHeight;
                }
            }

            /*
             * ======================================================
             * PAGE MANAGEMENT
             * ======================================================
             */

            private void EnsureSpace(
                double required)
            {
                if (_y -
                    required <
                    MarginBottom)
                {
                    StartNewPage();
                }
            }

            private void StartNewPage()
            {
                _currentPage =
                    new PdfPageModel();

                _pages.Add(
                    _currentPage);

                _y =
                    PageHeight -
                    MarginTop;
            }

            /*
             * ======================================================
             * PDF TEXT
             * ======================================================
             */

            private void AddTextLine(
                string text,
                string fontName,
                double fontSize,
                double x,
                double y)
            {
                string safe =
                    EscapePdfText(
                        NormalizeForWinAnsi(
                            text));

                _currentPage.Builder.Append(
                    "BT\n");

                _currentPage.Builder.Append(
                    "/" +
                    fontName +
                    " " +
                    PdfNumber(
                        fontSize) +
                    " Tf\n");

                _currentPage.Builder.Append(
                    "1 0 0 1 " +
                    PdfNumber(
                        x) +
                    " " +
                    PdfNumber(
                        y) +
                    " Tm\n");

                _currentPage.Builder.Append(
                    "(" +
                    safe +
                    ") Tj\n");

                _currentPage.Builder.Append(
                    "ET\n");
            }

            /*
             * ======================================================
             * TEXT WRAPPING
             * ======================================================
             */

            private static IList<string> WrapText(
                string text,
                int maxCharacters)
            {
                List<string> result =
                    new List<string>();

                string[] paragraphs =
                    text
                        .Replace(
                            "\r\n",
                            "\n")
                        .Replace(
                            "\r",
                            "\n")
                        .Split(
                            '\n');

                foreach (
                    string paragraph
                    in paragraphs)
                {
                    string remaining =
                        paragraph.Trim();

                    if (remaining.Length == 0)
                    {
                        result.Add(
                            string.Empty);

                        continue;
                    }

                    while (remaining.Length >
                        maxCharacters)
                    {
                        int split =
                            remaining.LastIndexOf(
                                ' ',
                                maxCharacters);

                        if (split <= 0)
                        {
                            split =
                                maxCharacters;
                        }

                        result.Add(
                            remaining
                                .Substring(
                                    0,
                                    split)
                                .TrimEnd());

                        remaining =
                            remaining
                                .Substring(
                                    split)
                                .TrimStart();
                    }

                    result.Add(
                        remaining);
                }

                return
                    result;
            }

            private static IList<string> WrapCodeLine(
                string line,
                int maxCharacters)
            {
                List<string> result =
                    new List<string>();

                string remaining =
                    line ?? string.Empty;

                if (remaining.Length == 0)
                {
                    result.Add(
                        string.Empty);

                    return
                        result;
                }

                while (remaining.Length >
                    maxCharacters)
                {
                    result.Add(
                        remaining.Substring(
                            0,
                            maxCharacters));

                    remaining =
                        "    " +
                        remaining.Substring(
                            maxCharacters);
                }

                result.Add(
                    remaining);

                return
                    result;
            }

            /*
             * ======================================================
             * PDF ESCAPING
             * ======================================================
             */

            private static string EscapePdfText(
                string value)
            {
                return
                    (value ?? string.Empty)
                        .Replace(
                            "\\",
                            "\\\\")
                        .Replace(
                            "(",
                            "\\(")
                        .Replace(
                            ")",
                            "\\)");
            }

            private static string NormalizeForWinAnsi(
                string value)
            {
                if (string.IsNullOrEmpty(
                        value))
                {
                    return
                        string.Empty;
                }

                StringBuilder result =
                    new StringBuilder();

                foreach (
                    char character
                    in value)
                {
                    if (character == '\t')
                    {
                        result.Append(
                            "    ");

                        continue;
                    }

                    if (character >= 32 &&
                        character <= 255)
                    {
                        result.Append(
                            character);
                    }
                    else
                    {
                        result.Append(
                            '?');
                    }
                }

                return
                    result.ToString();
            }
        }

        /*
         * ==========================================================
         * PAGE MODEL
         * ==========================================================
         */

        private sealed class PdfPageModel
        {
            public PdfPageModel()
            {
                Builder =
                    new StringBuilder();
            }

            public StringBuilder Builder
            {
                get;
                private set;
            }

            public string Content
            {
                get
                {
                    return
                        Builder.ToString();
                }
            }
        }
    }
}