using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class GenericAstWalker
    {
        private readonly Dictionary<TSqlFragment, AstNodeContext>
            _contexts =
                new Dictionary<TSqlFragment, AstNodeContext>(
                    new ReferenceComparer());

        private readonly List<AstNodeContext>
            _orderedContexts =
                new List<AstNodeContext>();

        private readonly HashSet<TSqlFragment>
            _visited =
                new HashSet<TSqlFragment>(
                    new ReferenceComparer());

        public int NodeCount
        {
            get;
            private set;
        }

        public int MaxDepth
        {
            get;
            private set;
        }

        /*
         * ==========================================================
         * TWO-PASS WALK
         * ==========================================================
         *
         * Pass 1 builds the complete structural map first.
         * Pass 2 executes formatting policies.
         *
         * This guarantees that a policy can call GetParent() for
         * any node, including deeply nested nodes that have not yet
         * been visited by the policy pass.
         */

        public void Walk(
            TSqlFragment root,
            Action<AstNodeContext> visitor)
        {
            _contexts.Clear();
            _orderedContexts.Clear();
            _visited.Clear();

            NodeCount =
                0;

            MaxDepth =
                0;

            if (root == null)
            {
                return;
            }

            /*
             * PASS 1: discover all nodes and ancestry.
             */
            Discover(
                root,
                null,
                "Root",
                0);

            /*
             * PASS 2: apply consumers after ancestry is complete.
             */
            if (visitor == null)
            {
                return;
            }

            foreach (
                AstNodeContext context
                in _orderedContexts)
            {
                visitor(
                    context);
            }
        }

        public AstNodeContext GetContext(
            TSqlFragment node)
        {
            if (node == null)
            {
                return null;
            }

            AstNodeContext context;

            if (_contexts.TryGetValue(
                    node,
                    out context))
            {
                return context;
            }

            return null;
        }

        public TSqlFragment GetParent(
            TSqlFragment node)
        {
            AstNodeContext context =
                GetContext(
                    node);

            return context == null
                ? null
                : context.Parent;
        }

        public IList<AstNodeContext> GetChildren(
            TSqlFragment parent)
        {
            List<AstNodeContext> children =
                new List<AstNodeContext>();

            if (parent == null)
            {
                return children;
            }

            foreach (
                AstNodeContext context
                in _orderedContexts)
            {
                if (ReferenceEquals(
                        context.Parent,
                        parent))
                {
                    children.Add(
                        context);
                }
            }

            return children;
        }

        private void Discover(
            TSqlFragment node,
            TSqlFragment parent,
            string relationship,
            int depth)
        {
            if (node == null)
            {
                return;
            }

            if (!_visited.Add(
                    node))
            {
                return;
            }

            AstNodeContext context =
                new AstNodeContext
                {
                    Node =
                        node,

                    Parent =
                        parent,

                    Relationship =
                        relationship ?? string.Empty,

                    Depth =
                        depth
                };

            _contexts[node] =
                context;

            _orderedContexts.Add(
                context);

            NodeCount++;

            if (depth >
                MaxDepth)
            {
                MaxDepth =
                    depth;
            }

            PropertyInfo[] properties =
                node
                    .GetType()
                    .GetProperties(
                        BindingFlags.Instance |
                        BindingFlags.Public);

            foreach (
                PropertyInfo property
                in properties)
            {
                if (!property.CanRead)
                {
                    continue;
                }

                if (property.GetIndexParameters().Length != 0)
                {
                    continue;
                }

                object value;

                try
                {
                    value =
                        property.GetValue(
                            node,
                            null);
                }
                catch
                {
                    continue;
                }

                if (value == null)
                {
                    continue;
                }

                TSqlFragment child =
                    value as TSqlFragment;

                if (child != null)
                {
                    Discover(
                        child,
                        node,
                        property.Name,
                        depth + 1);

                    continue;
                }

                IEnumerable collection =
                    value as IEnumerable;

                if (collection == null ||
                    value is string)
                {
                    continue;
                }

                int index =
                    0;

                foreach (
                    object item
                    in collection)
                {
                    TSqlFragment collectionChild =
                        item as TSqlFragment;

                    if (collectionChild != null)
                    {
                        Discover(
                            collectionChild,
                            node,
                            property.Name +
                            "[" +
                            index +
                            "]",
                            depth + 1);
                    }

                    index++;
                }
            }
        }

        private sealed class ReferenceComparer :
            IEqualityComparer<TSqlFragment>
        {
            public bool Equals(
                TSqlFragment x,
                TSqlFragment y)
            {
                return
                    ReferenceEquals(
                        x,
                        y);
            }

            public int GetHashCode(
                TSqlFragment obj)
            {
                return
                    RuntimeHelpers.GetHashCode(
                        obj);
            }
        }
    }
}
