using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class AstNodeContext
    {
        public TSqlFragment Node { get; set; }
        public TSqlFragment Parent { get; set; }
        public string Relationship { get; set; }
        public int Depth { get; set; }
    }
}
