namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class SqlFormatterOptions
    {
        public SqlFormatterOptions()
        {
            /*
             * Production V1 defaults: no persistent formatter output.
             *
             * Logging and PDF reporting remain available as optional
             * diagnostics and can be explicitly enabled by the host.
             */
            EnableLogFile = false;
            EnablePdfReport = false;
        }

        public bool EnableLogFile
        {
            get;
            set;
        }

        public bool EnablePdfReport
        {
            get;
            set;
        }
    }
}
