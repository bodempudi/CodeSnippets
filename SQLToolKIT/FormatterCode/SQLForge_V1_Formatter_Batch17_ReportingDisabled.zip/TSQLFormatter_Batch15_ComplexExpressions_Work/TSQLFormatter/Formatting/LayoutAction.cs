namespace NotepadPlusPlusPlugin.Formatting
{
    public enum LayoutAction
    {
        NewLine,
        BlankLine,
        SectionSeparator,
        Space,
        Tight
    }
}
