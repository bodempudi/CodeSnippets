using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class CteLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            CommonTableExpression cte =
                context.Node as CommonTableExpression;

            if (cte != null)
            {
                ApplyCte(
                    cte,
                    context,
                    layoutContext);

                return;
            }

            SelectStatement selectStatement =
                context.Node as SelectStatement;

            if (selectStatement != null &&
                selectStatement.WithCtesAndXmlNamespaces != null &&
                selectStatement.QueryExpression != null)
            {
                int statementIndent =
                    StatementIndentResolver
                        .GetStatementIndent(
                            selectStatement,
                            layoutContext);

                /*
                 * A defensive CTE is commonly written as:
                 *
                 *     ;WITH CteName AS
                 *
                 * ScriptDom starts the SelectStatement at WITH and does
                 * not treat the prefix semicolon as part of the statement.
                 * If a statement/spacing policy places a boundary on WITH,
                 * the output can incorrectly become:
                 *
                 *     ;
                 *     WITH
                 *
                 * Keep the semicolon and WITH as one visual start. We do
                 * not add/remove/reorder tokens; only whitespace changes.
                 */
                ApplyCteVisualStart(
                    selectStatement,
                    context,
                    layoutContext,
                    statementIndent);

                /*
                 * Main query following the CTE list.
                 */
                layoutContext.AddInstruction(
                    selectStatement
                        .QueryExpression
                        .FirstTokenIndex,
                    statementIndent,
                    "CteLayoutPolicy",
                    context);
            }
        }

        private static void ApplyCteVisualStart(
            SelectStatement selectStatement,
            AstNodeContext context,
            LayoutContext layoutContext,
            int statementIndent)
        {
            int withIndex =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        selectStatement.FirstTokenIndex,
                        selectStatement
                            .WithCtesAndXmlNamespaces
                            .FirstTokenIndex,
                        "WITH");

            if (withIndex < 0)
            {
                withIndex =
                    selectStatement.FirstTokenIndex;
            }

            int semicolonIndex =
                layoutContext.TokenNavigator
                    .FindPreviousToken(
                        withIndex,
                        TSqlTokenType.Semicolon);

            if (semicolonIndex < 0)
            {
                return;
            }

            LayoutInstruction withInstruction =
                layoutContext.Plan
                    .GetInstruction(
                        withIndex);

            /*
             * Transfer the logical statement boundary from WITH to the
             * prefix semicolon. Preserve BlankLine when already requested.
             */
            if (withInstruction != null &&
                withInstruction.Action ==
                    LayoutAction.BlankLine)
            {
                layoutContext.AddBlankLineInstruction(
                    semicolonIndex,
                    withInstruction.IndentLevel,
                    "CteLayoutPolicy",
                    context);
            }
            else
            {
                int indent =
                    withInstruction == null
                        ? statementIndent
                        : withInstruction.IndentLevel;

                layoutContext.AddInstruction(
                    semicolonIndex,
                    indent,
                    "CteLayoutPolicy",
                    context);
            }

            /*
             * No whitespace is allowed between the prefix semicolon and WITH.
             */
            layoutContext.AddTightInstruction(
                withIndex,
                "CteLayoutPolicy",
                context);
        }

        private static void ApplyCte(
            CommonTableExpression cte,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (cte.QueryExpression == null)
            {
                return;
            }

            int baseIndent =
                GetCteBaseIndent(
                    cte,
                    layoutContext);

            int cteIndex =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (cteIndex > 0)
            {
                int commaIndex =
                    layoutContext.TokenNavigator
                        .FindPreviousToken(
                            cte.FirstTokenIndex,
                            TSqlTokenType.Comma);

                if (commaIndex >= 0)
                {
                    /*
                     * Leading-comma CTE style:
                     *
                     *     )
                     *     ,TransactionData AS
                     */
                    layoutContext.AddInstruction(
                        commaIndex,
                        baseIndent,
                        "CteLayoutPolicy",
                        context);

                    layoutContext.AddTightInstruction(
                        cte.FirstTokenIndex,
                        "CteLayoutPolicy",
                        context);
                }
            }

            int openIndex =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        cte.FirstTokenIndex,
                        cte.QueryExpression.FirstTokenIndex,
                        "(");

            if (openIndex >= 0)
            {
                layoutContext.AddInstruction(
                    openIndex,
                    baseIndent,
                    "CteLayoutPolicy",
                    context);
            }

            layoutContext.AddInstruction(
                cte.QueryExpression.FirstTokenIndex,
                baseIndent + 1,
                "CteLayoutPolicy",
                context);

            int closeIndex =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        cte.QueryExpression.LastTokenIndex + 1,
                        cte.LastTokenIndex,
                        ")");

            if (closeIndex >= 0)
            {
                layoutContext.AddInstruction(
                    closeIndex,
                    baseIndent,
                    "CteLayoutPolicy",
                    context);
            }
        }

        private static int GetCteBaseIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            TSqlFragment current = node;

            while (current != null)
            {
                SelectStatement selectStatement =
                    current as SelectStatement;

                if (selectStatement != null)
                {
                    return
                        StatementIndentResolver
                            .GetStatementIndent(
                                selectStatement,
                                layoutContext);
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return 0;
        }
    }
}
