using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class DmlLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            if (context.Parent is UpdateSpecification &&
                TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "SetClauses"))
            {
                ApplyUpdateSetClause(
                    context,
                    layoutContext);

                return;
            }

            if (context.Parent is InsertSpecification &&
                TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Columns"))
            {
                ApplyInsertColumn(
                    context,
                    layoutContext);

                return;
            }

            ValuesInsertSource valuesSource =
                context.Node as ValuesInsertSource;

            if (valuesSource != null)
            {
                ApplyValuesSource(
                    valuesSource,
                    context,
                    layoutContext);

                return;
            }

            RowValue rowValue =
                context.Node as RowValue;

            if (rowValue != null)
            {
                ApplyRowValue(
                    rowValue,
                    context,
                    layoutContext);

                return;
            }

            if (context.Parent is RowValue &&
                TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "ColumnValues"))
            {
                ApplyRowColumnValue(
                    context,
                    layoutContext);
            }
        }

        private static void ApplyUpdateSetClause(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int statementIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Parent,
                    layoutContext);

            int itemIndent = statementIndent + 1;
            int index = TokenNavigator.GetRelationshipIndex(
                context.Relationship);

            if (index <= 0)
            {
                int setIndex =
                    layoutContext.TokenNavigator.FindMeaningfulTokenByTextBetween(
                        context.Parent.FirstTokenIndex,
                        context.Node.FirstTokenIndex,
                        "SET");

                if (setIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        setIndex,
                        statementIndent,
                        "DmlLayoutPolicy",
                        context);
                }

                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    itemIndent,
                    "DmlLayoutPolicy",
                    context);

                return;
            }

            AddCommaLeadingItem(
                context,
                layoutContext,
                itemIndent);
        }

        private static void ApplyInsertColumn(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            InsertSpecification insert =
                context.Parent as InsertSpecification;

            if (insert == null)
            {
                return;
            }

            int statementIndent =
                StatementIndentResolver.GetStatementIndent(
                    insert,
                    layoutContext);

            int itemIndent = statementIndent + 1;
            int index = TokenNavigator.GetRelationshipIndex(
                context.Relationship);

            if (index <= 0)
            {
                int openIndex =
                    layoutContext.TokenNavigator.FindMeaningfulTokenByTextBetween(
                        insert.FirstTokenIndex,
                        context.Node.FirstTokenIndex,
                        "(");

                if (openIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        openIndex,
                        statementIndent,
                        "DmlLayoutPolicy",
                        context);
                }

                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    itemIndent,
                    "DmlLayoutPolicy",
                    context);
            }
            else
            {
                AddCommaLeadingItem(
                    context,
                    layoutContext,
                    itemIndent);
            }

            if (insert.Columns != null &&
                insert.Columns.Count > 0 &&
                index == insert.Columns.Count - 1)
            {
                int end =
                    insert.InsertSource == null
                        ? insert.LastTokenIndex
                        : insert.InsertSource.FirstTokenIndex;

                int closeIndex =
                    layoutContext.TokenNavigator.FindMeaningfulTokenByTextBetween(
                        context.Node.LastTokenIndex + 1,
                        end,
                        ")");

                if (closeIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        closeIndex,
                        statementIndent,
                        "DmlLayoutPolicy",
                        context);
                }
            }
        }

        private static void ApplyValuesSource(
            ValuesInsertSource valuesSource,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int statementIndent =
                StatementIndentResolver.GetStatementIndent(
                    valuesSource,
                    layoutContext);

            int valuesIndex =
                layoutContext.TokenNavigator.FindMeaningfulTokenByTextBetween(
                    valuesSource.FirstTokenIndex,
                    valuesSource.LastTokenIndex,
                    "VALUES");

            if (valuesIndex < 0)
            {
                valuesIndex = valuesSource.FirstTokenIndex;
            }

            layoutContext.AddInstruction(
                valuesIndex,
                statementIndent,
                "DmlLayoutPolicy",
                context);
        }

        private static void ApplyRowValue(
            RowValue rowValue,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int statementIndent =
                StatementIndentResolver.GetStatementIndent(
                    rowValue,
                    layoutContext);

            int rowIndex =
                TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "RowValues")
                    ? TokenNavigator.GetRelationshipIndex(
                        context.Relationship)
                    : 0;

            if (rowIndex <= 0)
            {
                layoutContext.AddInstruction(
                    rowValue.FirstTokenIndex,
                    statementIndent,
                    "DmlLayoutPolicy",
                    context);
            }
            else
            {
                int commaIndex =
                    layoutContext.TokenNavigator.FindPreviousToken(
                        rowValue.FirstTokenIndex,
                        TSqlTokenType.Comma);

                if (commaIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        commaIndex,
                        statementIndent,
                        "DmlLayoutPolicy",
                        context);
                }
                else
                {
                    layoutContext.AddInstruction(
                        rowValue.FirstTokenIndex,
                        statementIndent,
                        "DmlLayoutPolicy",
                        context);
                }
            }

            layoutContext.AddInstruction(
                rowValue.LastTokenIndex,
                statementIndent,
                "DmlLayoutPolicy",
                context);
        }

        private static void ApplyRowColumnValue(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int statementIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Parent,
                    layoutContext);

            int itemIndent = statementIndent + 1;
            int index = TokenNavigator.GetRelationshipIndex(
                context.Relationship);

            if (index <= 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    itemIndent,
                    "DmlLayoutPolicy",
                    context);

                return;
            }

            AddCommaLeadingItem(
                context,
                layoutContext,
                itemIndent);
        }

        private static void AddCommaLeadingItem(
            AstNodeContext context,
            LayoutContext layoutContext,
            int indent)
        {
            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    indent,
                    "DmlLayoutPolicy",
                    context);

                // Keep the item attached to its leading comma.
                // Without this, an existing newline before the item
                // can survive and leave the comma on a line by itself.
                layoutContext.AddTightInstruction(
                    context.Node.FirstTokenIndex,
                    "DmlLayoutPolicy",
                    context);
            }
        }
    }
}
