using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class ControlFlowLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            IfStatement ifStatement =
                context.Node as IfStatement;

            if (ifStatement != null)
            {
                ApplyIf(
                    ifStatement,
                    context,
                    layoutContext);

                return;
            }

            WhileStatement whileStatement =
                context.Node as WhileStatement;

            if (whileStatement != null)
            {
                ApplyWhile(
                    whileStatement,
                    context,
                    layoutContext);
            }
        }

        private static void ApplyIf(
            IfStatement ifStatement,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int baseIndent =
                StatementIndentResolver
                    .GetStatementIndent(
                        ifStatement,
                        layoutContext);

            if (ifStatement.ThenStatement != null)
            {
                int thenIndent =
                    ifStatement.ThenStatement is BeginEndBlockStatement
                        ? baseIndent
                        : baseIndent + 1;

                layoutContext.AddInstruction(
                    ifStatement
                        .ThenStatement
                        .FirstTokenIndex,
                    thenIndent,
                    "ControlFlowLayoutPolicy",
                    context);
            }

            if (ifStatement.ElseStatement == null)
            {
                return;
            }

            int elseIndex =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        ifStatement
                            .ThenStatement
                            .LastTokenIndex + 1,
                        ifStatement
                            .ElseStatement
                            .FirstTokenIndex,
                        "ELSE");

            if (elseIndex >= 0)
            {
                layoutContext.AddInstruction(
                    elseIndex,
                    baseIndent,
                    "ControlFlowLayoutPolicy",
                    context);
            }

            int elseBodyIndent =
                ifStatement.ElseStatement is BeginEndBlockStatement
                    ? baseIndent
                    : baseIndent + 1;

            layoutContext.AddInstruction(
                ifStatement
                    .ElseStatement
                    .FirstTokenIndex,
                elseBodyIndent,
                "ControlFlowLayoutPolicy",
                context);
        }

        private static void ApplyWhile(
            WhileStatement whileStatement,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (whileStatement.Statement == null)
            {
                return;
            }

            int baseIndent =
                StatementIndentResolver
                    .GetStatementIndent(
                        whileStatement,
                        layoutContext);

            int bodyIndent =
                whileStatement.Statement is BeginEndBlockStatement
                    ? baseIndent
                    : baseIndent + 1;

            layoutContext.AddInstruction(
                whileStatement
                    .Statement
                    .FirstTokenIndex,
                bodyIndent,
                "ControlFlowLayoutPolicy",
                context);
        }
    }
}
