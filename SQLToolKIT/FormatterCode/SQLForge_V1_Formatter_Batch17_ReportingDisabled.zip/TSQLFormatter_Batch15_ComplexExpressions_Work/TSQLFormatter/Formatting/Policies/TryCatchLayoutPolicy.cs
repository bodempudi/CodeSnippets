using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class TryCatchLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            TryCatchStatement tryCatch =
                context.Node as TryCatchStatement;

            if (tryCatch == null)
            {
                return;
            }

            int baseIndent =
                StatementIndentResolver
                    .GetStatementIndent(
                        tryCatch,
                        layoutContext);

            ApplyBoundary(
                tryCatch,
                context,
                layoutContext,
                baseIndent,
                "BEGIN TRY");

            ApplyBoundary(
                tryCatch,
                context,
                layoutContext,
                baseIndent,
                "END TRY");

            ApplyBoundary(
                tryCatch,
                context,
                layoutContext,
                baseIndent,
                "BEGIN CATCH");

            ApplyEndCatchBoundary(
                tryCatch,
                context,
                layoutContext,
                baseIndent);
        }

        private static void ApplyBoundary(
            TryCatchStatement tryCatch,
            AstNodeContext context,
            LayoutContext layoutContext,
            int indent,
            string boundaryText)
        {
            int tokenIndex =
                layoutContext.TokenNavigator
                    .FindTokenSequenceByTextBetween(
                        tryCatch.FirstTokenIndex,
                        tryCatch.LastTokenIndex,
                        boundaryText.Split(' '));

            if (tokenIndex < 0)
            {
                return;
            }

            layoutContext.AddInstruction(
                tokenIndex,
                indent,
                "TryCatchLayoutPolicy",
                context);
        }

        private static void ApplyEndCatchBoundary(
            TryCatchStatement tryCatch,
            AstNodeContext context,
            LayoutContext layoutContext,
            int indent)
        {
            int endCatchIndex =
                layoutContext.TokenNavigator
                    .FindTokenSequenceByTextBetween(
                        tryCatch.FirstTokenIndex,
                        tryCatch.LastTokenIndex,
                        "END",
                        "CATCH");

            if (endCatchIndex < 0)
            {
                return;
            }

            if (CatchEndsWithThrow(
                    tryCatch,
                    endCatchIndex,
                    layoutContext))
            {
                layoutContext.AddBlankLineInstruction(
                    endCatchIndex,
                    indent,
                    "TryCatchLayoutPolicy",
                    context);

                return;
            }

            layoutContext.AddInstruction(
                endCatchIndex,
                indent,
                "TryCatchLayoutPolicy",
                context);
        }

        /*
         * Keep this token based so it works across ScriptDom versions
         * without depending on a specific CatchStatements property shape.
         *
         * We inspect only the last statement-sized token region immediately
         * before END CATCH. A bare THROW; (our common production pattern)
         * therefore receives one blank line before END CATCH.
         */
        private static bool CatchEndsWithThrow(
            TryCatchStatement tryCatch,
            int endCatchIndex,
            LayoutContext layoutContext)
        {
            int lastMeaningful =
                FindPreviousMeaningfulToken(
                    endCatchIndex - 1,
                    tryCatch.FirstTokenIndex,
                    layoutContext);

            if (lastMeaningful < 0)
            {
                return false;
            }

            /*
             * Skip the terminator after THROW.
             */
            if (string.Equals(
                    layoutContext.TokenNavigator
                        .GetTokenText(lastMeaningful),
                    ";",
                    StringComparison.Ordinal))
            {
                lastMeaningful =
                    FindPreviousMeaningfulToken(
                        lastMeaningful - 1,
                        tryCatch.FirstTokenIndex,
                        layoutContext);
            }

            if (lastMeaningful < 0)
            {
                return false;
            }

            return
                string.Equals(
                    layoutContext.TokenNavigator
                        .GetTokenText(lastMeaningful),
                    "THROW",
                    StringComparison.OrdinalIgnoreCase);
        }

        private static int FindPreviousMeaningfulToken(
            int start,
            int minimum,
            LayoutContext layoutContext)
        {
            if (start >= layoutContext.Tokens.Count)
            {
                start =
                    layoutContext.Tokens.Count - 1;
            }

            for (int i = start;
                 i >= minimum;
                 i--)
            {
                TSqlParserToken token =
                    layoutContext.Tokens[i];

                if (token.TokenType ==
                        TSqlTokenType.WhiteSpace ||
                    token.TokenType ==
                        TSqlTokenType.SingleLineComment ||
                    token.TokenType ==
                        TSqlTokenType.MultilineComment)
                {
                    continue;
                }

                return i;
            }

            return -1;
        }
    }
}
