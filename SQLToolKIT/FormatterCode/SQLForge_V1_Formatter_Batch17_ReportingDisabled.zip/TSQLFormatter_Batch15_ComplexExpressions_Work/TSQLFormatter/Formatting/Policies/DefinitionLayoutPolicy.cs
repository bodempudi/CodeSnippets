using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections.Generic;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class DefinitionLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            if (!IsDefinitionStatement(context.Node))
            {
                return;
            }

            int baseIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Node,
                    layoutContext);

            int asIndex =
                layoutContext.TokenNavigator.FindMeaningfulTokenByTextBetween(
                    context.Node.FirstTokenIndex,
                    context.Node.LastTokenIndex,
                    "AS");

            if (asIndex >= 0)
            {
                layoutContext.AddInstruction(
                    asIndex,
                    baseIndent,
                    "DefinitionLayoutPolicy",
                    context);
            }

            ApplyBodyBoundary(
                context,
                layoutContext,
                asIndex,
                baseIndent);
        }

        private static bool IsDefinitionStatement(
            TSqlFragment node)
        {
            string name = node.GetType().Name;

            bool createOrAlter =
                name.StartsWith("Create", StringComparison.Ordinal) ||
                name.StartsWith("Alter", StringComparison.Ordinal);

            if (!createOrAlter)
            {
                return false;
            }

            return
                name.IndexOf("Procedure", StringComparison.OrdinalIgnoreCase) >= 0 ||
                name.IndexOf("Function", StringComparison.OrdinalIgnoreCase) >= 0 ||
                name.IndexOf("View", StringComparison.OrdinalIgnoreCase) >= 0 ||
                name.IndexOf("Trigger", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void ApplyBodyBoundary(
            AstNodeContext context,
            LayoutContext layoutContext,
            int asIndex,
            int baseIndent)
        {
            IList<AstNodeContext> children =
                layoutContext.Walker.GetChildren(
                    context.Node);

            AstNodeContext firstBodyChild = null;

            foreach (AstNodeContext child in children)
            {
                if (child == null ||
                    child.Node == null)
                {
                    continue;
                }

                if (asIndex >= 0 &&
                    child.Node.FirstTokenIndex <= asIndex)
                {
                    continue;
                }

                string relationship =
                    child.Relationship ?? string.Empty;

                string typeName =
                    child.Node.GetType().Name;

                if (relationship == "StatementList" ||
                    relationship == "SelectStatement" ||
                    relationship == "QueryExpression" ||
                    typeName == "StatementList" ||
                    typeName.EndsWith("Statement", StringComparison.Ordinal))
                {
                    if (firstBodyChild == null ||
                        child.Node.FirstTokenIndex <
                            firstBodyChild.Node.FirstTokenIndex)
                    {
                        firstBodyChild = child;
                    }
                }
            }

            if (firstBodyChild == null)
            {
                return;
            }

            if (firstBodyChild.Node is StatementList)
            {
                IList<AstNodeContext> statements =
                    layoutContext.Walker.GetChildren(
                        firstBodyChild.Node);

                foreach (AstNodeContext statement in statements)
                {
                    if (statement != null &&
                        statement.Node != null &&
                        TokenNavigator.IsIndexedRelationship(
                            statement.Relationship,
                            "Statements"))
                    {
                        layoutContext.AddInstruction(
                            statement.Node.FirstTokenIndex,
                            baseIndent,
                            "DefinitionLayoutPolicy",
                            statement);

                        break;
                    }
                }

                return;
            }

            layoutContext.AddInstruction(
                firstBodyChild.Node.FirstTokenIndex,
                baseIndent,
                "DefinitionLayoutPolicy",
                firstBodyChild);
        }
    }
}
