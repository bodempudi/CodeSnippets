using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class CaseLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            SearchedCaseExpression searchedCase =
                context.Node as SearchedCaseExpression;

            if (searchedCase != null)
            {
                ApplySearchedCase(
                    searchedCase,
                    context,
                    layoutContext);

                return;
            }

            SimpleCaseExpression simpleCase =
                context.Node as SimpleCaseExpression;

            if (simpleCase != null)
            {
                ApplySimpleCase(
                    simpleCase,
                    context,
                    layoutContext);
            }
        }

        /*
         * ==========================================================
         * SEARCHED CASE
         * ==========================================================
         *
         * case
         *     when X=1
         *         then ...
         *     else ...
         * end
         */

        private static void ApplySearchedCase(
            SearchedCaseExpression caseExpression,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int caseIndent =
                GetCaseIndent(
                    caseExpression,
                    layoutContext);

            /*
             * CASE itself.
             *
             * Important for nested CASE.
             *
             * Top-level CASE may already receive an
             * instruction from SELECT formatting.
             * LayoutPlan should resolve duplicate
             * instructions for the same token.
             */

            layoutContext.AddInstruction(
                caseExpression.FirstTokenIndex,
                caseIndent,
                "CaseLayoutPolicy",
                context);

            /*
             * WHEN / THEN
             */

            foreach (
                SearchedWhenClause whenClause
                in caseExpression.WhenClauses)
            {
                AddWhenThen(
                    whenClause,
                    caseIndent,
                    context,
                    layoutContext);
            }

            /*
             * ELSE
             */

            AddElse(
                caseExpression.ElseExpression,
                caseIndent,
                context,
                layoutContext);

            /*
             * END
             */

            AddEnd(
                caseExpression,
                caseIndent,
                context,
                layoutContext);
        }

        /*
         * ==========================================================
         * SIMPLE CASE
         * ==========================================================
         *
         * case Status
         *     when 1
         *         then ...
         *     when 2
         *         then ...
         *     else ...
         * end
         */

        private static void ApplySimpleCase(
            SimpleCaseExpression caseExpression,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int caseIndent =
                GetCaseIndent(
                    caseExpression,
                    layoutContext);

            layoutContext.AddInstruction(
                caseExpression.FirstTokenIndex,
                caseIndent,
                "CaseLayoutPolicy",
                context);

            foreach (
                SimpleWhenClause whenClause
                in caseExpression.WhenClauses)
            {
                AddWhenThen(
                    whenClause,
                    caseIndent,
                    context,
                    layoutContext);
            }

            AddElse(
                caseExpression.ElseExpression,
                caseIndent,
                context,
                layoutContext);

            AddEnd(
                caseExpression,
                caseIndent,
                context,
                layoutContext);
        }

        /*
         * ==========================================================
         * SEARCHED WHEN
         * ==========================================================
         */

        private static void AddWhenThen(
            SearchedWhenClause whenClause,
            int caseIndent,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (whenClause == null)
            {
                return;
            }

            /*
             * WHEN = CASE + 1
             */

            layoutContext.AddInstruction(
                whenClause.FirstTokenIndex,
                caseIndent + 1,
                "CaseLayoutPolicy",
                context);

            /*
             * THEN = CASE + 2
             */

            int thenIndex =
                FindTokenBetween(
                    layoutContext,
                    whenClause.FirstTokenIndex,
                    whenClause.LastTokenIndex,
                    TSqlTokenType.Then);

            if (thenIndex >= 0)
            {
                layoutContext.AddInstruction(
                    thenIndex,
                    caseIndent + 2,
                    "CaseLayoutPolicy",
                    context);
            }
        }

        /*
         * ==========================================================
         * SIMPLE WHEN
         * ==========================================================
         */

        private static void AddWhenThen(
            SimpleWhenClause whenClause,
            int caseIndent,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (whenClause == null)
            {
                return;
            }

            layoutContext.AddInstruction(
                whenClause.FirstTokenIndex,
                caseIndent + 1,
                "CaseLayoutPolicy",
                context);

            int thenIndex =
                FindTokenBetween(
                    layoutContext,
                    whenClause.FirstTokenIndex,
                    whenClause.LastTokenIndex,
                    TSqlTokenType.Then);

            if (thenIndex >= 0)
            {
                layoutContext.AddInstruction(
                    thenIndex,
                    caseIndent + 2,
                    "CaseLayoutPolicy",
                    context);
            }
        }

        /*
         * ==========================================================
         * ELSE
         * ==========================================================
         */

        private static void AddElse(
            ScalarExpression elseExpression,
            int caseIndent,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (elseExpression == null)
            {
                return;
            }

            int elseIndex =
                FindPreviousToken(
                    layoutContext,
                    elseExpression.FirstTokenIndex,
                    TSqlTokenType.Else);

            if (elseIndex < 0)
            {
                return;
            }

            /*
             * ELSE = CASE + 1
             */

            layoutContext.AddInstruction(
                elseIndex,
                caseIndent + 1,
                "CaseLayoutPolicy",
                context);
        }

        /*
         * ==========================================================
         * END
         * ==========================================================
         */

        private static void AddEnd(
            TSqlFragment caseExpression,
            int caseIndent,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int endIndex =
                FindLastToken(
                    layoutContext,
                    caseExpression.FirstTokenIndex,
                    caseExpression.LastTokenIndex,
                    TSqlTokenType.End);

            if (endIndex < 0)
            {
                return;
            }

            /*
             * END aligns with CASE.
             */

            layoutContext.AddInstruction(
                endIndex,
                caseIndent,
                "CaseLayoutPolicy",
                context);
        }

        /*
         * ==========================================================
         * CASE BASE INDENT
         * ==========================================================
         */

        private static int GetCaseIndent(
            TSqlFragment caseExpression,
            LayoutContext layoutContext)
        {
            if (caseExpression == null ||
                layoutContext == null ||
                layoutContext.Walker == null)
            {
                return 0;
            }

            AstNodeContext context =
                layoutContext.Walker.GetContext(
                    caseExpression);

            /*
             * UPDATE SET assignment values are continuation expressions.
             *
             *     SET
             *         ColumnName=
             *             CASE
             *                 WHEN ...
             *             END
             *
             * The assignment item itself is statement-indent + 1, so the
             * CASE expression starts one additional level inside it.
             */
            if (context != null &&
                context.Parent is AssignmentSetClause &&
                context.Relationship == "NewValue")
            {
                return
                    StatementIndentResolver
                        .GetStatementIndent(
                            context.Parent,
                            layoutContext) +
                    2;
            }

            /*
             * CASE used as a function argument is a nested expression.
             *
             *     ,Amount=SUM
             *     (
             *         CASE
             *             ...
             *         END
             *     )
             */
            if (context != null &&
                context.Parent is FunctionCall)
            {
                return
                    ExpressionIndentResolver
                        .GetExpressionBaseIndent(
                            context.Parent,
                            layoutContext) +
                    1;
            }

            /*
             * For SELECT expressions, SET variable expressions, nested
             * CASE expressions and other scalar contexts, continue using
             * the generic expression resolver.
             */
            return
                ExpressionIndentResolver
                    .GetExpressionBaseIndent(
                        caseExpression,
                        layoutContext);
        }

        private static bool IsCaseExpression(
            TSqlFragment fragment)
        {
            return
                fragment is SearchedCaseExpression ||
                fragment is SimpleCaseExpression;
        }

        /*
         * ==========================================================
         * TOKEN HELPERS
         * ==========================================================
         */

        private static int FindTokenBetween(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (start < 0)
            {
                start =
                    0;
            }

            if (end >=
                layoutContext.Tokens.Count)
            {
                end =
                    layoutContext.Tokens.Count - 1;
            }

            for (int i = start;
                 i <= end;
                 i++)
            {
                if (layoutContext
                        .Tokens[i]
                        .TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }

        private static int FindPreviousToken(
            LayoutContext layoutContext,
            int startIndex,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            int start =
                startIndex - 1;

            if (start >=
                layoutContext.Tokens.Count)
            {
                start =
                    layoutContext.Tokens.Count - 1;
            }

            for (int i = start;
                 i >= 0;
                 i--)
            {
                TSqlParserToken token =
                    layoutContext.Tokens[i];

                if (token.TokenType ==
                    tokenType)
                {
                    return i;
                }

                /*
                 * Skip trivia.
                 */

                if (token.TokenType ==
                        TSqlTokenType.WhiteSpace ||
                    token.TokenType ==
                        TSqlTokenType.SingleLineComment ||
                    token.TokenType ==
                        TSqlTokenType.MultilineComment)
                {
                    continue;
                }

                /*
                 * Once another meaningful token is
                 * encountered, ELSE was not immediately
                 * before the expression.
                 */

                break;
            }

            return -1;
        }

        private static int FindLastToken(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (start < 0)
            {
                start =
                    0;
            }

            if (end >=
                layoutContext.Tokens.Count)
            {
                end =
                    layoutContext.Tokens.Count - 1;
            }

            for (int i = end;
                 i >= start;
                 i--)
            {
                if (layoutContext
                        .Tokens[i]
                        .TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }
    }
}