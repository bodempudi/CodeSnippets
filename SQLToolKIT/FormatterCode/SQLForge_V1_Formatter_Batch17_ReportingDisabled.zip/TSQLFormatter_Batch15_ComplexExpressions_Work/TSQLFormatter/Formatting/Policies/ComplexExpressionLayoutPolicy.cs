using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    /*
     * Formats only function calls that are genuinely multiline complex
     * expressions. Ordinary calls such as COUNT(*), ISNULL(x,0), GETDATE()
     * are deliberately left alone.
     */
    public sealed class ComplexExpressionLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            FunctionCall functionCall =
                context.Node as FunctionCall;

            if (functionCall == null ||
                !ContainsCaseArgument(functionCall))
            {
                return;
            }

            int functionIndent =
                ExpressionIndentResolver
                    .GetExpressionBaseIndent(
                        functionCall,
                        layoutContext) +
                1;

            /*
             * Example target:
             *
             *     ,SuccessfulAmount=
             *         SUM
             *         (
             *             CASE
             *                 ...
             *             END
             *         )
             */
            layoutContext.AddInstruction(
                functionCall.FirstTokenIndex,
                functionIndent,
                "ComplexExpressionLayoutPolicy",
                context);

            int leftParenthesisIndex =
                FindToken(
                    layoutContext,
                    functionCall.FirstTokenIndex,
                    functionCall.LastTokenIndex,
                    TSqlTokenType.LeftParenthesis);

            if (leftParenthesisIndex >= 0)
            {
                layoutContext.AddInstruction(
                    leftParenthesisIndex,
                    functionIndent,
                    "ComplexExpressionLayoutPolicy",
                    context);
            }

            int rightParenthesisIndex =
                FindLastToken(
                    layoutContext,
                    functionCall.FirstTokenIndex,
                    functionCall.LastTokenIndex,
                    TSqlTokenType.RightParenthesis);

            if (rightParenthesisIndex >= 0)
            {
                layoutContext.AddInstruction(
                    rightParenthesisIndex,
                    functionIndent,
                    "ComplexExpressionLayoutPolicy",
                    context);
            }
        }

        private static bool ContainsCaseArgument(
            FunctionCall functionCall)
        {
            if (functionCall == null ||
                functionCall.Parameters == null)
            {
                return false;
            }

            foreach (
                ScalarExpression parameter
                in functionCall.Parameters)
            {
                if (parameter is SearchedCaseExpression ||
                    parameter is SimpleCaseExpression)
                {
                    return true;
                }
            }

            return false;
        }

        private static int FindToken(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (start < 0)
            {
                start = 0;
            }

            if (end >= layoutContext.Tokens.Count)
            {
                end = layoutContext.Tokens.Count - 1;
            }

            for (int i = start; i <= end; i++)
            {
                if (layoutContext.Tokens[i].TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }

        private static int FindLastToken(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (start < 0)
            {
                start = 0;
            }

            if (end >= layoutContext.Tokens.Count)
            {
                end = layoutContext.Tokens.Count - 1;
            }

            for (int i = end; i >= start; i--)
            {
                if (layoutContext.Tokens[i].TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }
    }
}
