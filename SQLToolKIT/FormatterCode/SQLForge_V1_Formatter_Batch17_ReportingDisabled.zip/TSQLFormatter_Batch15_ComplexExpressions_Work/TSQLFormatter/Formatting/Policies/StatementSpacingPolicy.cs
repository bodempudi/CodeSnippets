using Microsoft.SqlServer.TransactSql.ScriptDom;
using System.Linq;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    /*
     * Adds generated 135-hyphen separators around structural statement
     * groups inside a StatementList.
     *
     * IMPORTANT:
     *
     * This policy does NOT derive business meaning. It only uses ScriptDom
     * statement types and deterministic statement-family transitions.
     *
     * A separator is a shared boundary:
     *
     *     separator
     *     GROUP A
     *     separator   <- end A + start B
     *     GROUP B
     *     separator
     *
     * Consecutive statements in the same family stay together.
     */
    public sealed class StatementSpacingPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                context.Parent == null ||
                layoutContext == null)
            {
                return;
            }

            if (!(context.Parent is StatementList) ||
                !TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Statements"))
            {
                return;
            }

            int statementIndex =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (statementIndex < 0)
            {
                return;
            }

            StatementFamily currentFamily =
                GetFamily(
                    context.Node);

            if (currentFamily == StatementFamily.Unknown)
            {
                return;
            }

            int indent =
                StatementIndentResolver
                    .GetStatementIndent(
                        context.Node,
                        layoutContext);

            /*
             * First known statement in this StatementList starts a
             * structural section.
             */
            AstNodeContext previousKnown =
                GetPreviousKnownStatementSibling(
                    context.Parent,
                    statementIndex,
                    layoutContext);

            if (previousKnown == null)
            {
                layoutContext.AddSectionSeparatorInstruction(
                    context.Node.FirstTokenIndex,
                    indent,
                    "StatementSpacingPolicy.Start",
                    context);
            }
            else
            {
                StatementFamily previousFamily =
                    GetFamily(
                        previousKnown.Node);

                if (ShouldSeparate(
                        previousFamily,
                        currentFamily))
                {
                    layoutContext.AddSectionSeparatorInstruction(
                        context.Node.FirstTokenIndex,
                        indent,
                        "StatementSpacingPolicy.Boundary",
                        context);
                }
            }

            /*
             * If no later known statement exists, this statement closes
             * the final structural section in this StatementList.
             *
             * The instruction is placed before the next meaningful token
             * (normally END, ELSE, or EOF), so the separator is aligned to
             * the statement-list indentation rather than to the outer token.
             */
            AstNodeContext nextKnown =
                GetNextKnownStatementSibling(
                    context.Parent,
                    statementIndex,
                    layoutContext);

            if (nextKnown == null)
            {
                int nextToken =
                    layoutContext.TokenNavigator
                        .FindNextMeaningfulToken(
                            context.Node.LastTokenIndex + 1,
                            layoutContext.Tokens.Count - 1);

                if (nextToken >= 0)
                {
                    layoutContext.AddSectionSeparatorInstruction(
                        nextToken,
                        indent,
                        "StatementSpacingPolicy.End",
                        context);
                }
            }
        }

        private static AstNodeContext GetPreviousKnownStatementSibling(
            TSqlFragment statementList,
            int statementIndex,
            LayoutContext layoutContext)
        {
            for (int index = statementIndex - 1;
                 index >= 0;
                 index--)
            {
                AstNodeContext sibling =
                    GetStatementSibling(
                        statementList,
                        index,
                        layoutContext);

                if (sibling != null &&
                    sibling.Node != null &&
                    GetFamily(sibling.Node) != StatementFamily.Unknown)
                {
                    return sibling;
                }
            }

            return null;
        }

        private static AstNodeContext GetNextKnownStatementSibling(
            TSqlFragment statementList,
            int statementIndex,
            LayoutContext layoutContext)
        {
            int count =
                GetStatementCount(
                    statementList,
                    layoutContext);

            for (int index = statementIndex + 1;
                 index < count;
                 index++)
            {
                AstNodeContext sibling =
                    GetStatementSibling(
                        statementList,
                        index,
                        layoutContext);

                if (sibling != null &&
                    sibling.Node != null &&
                    GetFamily(sibling.Node) != StatementFamily.Unknown)
                {
                    return sibling;
                }
            }

            return null;
        }

        private static int GetStatementCount(
            TSqlFragment statementList,
            LayoutContext layoutContext)
        {
            return
                layoutContext.Walker
                    .GetChildren(
                        statementList)
                    .Count(
                        x =>
                            x != null &&
                            x.Node != null &&
                            TokenNavigator.IsIndexedRelationship(
                                x.Relationship,
                                "Statements"));
        }

        private static AstNodeContext GetStatementSibling(
            TSqlFragment statementList,
            int statementIndex,
            LayoutContext layoutContext)
        {
            string relationship =
                "Statements[" +
                statementIndex +
                "]";

            return
                layoutContext.Walker
                    .GetChildren(
                        statementList)
                    .FirstOrDefault(
                        x =>
                            x != null &&
                            x.Node != null &&
                            x.Relationship == relationship);
        }

        private static bool ShouldSeparate(
            StatementFamily previous,
            StatementFamily current)
        {
            if (previous == StatementFamily.Unknown ||
                current == StatementFamily.Unknown ||
                previous == current)
            {
                return false;
            }

            /*
             * Purely structural rule: a statement-family transition is a
             * logical boundary. No identifiers, comments, values, or
             * business semantics are inspected.
             */
            return true;
        }

        private static StatementFamily GetFamily(
            TSqlFragment node)
        {
            if (node == null)
            {
                return StatementFamily.Unknown;
            }

            string typeName =
                node.GetType().Name;

            switch (typeName)
            {
                case "DeclareVariableStatement":
                case "DeclareTableVariableStatement":
                    return StatementFamily.Declaration;

                case "SetVariableStatement":
                case "PredicateSetStatement":
                    return StatementFamily.Set;

                case "SelectStatement":
                    return StatementFamily.Query;

                case "InsertStatement":
                case "UpdateStatement":
                case "DeleteStatement":
                case "MergeStatement":
                    return StatementFamily.Dml;

                case "IfStatement":
                case "WhileStatement":
                case "TryCatchStatement":
                case "BeginEndBlockStatement":
                    return StatementFamily.ControlFlow;

                case "BeginTransactionStatement":
                case "CommitTransactionStatement":
                case "RollbackTransactionStatement":
                case "SaveTransactionStatement":
                    return StatementFamily.Transaction;

                case "ExecuteStatement":
                    return StatementFamily.Execution;

                case "CreateTableStatement":
                case "DropTableStatement":
                case "TruncateTableStatement":
                    return StatementFamily.TableSetup;

                case "ThrowStatement":
                case "ReturnStatement":
                    return StatementFamily.Terminal;

                default:
                    return StatementFamily.Unknown;
            }
        }

        private enum StatementFamily
        {
            Unknown,
            Set,
            Declaration,
            Query,
            Dml,
            ControlFlow,
            Transaction,
            Execution,
            TableSetup,
            Terminal
        }
    }
}
