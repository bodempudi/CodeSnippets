using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class HintLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "OptimizerHints"))
            {
                ApplyOptimizerHint(
                    context,
                    layoutContext);

                return;
            }

            string nodeType =
                context.Node.GetType().Name;

            if (nodeType.IndexOf(
                    "OptimizerHintClause",
                    StringComparison.OrdinalIgnoreCase) >= 0 ||
                nodeType.IndexOf(
                    "OptionClause",
                    StringComparison.OrdinalIgnoreCase) >= 0)
            {
                int optionIndex =
                    layoutContext.TokenNavigator
                        .FindMeaningfulTokenByTextBetween(
                            context.Node.FirstTokenIndex,
                            context.Node.LastTokenIndex,
                            "OPTION");

                if (optionIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        optionIndex,
                        QueryIndentResolver.GetQueryBaseIndent(
                            context.Node,
                            layoutContext),
                        "HintLayoutPolicy",
                        context);
                }
            }
        }

        private static void ApplyOptimizerHint(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int baseIndent =
                QueryIndentResolver.GetQueryBaseIndent(
                    context.Node,
                    layoutContext);

            int itemIndent =
                baseIndent + 1;

            int position =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (position <= 0)
            {
                TSqlFragment parent =
                    context.Parent;

                if (parent != null)
                {
                    int optionIndex =
                        layoutContext.TokenNavigator
                            .FindMeaningfulTokenByTextBetween(
                                parent.FirstTokenIndex,
                                context.Node.FirstTokenIndex,
                                "OPTION");

                    if (optionIndex >= 0)
                    {
                        layoutContext.AddInstruction(
                            optionIndex,
                            baseIndent,
                            "HintLayoutPolicy",
                            context);
                    }
                }

                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    itemIndent,
                    "HintLayoutPolicy",
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    itemIndent,
                    "HintLayoutPolicy",
                    context);
            }
        }
    }
}
