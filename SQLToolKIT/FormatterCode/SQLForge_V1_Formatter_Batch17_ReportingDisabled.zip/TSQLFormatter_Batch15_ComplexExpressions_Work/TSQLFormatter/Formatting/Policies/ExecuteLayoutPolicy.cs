using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class ExecuteLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                context.Parent == null ||
                layoutContext == null)
            {
                return;
            }

            if (!TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Parameters") &&
                !TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "ExecuteParameters"))
            {
                return;
            }

            string parentType =
                context.Parent.GetType().Name;

            if (parentType.IndexOf(
                    "Execute",
                    StringComparison.Ordinal) < 0)
            {
                return;
            }

            int indent =
                StatementIndentResolver.GetStatementIndent(
                    context.Parent,
                    layoutContext) + 1;

            int index =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (index <= 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    indent,
                    "ExecuteLayoutPolicy",
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    indent,
                    "ExecuteLayoutPolicy",
                    context);
            }
        }
    }
}
