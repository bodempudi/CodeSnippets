using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class DeclarationLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                context.Parent == null ||
                layoutContext == null)
            {
                return;
            }

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Declarations") &&
                string.Equals(
                    context.Parent.GetType().Name,
                    "DeclareVariableStatement",
                    StringComparison.Ordinal))
            {
                ApplyTrailingCommaItem(
                    context,
                    layoutContext,
                    StatementIndentResolver.GetStatementIndent(
                        context.Parent,
                        layoutContext) + 1,
                    "DeclarationLayoutPolicy");

                return;
            }

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Parameters") &&
                IsRoutineParameter(context, layoutContext))
            {
                ApplyTrailingCommaItem(
                    context,
                    layoutContext,
                    GetOwningDefinitionIndent(
                        context,
                        layoutContext) + 1,
                    "DeclarationLayoutPolicy");
            }
        }

        private static bool IsRoutineParameter(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            /*
             * The relationship name "Parameters" is also used by
             * SqlDataTypeReference and function-call AST nodes.
             * Only actual routine parameter nodes belong to this policy.
             *
             * Without this guard, constructs such as VARCHAR(20),
             * DECIMAL(18,2), COUNT(*) and ISNULL(x,0) are incorrectly
             * treated as procedure/function parameter lists.
             */
            if (context == null ||
                context.Node == null ||
                !string.Equals(
                    context.Node.GetType().Name,
                    "ProcedureParameter",
                    StringComparison.Ordinal))
            {
                return false;
            }

            TSqlFragment current = context.Parent;

            while (current != null)
            {
                string name = current.GetType().Name;

                if (name.IndexOf("Procedure", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    name.IndexOf("Function", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }

                current = layoutContext.Walker.GetParent(current);
            }

            return false;
        }

        private static int GetOwningDefinitionIndent(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            TSqlFragment current = context.Node;

            while (current != null)
            {
                string name = current.GetType().Name;

                if (name.IndexOf("Procedure", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    name.IndexOf("Function", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return StatementIndentResolver.GetStatementIndent(
                        current,
                        layoutContext);
                }

                current = layoutContext.Walker.GetParent(current);
            }

            return 0;
        }

        private static void ApplyTrailingCommaItem(
            AstNodeContext context,
            LayoutContext layoutContext,
            int indent,
            string policyName)
        {
            int index = TokenNavigator.GetRelationshipIndex(
                context.Relationship);

            if (index <= 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    indent,
                    policyName,
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                // Procedure parameters and DECLARE variables use
                // trailing commas.  Force the comma onto the end of
                // the previous item, then start the next item on its
                // own correctly-indented line.
                layoutContext.AddTightInstruction(
                    commaIndex,
                    policyName,
                    context);
            }

            layoutContext.AddInstruction(
                context.Node.FirstTokenIndex,
                indent,
                policyName,
                context);
        }
    }
}
