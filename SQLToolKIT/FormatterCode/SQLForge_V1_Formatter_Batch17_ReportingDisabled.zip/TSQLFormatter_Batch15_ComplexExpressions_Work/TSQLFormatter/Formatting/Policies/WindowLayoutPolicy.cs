using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class WindowLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            OverClause overClause =
                context.Node as OverClause;

            if (overClause != null)
            {
                ApplyOverClause(
                    overClause,
                    context,
                    layoutContext);

                return;
            }

            string parentType =
                context.Parent == null
                    ? string.Empty
                    : context.Parent.GetType().Name;

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Partitions") &&
                string.Equals(
                    parentType,
                    "OverClause",
                    StringComparison.Ordinal))
            {
                ApplyPartitionItem(
                    context,
                    layoutContext);

                return;
            }

            if (context.Relationship ==
                    "OrderByClause" &&
                string.Equals(
                    parentType,
                    "OverClause",
                    StringComparison.Ordinal))
            {
                int indent =
                    ExpressionIndentResolver
                        .GetExpressionBaseIndent(
                            context.Parent,
                            layoutContext) +
                    1;

                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    indent,
                    "WindowLayoutPolicy",
                    context);
            }
        }

        private static void ApplyOverClause(
            OverClause overClause,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int overIndent =
                ExpressionIndentResolver
                    .GetExpressionBaseIndent(
                        overClause,
                        layoutContext);

            int leftParenthesisIndex =
                FindToken(
                    layoutContext,
                    overClause.FirstTokenIndex,
                    overClause.LastTokenIndex,
                    TSqlTokenType.LeftParenthesis);

            if (leftParenthesisIndex >= 0)
            {
                layoutContext.AddInstruction(
                    leftParenthesisIndex,
                    overIndent,
                    "WindowLayoutPolicy",
                    context);
            }

            int rightParenthesisIndex =
                FindLastToken(
                    layoutContext,
                    overClause.FirstTokenIndex,
                    overClause.LastTokenIndex,
                    TSqlTokenType.RightParenthesis);

            if (rightParenthesisIndex >= 0)
            {
                layoutContext.AddInstruction(
                    rightParenthesisIndex,
                    overIndent,
                    "WindowLayoutPolicy",
                    context);
            }
        }

        private static void ApplyPartitionItem(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int baseIndent =
                ExpressionIndentResolver
                    .GetExpressionBaseIndent(
                        context.Parent,
                        layoutContext) +
                1;

            int index =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (index <= 0)
            {
                int partitionIndex =
                    layoutContext.TokenNavigator
                        .FindTokenSequenceByTextBetween(
                            context.Parent.FirstTokenIndex,
                            context.Node.FirstTokenIndex,
                            "PARTITION",
                            "BY");

                if (partitionIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        partitionIndex,
                        baseIndent,
                        "WindowLayoutPolicy",
                        context);
                }

                /*
                 * Put the first PARTITION BY expression on the next
                 * indentation level.
                 */
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    baseIndent + 1,
                    "WindowLayoutPolicy",
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator
                    .FindPreviousToken(
                        context.Node.FirstTokenIndex,
                        TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    baseIndent + 1,
                    "WindowLayoutPolicy",
                    context);

                layoutContext.AddTightInstruction(
                    context.Node.FirstTokenIndex,
                    "WindowLayoutPolicy",
                    context);
            }
        }

        private static int FindToken(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (start < 0)
            {
                start = 0;
            }

            if (end >= layoutContext.Tokens.Count)
            {
                end = layoutContext.Tokens.Count - 1;
            }

            for (int i = start; i <= end; i++)
            {
                if (layoutContext.Tokens[i].TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }

        private static int FindLastToken(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (start < 0)
            {
                start = 0;
            }

            if (end >= layoutContext.Tokens.Count)
            {
                end = layoutContext.Tokens.Count - 1;
            }

            for (int i = end; i >= start; i--)
            {
                if (layoutContext.Tokens[i].TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }
    }
}
