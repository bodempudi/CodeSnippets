using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class IndexLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            if (context.Parent != null &&
                IsIndexOwner(
                    context.Parent.GetType().Name))
            {
                if (TokenNavigator.IsIndexedRelationship(
                        context.Relationship,
                        "Columns") ||
                    TokenNavigator.IsIndexedRelationship(
                        context.Relationship,
                        "IncludeColumns"))
                {
                    ApplyCommaLeadingItem(
                        context,
                        layoutContext);

                    return;
                }
            }

            string nodeType =
                context.Node.GetType().Name;

            if (!IsIndexOwner(nodeType))
            {
                return;
            }

            int baseIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Node,
                    layoutContext);

            ApplyMainIndexColumnList(
                context,
                layoutContext,
                baseIndent);

            AddKeywordIfPresent(
                context,
                layoutContext,
                "INCLUDE",
                baseIndent);

            AddKeywordIfPresent(
                context,
                layoutContext,
                "WHERE",
                baseIndent);

            AddKeywordIfPresent(
                context,
                layoutContext,
                "WITH",
                baseIndent);
        }

        private static bool IsIndexOwner(
            string typeName)
        {
            if (string.IsNullOrEmpty(typeName))
            {
                return false;
            }

            return
                typeName.IndexOf(
                    "Index",
                    StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void ApplyCommaLeadingItem(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int indent =
                StatementIndentResolver.GetStatementIndent(
                    context.Parent,
                    layoutContext) + 1;

            int index =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (index <= 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    indent,
                    "IndexLayoutPolicy",
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    indent,
                    "IndexLayoutPolicy",
                    context);

                layoutContext.AddTightInstruction(
                    context.Node.FirstTokenIndex,
                    "IndexLayoutPolicy",
                    context);
            }
        }

        private static void ApplyMainIndexColumnList(
            AstNodeContext context,
            LayoutContext layoutContext,
            int baseIndent)
        {
            int onIndex =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        context.Node.FirstTokenIndex,
                        context.Node.LastTokenIndex,
                        "ON");

            if (onIndex < 0)
            {
                return;
            }

            int openIndex = -1;

            for (int i = onIndex + 1;
                 i <= context.Node.LastTokenIndex &&
                 i < layoutContext.Tokens.Count;
                 i++)
            {
                if (layoutContext.Tokens[i].TokenType ==
                    TSqlTokenType.LeftParenthesis)
                {
                    openIndex = i;
                    break;
                }
            }

            if (openIndex < 0)
            {
                return;
            }

            int closeIndex = -1;
            int depth = 0;

            for (int i = openIndex;
                 i <= context.Node.LastTokenIndex &&
                 i < layoutContext.Tokens.Count;
                 i++)
            {
                TSqlTokenType tokenType =
                    layoutContext.Tokens[i].TokenType;

                if (tokenType == TSqlTokenType.LeftParenthesis)
                {
                    depth++;
                }
                else if (tokenType == TSqlTokenType.RightParenthesis)
                {
                    depth--;

                    if (depth == 0)
                    {
                        closeIndex = i;
                        break;
                    }
                }
            }

            if (closeIndex < 0)
            {
                return;
            }

            layoutContext.AddInstruction(
                openIndex,
                baseIndent,
                "IndexLayoutPolicy",
                context);

            int firstItemIndex =
                FindNextMeaningfulToken(
                    layoutContext,
                    openIndex + 1,
                    closeIndex - 1);

            if (firstItemIndex >= 0)
            {
                layoutContext.AddInstruction(
                    firstItemIndex,
                    baseIndent + 1,
                    "IndexLayoutPolicy",
                    context);
            }

            depth = 1;

            for (int i = openIndex + 1;
                 i < closeIndex;
                 i++)
            {
                TSqlTokenType tokenType =
                    layoutContext.Tokens[i].TokenType;

                if (tokenType == TSqlTokenType.LeftParenthesis)
                {
                    depth++;
                    continue;
                }

                if (tokenType == TSqlTokenType.RightParenthesis)
                {
                    depth--;
                    continue;
                }

                if (depth != 1 ||
                    tokenType != TSqlTokenType.Comma)
                {
                    continue;
                }

                int nextItemIndex =
                    FindNextMeaningfulToken(
                        layoutContext,
                        i + 1,
                        closeIndex - 1);

                layoutContext.AddInstruction(
                    i,
                    baseIndent + 1,
                    "IndexLayoutPolicy",
                    context);

                if (nextItemIndex >= 0)
                {
                    layoutContext.AddTightInstruction(
                        nextItemIndex,
                        "IndexLayoutPolicy",
                        context);
                }
            }

            layoutContext.AddInstruction(
                closeIndex,
                baseIndent,
                "IndexLayoutPolicy",
                context);
        }

        private static int FindNextMeaningfulToken(
            LayoutContext layoutContext,
            int start,
            int end)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            if (start < 0)
            {
                start = 0;
            }

            if (end >= layoutContext.Tokens.Count)
            {
                end = layoutContext.Tokens.Count - 1;
            }

            for (int i = start; i <= end; i++)
            {
                TSqlTokenType tokenType =
                    layoutContext.Tokens[i].TokenType;

                if (tokenType == TSqlTokenType.WhiteSpace ||
                    tokenType == TSqlTokenType.SingleLineComment ||
                    tokenType == TSqlTokenType.MultilineComment)
                {
                    continue;
                }

                return i;
            }

            return -1;
        }

        private static void AddKeywordIfPresent(
            AstNodeContext context,
            LayoutContext layoutContext,
            string keyword,
            int indent)
        {
            int index =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        context.Node.FirstTokenIndex,
                        context.Node.LastTokenIndex,
                        keyword);

            if (index >= 0)
            {
                layoutContext.AddInstruction(
                    index,
                    indent,
                    "IndexLayoutPolicy",
                    context);
            }
        }
    }
}
