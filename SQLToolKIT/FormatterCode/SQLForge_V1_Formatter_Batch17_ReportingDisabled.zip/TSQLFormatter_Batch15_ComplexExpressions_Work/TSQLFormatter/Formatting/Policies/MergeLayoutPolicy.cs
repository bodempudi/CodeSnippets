using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class MergeLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            string nodeType =
                context.Node.GetType().Name;

            if (!string.Equals(
                    nodeType,
                    "MergeSpecification",
                    StringComparison.Ordinal) &&
                !string.Equals(
                    nodeType,
                    "MergeStatement",
                    StringComparison.Ordinal))
            {
                return;
            }

            int baseIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Node,
                    layoutContext);

            FormatKeyword(
                context,
                layoutContext,
                "USING",
                baseIndent);

            FormatKeyword(
                context,
                layoutContext,
                "ON",
                baseIndent + 1);

            FormatAllKeywords(
                context,
                layoutContext,
                "WHEN",
                baseIndent);

            FormatKeyword(
                context,
                layoutContext,
                "OUTPUT",
                baseIndent);
        }

        private static void FormatKeyword(
            AstNodeContext context,
            LayoutContext layoutContext,
            string keyword,
            int indent)
        {
            int index =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        context.Node.FirstTokenIndex,
                        context.Node.LastTokenIndex,
                        keyword);

            if (index >= 0)
            {
                layoutContext.AddInstruction(
                    index,
                    indent,
                    "MergeLayoutPolicy",
                    context);
            }
        }

        private static void FormatAllKeywords(
            AstNodeContext context,
            LayoutContext layoutContext,
            string keyword,
            int indent)
        {
            int start =
                context.Node.FirstTokenIndex;

            while (start <=
                   context.Node.LastTokenIndex)
            {
                int index =
                    layoutContext.TokenNavigator
                        .FindMeaningfulTokenByTextBetween(
                            start,
                            context.Node.LastTokenIndex,
                            keyword);

                if (index < 0)
                {
                    return;
                }

                layoutContext.AddInstruction(
                    index,
                    indent,
                    "MergeLayoutPolicy",
                    context);

                start = index + 1;
            }
        }
    }
}
