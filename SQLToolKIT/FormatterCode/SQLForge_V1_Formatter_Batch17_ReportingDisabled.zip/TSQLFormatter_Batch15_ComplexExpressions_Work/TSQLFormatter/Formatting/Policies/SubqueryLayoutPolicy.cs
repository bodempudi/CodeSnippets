﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using NotepadPlusPlusPlugin.Formatting.Resolvers;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class SubqueryLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            /*
             * ======================================================
             * EXISTS / NOT EXISTS
             * ======================================================
             */

            ExistsPredicate existsPredicate =
                context.Node as ExistsPredicate;

            if (existsPredicate != null &&
                existsPredicate.Subquery != null)
            {
                ApplyExists(
                    existsPredicate,
                    context,
                    layoutContext);

                return;
            }

            /*
             * ======================================================
             * IN / NOT IN
             * ======================================================
             */

            InPredicate inPredicate =
                context.Node as InPredicate;

            if (inPredicate != null &&
                inPredicate.Subquery != null)
            {
                ApplyInSubquery(
                    inPredicate,
                    context,
                    layoutContext);

                return;
            }

            /*
             * ======================================================
             * SCALAR SUBQUERY
             * ======================================================
             */

            ScalarSubquery scalarSubquery =
                context.Node as ScalarSubquery;

            if (scalarSubquery == null)
            {
                return;
            }

            /*
             * EXISTS and IN already own their
             * ScalarSubquery delimiter formatting.
             */
            if (context.Parent is ExistsPredicate ||
                context.Parent is InPredicate)
            {
                return;
            }

            ApplyScalarSubquery(
                scalarSubquery,
                context,
                layoutContext);
        }

        /*
         * ==========================================================
         * EXISTS / NOT EXISTS
         * ==========================================================
         *
         * Direct WHERE:
         *
         * where exists
         * (
         *     select ...
         * )
         *
         * where not exists
         * (
         *     select ...
         * )
         *
         *
         * Boolean branch:
         *
         * where
         *     A=1
         *     and exists
         *     (
         *         select ...
         *     )
         *
         *     and not exists
         *     (
         *         select ...
         *     )
         */

        private static void ApplyExists(
            ExistsPredicate existsPredicate,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int openParenthesisIndex =
                existsPredicate.FirstTokenIndex;

            int closeParenthesisIndex =
                existsPredicate.LastTokenIndex;

            if (!IsValidTokenIndex(
                    layoutContext,
                    openParenthesisIndex) ||
                !IsValidTokenIndex(
                    layoutContext,
                    closeParenthesisIndex))
            {
                return;
            }

            int selectIndex =
                FindToken(
                    layoutContext,
                    openParenthesisIndex,
                    closeParenthesisIndex,
                    TSqlTokenType.Select);

            /*
             * Context-sensitive EXISTS indentation.
             */
            int baseIndent =
                GetExistsSubqueryIndent(
                    existsPredicate,
                    layoutContext);

            /*
             * (
             */
            layoutContext.AddInstruction(
                openParenthesisIndex,
                baseIndent,
                "SubqueryLayoutPolicy",
                context);

            /*
             * SELECT
             */
            if (selectIndex >= 0)
            {
                layoutContext.AddInstruction(
                    selectIndex,
                    baseIndent + 1,
                    "SubqueryLayoutPolicy",
                    context);
            }

            /*
             * )
             */
            layoutContext.AddInstruction(
                closeParenthesisIndex,
                baseIndent,
                "SubqueryLayoutPolicy",
                context);

            layoutContext.Diagnostics.Add(
                "SUBQUERY",
                "EXISTS subquery layout created. " +
                "OpenIndex=" +
                openParenthesisIndex +
                ", SelectIndex=" +
                selectIndex +
                ", CloseIndex=" +
                closeParenthesisIndex +
                ", BaseIndent=" +
                baseIndent +
                ".");
        }

        /*
         * ==========================================================
         * IN / NOT IN SUBQUERY
         * ==========================================================
         */

        private static void ApplyInSubquery(
            InPredicate inPredicate,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            ScalarSubquery subquery =
                inPredicate.Subquery;

            if (subquery == null)
            {
                return;
            }

            int openParenthesisIndex =
                subquery.FirstTokenIndex;

            int closeParenthesisIndex =
                subquery.LastTokenIndex;

            if (!IsValidTokenIndex(
                    layoutContext,
                    openParenthesisIndex) ||
                !IsValidTokenIndex(
                    layoutContext,
                    closeParenthesisIndex))
            {
                return;
            }

            int selectIndex =
                FindToken(
                    layoutContext,
                    openParenthesisIndex,
                    closeParenthesisIndex,
                    TSqlTokenType.Select);

            int baseIndent =
                GetBooleanSubqueryIndent(
                    inPredicate,
                    layoutContext);

            /*
             * (
             */
            layoutContext.AddInstruction(
                openParenthesisIndex,
                baseIndent,
                "SubqueryLayoutPolicy",
                context);

            /*
             * SELECT
             */
            if (selectIndex >= 0)
            {
                layoutContext.AddInstruction(
                    selectIndex,
                    baseIndent + 1,
                    "SubqueryLayoutPolicy",
                    context);
            }

            /*
             * )
             */
            layoutContext.AddInstruction(
                closeParenthesisIndex,
                baseIndent,
                "SubqueryLayoutPolicy",
                context);

            layoutContext.Diagnostics.Add(
                "SUBQUERY",
                "IN subquery layout created. " +
                "OpenIndex=" +
                openParenthesisIndex +
                ", SelectIndex=" +
                selectIndex +
                ", CloseIndex=" +
                closeParenthesisIndex +
                ", BaseIndent=" +
                baseIndent +
                ".");
        }

        /*
         * ==========================================================
         * SCALAR SUBQUERY
         * ==========================================================
         */

        private static void ApplyScalarSubquery(
            ScalarSubquery scalarSubquery,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int openParenthesisIndex =
                scalarSubquery.FirstTokenIndex;

            int closeParenthesisIndex =
                scalarSubquery.LastTokenIndex;

            if (!IsValidTokenIndex(
                    layoutContext,
                    openParenthesisIndex) ||
                !IsValidTokenIndex(
                    layoutContext,
                    closeParenthesisIndex))
            {
                return;
            }

            int selectIndex =
                FindToken(
                    layoutContext,
                    openParenthesisIndex,
                    closeParenthesisIndex,
                    TSqlTokenType.Select);

            int baseIndent =
                ExpressionIndentResolver
                    .GetExpressionBaseIndent(
                        scalarSubquery,
                        layoutContext);

            LayoutAction openingAction =
                TokenPlacementResolver
                    .ResolveSubqueryOpening(
                        context);

            /*
             * Opening (
             */
            switch (openingAction)
            {
                case LayoutAction.NewLine:

                    layoutContext.AddInstruction(
                        openParenthesisIndex,
                        baseIndent,
                        "SubqueryLayoutPolicy",
                        context);

                    break;

                case LayoutAction.Space:

                    layoutContext.AddSpaceInstruction(
                        openParenthesisIndex,
                        "SubqueryLayoutPolicy",
                        context);

                    break;

                case LayoutAction.Tight:

                    layoutContext.AddTightInstruction(
                        openParenthesisIndex,
                        "SubqueryLayoutPolicy",
                        context);

                    break;
            }

            /*
             * SELECT
             */
            if (selectIndex >= 0)
            {
                layoutContext.AddInstruction(
                    selectIndex,
                    baseIndent + 1,
                    "SubqueryLayoutPolicy",
                    context);
            }

            /*
             * )
             */
            layoutContext.AddInstruction(
                closeParenthesisIndex,
                baseIndent,
                "SubqueryLayoutPolicy",
                context);

            layoutContext.Diagnostics.Add(
                "SUBQUERY",
                "Scalar subquery layout created. " +
                "OpenIndex=" +
                openParenthesisIndex +
                ", SelectIndex=" +
                selectIndex +
                ", CloseIndex=" +
                closeParenthesisIndex +
                ", BaseIndent=" +
                baseIndent +
                ", OpeningAction=" +
                openingAction +
                ".");
        }

        /*
         * ==========================================================
         * EXISTS INDENT RESOLVER
         * ==========================================================
         */

        private static int GetExistsSubqueryIndent(
            ExistsPredicate existsPredicate,
            LayoutContext layoutContext)
        {
            if (existsPredicate == null ||
                layoutContext == null ||
                layoutContext.Walker == null)
            {
                return 0;
            }

            TSqlFragment parent =
                layoutContext.Walker.GetParent(
                    existsPredicate);

            /*
             * ======================================================
             * DIRECT WHERE EXISTS
             * ======================================================
             *
             * where exists
             * (
             *
             * Parenthesis aligns with WHERE/query base.
             */

            if (parent is WhereClause)
            {
                return
                    QueryIndentResolver
                        .GetQueryBaseIndent(
                            existsPredicate,
                            layoutContext);
            }

            /*
             * ======================================================
             * NOT EXISTS
             * ======================================================
             */

            BooleanNotExpression notExpression =
                parent as BooleanNotExpression;

            if (notExpression != null)
            {
                TSqlFragment notParent =
                    layoutContext.Walker.GetParent(
                        notExpression);

                /*
                 * Direct:
                 *
                 * where not exists
                 * (
                 */
                if (notParent is WhereClause)
                {
                    return
                        QueryIndentResolver
                            .GetQueryBaseIndent(
                                existsPredicate,
                                layoutContext);
                }

                /*
                 * Boolean branch:
                 *
                 * and not exists
                 *     (
                 *
                 * or not exists
                 *     (
                 */
                return
                    GetBooleanExpressionIndent(
                        notExpression,
                        layoutContext);
            }

            /*
             * ======================================================
             * EXISTS AS BOOLEAN BRANCH
             * ======================================================
             *
             * and exists
             *     (
             *
             * or exists
             *     (
             */

            if (parent is BooleanBinaryExpression ||
                parent is BooleanParenthesisExpression)
            {
                return
                    GetBooleanExpressionIndent(
                        existsPredicate,
                        layoutContext);
            }

            /*
             * Fallback.
             */
            return
                QueryIndentResolver
                    .GetQueryBaseIndent(
                        existsPredicate,
                        layoutContext);
        }

        /*
         * ==========================================================
         * BOOLEAN EXPRESSION INDENT
         * ==========================================================
         */

        private static int GetBooleanExpressionIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            int indent =
                QueryIndentResolver
                    .GetQueryBaseIndent(
                        node,
                        layoutContext) +
                1;

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    node);

            while (current != null)
            {
                if (current is
                    BooleanParenthesisExpression)
                {
                    indent++;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return indent;
        }

        /*
         * ==========================================================
         * BOOLEAN SUBQUERY INDENT
         * ==========================================================
         *
         * Used by IN / NOT IN.
         */

        private static int GetBooleanSubqueryIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            int indent =
                QueryIndentResolver
                    .GetQueryBaseIndent(
                        node,
                        layoutContext) +
                1;

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    node);

            while (current != null)
            {
                if (current is
                    BooleanParenthesisExpression)
                {
                    indent++;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return indent;
        }

        /*
         * ==========================================================
         * FIND TOKEN
         * ==========================================================
         */

        private static int FindToken(
            LayoutContext layoutContext,
            int start,
            int end,
            TSqlTokenType tokenType)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null ||
                layoutContext.Tokens.Count == 0)
            {
                return -1;
            }

            if (start < 0)
            {
                start =
                    0;
            }

            if (end >=
                layoutContext.Tokens.Count)
            {
                end =
                    layoutContext.Tokens.Count - 1;
            }

            if (start > end)
            {
                return -1;
            }

            for (int i = start;
                 i <= end;
                 i++)
            {
                if (layoutContext
                        .Tokens[i]
                        .TokenType ==
                    tokenType)
                {
                    return i;
                }
            }

            return -1;
        }

        /*
         * ==========================================================
         * TOKEN INDEX VALIDATION
         * ==========================================================
         */

        private static bool IsValidTokenIndex(
            LayoutContext layoutContext,
            int tokenIndex)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return false;
            }

            return
                tokenIndex >= 0 &&
                tokenIndex <
                    layoutContext.Tokens.Count;
        }
    }
}