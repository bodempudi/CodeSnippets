using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class ApplyPivotLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            string nodeType =
                context.Node.GetType().Name;

            if (string.Equals(
                    nodeType,
                    "UnqualifiedJoin",
                    StringComparison.Ordinal))
            {
                ApplyUnqualifiedJoin(
                    context,
                    layoutContext);

                return;
            }

            if (string.Equals(
                    nodeType,
                    "PivotedTableReference",
                    StringComparison.Ordinal))
            {
                ApplyKeyword(
                    context,
                    layoutContext,
                    "PIVOT");

                return;
            }

            if (string.Equals(
                    nodeType,
                    "UnpivotedTableReference",
                    StringComparison.Ordinal))
            {
                ApplyKeyword(
                    context,
                    layoutContext,
                    "UNPIVOT");
            }
        }

        private static void ApplyUnqualifiedJoin(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int baseIndent =
                QueryIndentResolver.GetQueryBaseIndent(
                    context.Node,
                    layoutContext) + 1;

            int tokenIndex =
                layoutContext.TokenNavigator
                    .FindTokenSequenceByTextBetween(
                        context.Node.FirstTokenIndex,
                        context.Node.LastTokenIndex,
                        "CROSS",
                        "APPLY");

            if (tokenIndex < 0)
            {
                tokenIndex =
                    layoutContext.TokenNavigator
                        .FindTokenSequenceByTextBetween(
                            context.Node.FirstTokenIndex,
                            context.Node.LastTokenIndex,
                            "OUTER",
                            "APPLY");
            }

            if (tokenIndex < 0)
            {
                tokenIndex =
                    layoutContext.TokenNavigator
                        .FindTokenSequenceByTextBetween(
                            context.Node.FirstTokenIndex,
                            context.Node.LastTokenIndex,
                            "CROSS",
                            "JOIN");
            }

            if (tokenIndex >= 0)
            {
                layoutContext.AddInstruction(
                    tokenIndex,
                    baseIndent,
                    "ApplyPivotLayoutPolicy",
                    context);
            }
        }

        private static void ApplyKeyword(
            AstNodeContext context,
            LayoutContext layoutContext,
            string keyword)
        {
            int keywordIndex =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        context.Node.FirstTokenIndex,
                        context.Node.LastTokenIndex,
                        keyword);

            if (keywordIndex < 0)
            {
                return;
            }

            int indent =
                QueryIndentResolver.GetQueryBaseIndent(
                    context.Node,
                    layoutContext) + 1;

            layoutContext.AddInstruction(
                keywordIndex,
                indent,
                "ApplyPivotLayoutPolicy",
                context);
        }
    }
}
