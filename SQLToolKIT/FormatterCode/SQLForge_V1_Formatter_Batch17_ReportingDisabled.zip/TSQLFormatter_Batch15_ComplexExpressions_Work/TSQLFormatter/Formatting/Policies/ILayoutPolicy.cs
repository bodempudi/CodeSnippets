namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public interface ILayoutPolicy
    {
        void Apply(AstNodeContext context, LayoutContext layoutContext);
    }
}
