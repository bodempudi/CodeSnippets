using Microsoft.SqlServer.TransactSql.ScriptDom;
using NotepadPlusPlusPlugin.Formatting.Resolvers;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class ClauseLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            int queryBaseIndent =
                QueryIndentResolver.GetQueryBaseIndent(
                    context.Node,
                    layoutContext);

            /*
             * ORDER BY inside an OVER() clause is owned by
             * WindowLayoutPolicy, not by the top-level query clause policy.
             */
            if (context.Relationship == "OrderByClause" &&
                context.Parent is OverClause)
            {
                return;
            }

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "OrderByElements") &&
                context.Parent is OrderByClause &&
                layoutContext.Walker.GetParent(
                    context.Parent) is OverClause)
            {
                return;
            }

            /*
             * ======================================================
             * MAJOR QUERY CLAUSES
             * ======================================================
             *
             * FROM / WHERE / GROUP BY / HAVING / ORDER BY
             * all align to the owning query base.
             */

            if (context.Relationship ==
                    "FromClause" ||
                context.Relationship ==
                    "WhereClause" ||
                context.Relationship ==
                    "GroupByClause" ||
                context.Relationship ==
                    "HavingClause" ||
                context.Relationship ==
                    "OrderByClause")
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    queryBaseIndent,
                    "ClauseLayoutPolicy",
                    context);

                return;
            }

            /*
             * ======================================================
             * GROUP BY ITEMS
             * ======================================================
             *
             * group by
             *     c.CustomerId
             *     ,c.Status
             */

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "GroupingSpecifications") &&
                context.Parent is GroupByClause)
            {
                ApplyCommaSeparatedClauseItem(
                    context,
                    layoutContext,
                    queryBaseIndent + 1);

                return;
            }

            /*
             * ======================================================
             * ORDER BY ITEMS
             * ======================================================
             *
             * order by
             *     c.Name
             *     ,c.CustomerId
             */

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "OrderByElements") &&
                context.Parent is OrderByClause)
            {
                ApplyCommaSeparatedClauseItem(
                    context,
                    layoutContext,
                    queryBaseIndent + 1);

                return;
            }

            /*
             * ======================================================
             * WHERE / HAVING FIRST CONDITION
             * ======================================================
             */

            if (context.Relationship !=
                "SearchCondition")
            {
                return;
            }

            bool isWhere =
                context.Parent is WhereClause;

            bool isHaving =
                context.Parent is HavingClause;

            if (!isWhere &&
                !isHaving)
            {
                return;
            }

            BooleanExpression expression =
                context.Node as BooleanExpression;

            if (expression == null)
            {
                return;
            }

            /*
             * WHERE/HAVING EXISTS stays inline with the clause.
             */

            if (expression is ExistsPredicate)
            {
                int startIndex =
                    BooleanExpressionStartResolver
                        .GetStartTokenIndex(
                            expression,
                            layoutContext);

                if (startIndex >= 0)
                {
                    layoutContext.AddSpaceInstruction(
                        startIndex,
                        "ClauseLayoutPolicy",
                        context);
                }

                return;
            }

            BooleanNotExpression notExpression =
                expression as BooleanNotExpression;

            if (notExpression != null &&
                notExpression.Expression is ExistsPredicate)
            {
                layoutContext.AddSpaceInstruction(
                    notExpression.FirstTokenIndex,
                    "ClauseLayoutPolicy",
                    context);

                return;
            }

            /*
             * Left-side scalar subquery owns its opening placement.
             */

            BooleanComparisonExpression comparison =
                expression as BooleanComparisonExpression;

            if (comparison != null &&
                comparison.FirstExpression is ScalarSubquery)
            {
                return;
            }

            int conditionStartIndex =
                BooleanExpressionStartResolver
                    .GetStartTokenIndex(
                        expression,
                        layoutContext);

            if (conditionStartIndex < 0)
            {
                return;
            }

            layoutContext.AddInstruction(
                conditionStartIndex,
                queryBaseIndent + 1,
                "ClauseLayoutPolicy",
                context);
        }

        private static void ApplyCommaSeparatedClauseItem(
            AstNodeContext context,
            LayoutContext layoutContext,
            int indentLevel)
        {
            int index =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (index <= 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    indentLevel,
                    "ClauseLayoutPolicy",
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator
                    .FindPreviousToken(
                        context.Node.FirstTokenIndex,
                        TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    indentLevel,
                    "ClauseLayoutPolicy",
                    context);
            }
        }
    }
}
