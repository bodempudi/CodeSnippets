using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class QueryTailLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            string nodeType =
                context.Node.GetType().Name;

            bool isForClause =
                string.Equals(
                    context.Relationship,
                    "ForClause",
                    StringComparison.Ordinal) ||
                nodeType.IndexOf(
                    "ForClause",
                    StringComparison.Ordinal) >= 0;

            bool isOffsetClause =
                string.Equals(
                    context.Relationship,
                    "OffsetClause",
                    StringComparison.Ordinal) ||
                nodeType.IndexOf(
                    "OffsetClause",
                    StringComparison.Ordinal) >= 0;

            if (!isForClause &&
                !isOffsetClause)
            {
                return;
            }

            int indent =
                QueryIndentResolver.GetQueryBaseIndent(
                    context.Node,
                    layoutContext);

            layoutContext.AddInstruction(
                context.Node.FirstTokenIndex,
                indent,
                "QueryTailLayoutPolicy",
                context);
        }
    }
}
