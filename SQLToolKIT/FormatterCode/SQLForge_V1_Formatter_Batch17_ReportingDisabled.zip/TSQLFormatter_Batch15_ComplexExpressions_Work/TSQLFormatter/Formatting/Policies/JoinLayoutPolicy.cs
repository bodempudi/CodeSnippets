using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class JoinLayoutPolicy : ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            int queryBaseIndent =
                QueryIndentResolver.GetQueryBaseIndent(
                    context.Node,
                    layoutContext);

            if (context.Relationship == "SecondTableReference" &&
                context.Parent != null &&
                context.Parent.GetType().Name == "QualifiedJoin")
            {
                int joinStart =
                    layoutContext.TokenNavigator.FindJoinStart(
                        context.Parent,
                        context.Node);

                if (joinStart >= 0)
                {
                    layoutContext.AddInstruction(
                        joinStart,
                        queryBaseIndent + 1,
                        "JoinLayoutPolicy",
                        context);
                }
            }

            if (context.Relationship == "SearchCondition" &&
                context.Parent != null &&
                context.Parent.GetType().Name == "QualifiedJoin")
            {
                int onIndex =
                    layoutContext.TokenNavigator.FindTokenBetween(
                        context.Parent.FirstTokenIndex,
                        context.Node.FirstTokenIndex,
                        TSqlTokenType.On);

                if (onIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        onIndex,
                        queryBaseIndent + 2,
                        "JoinLayoutPolicy",
                        context);
                }
            }
        }
    }
}
