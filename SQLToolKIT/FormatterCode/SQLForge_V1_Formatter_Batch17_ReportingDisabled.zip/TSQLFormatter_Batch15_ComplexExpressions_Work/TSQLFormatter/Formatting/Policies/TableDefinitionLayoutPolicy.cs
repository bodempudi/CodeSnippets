using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class TableDefinitionLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                context.Parent == null ||
                layoutContext == null)
            {
                return;
            }

            if (!string.Equals(
                    context.Parent.GetType().Name,
                    "TableDefinition",
                    StringComparison.Ordinal))
            {
                return;
            }

            if (!IsTableDefinitionItem(context.Relationship))
            {
                return;
            }

            IList<AstNodeContext> items =
                layoutContext.Walker.GetChildren(
                    context.Parent)
                    .Where(
                        x => x != null &&
                             x.Node != null &&
                             IsTableDefinitionItem(
                                 x.Relationship))
                    .OrderBy(
                        x => x.Node.FirstTokenIndex)
                    .ToList();

            int position = -1;

            for (int i = 0; i < items.Count; i++)
            {
                if (ReferenceEquals(
                        items[i].Node,
                        context.Node))
                {
                    position = i;
                    break;
                }
            }

            if (position < 0)
            {
                return;
            }

            int baseIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Parent,
                    layoutContext);

            if (position == 0)
            {
                int openIndex =
                    layoutContext.TokenNavigator.FindMeaningfulTokenByTextBetween(
                        context.Parent.FirstTokenIndex,
                        context.Node.FirstTokenIndex,
                        "(");

                if (openIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        openIndex,
                        baseIndent,
                        "TableDefinitionLayoutPolicy",
                        context);
                }

                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    baseIndent + 1,
                    "TableDefinitionLayoutPolicy",
                    context);
            }
            else
            {
                int commaIndex =
                    layoutContext.TokenNavigator.FindPreviousToken(
                        context.Node.FirstTokenIndex,
                        TSqlTokenType.Comma);

                if (commaIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        commaIndex,
                        baseIndent + 1,
                        "TableDefinitionLayoutPolicy",
                        context);
                }
            }

            if (position == items.Count - 1)
            {
                int closeIndex =
                    layoutContext.TokenNavigator.FindMeaningfulTokenByTextBetween(
                        context.Node.LastTokenIndex + 1,
                        context.Parent.LastTokenIndex,
                        ")");

                if (closeIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        closeIndex,
                        baseIndent,
                        "TableDefinitionLayoutPolicy",
                        context);
                }
            }
        }

        private static bool IsTableDefinitionItem(
            string relationship)
        {
            return
                TokenNavigator.IsIndexedRelationship(
                    relationship,
                    "ColumnDefinitions") ||
                TokenNavigator.IsIndexedRelationship(
                    relationship,
                    "TableConstraints");
        }
    }
}
