using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class SetOperatorLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            BinaryQueryExpression binaryQuery =
                context.Node as BinaryQueryExpression;

            if (binaryQuery == null ||
                binaryQuery.FirstQueryExpression == null ||
                binaryQuery.SecondQueryExpression == null)
            {
                return;
            }

            int baseIndent =
                GetSetBaseIndent(
                    binaryQuery,
                    layoutContext);

            int operatorIndex =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        binaryQuery
                            .FirstQueryExpression
                            .LastTokenIndex + 1,
                        binaryQuery
                            .SecondQueryExpression
                            .FirstTokenIndex - 1,
                        "UNION",
                        "EXCEPT",
                        "INTERSECT");

            if (operatorIndex >= 0)
            {
                layoutContext.AddInstruction(
                    operatorIndex,
                    baseIndent,
                    "SetOperatorLayoutPolicy",
                    context);
            }

            /*
             * The second query begins on its own line.
             * UNION ALL remains together because ALL is an original
             * token following UNION and is not reconstructed.
             */
            layoutContext.AddInstruction(
                binaryQuery
                    .SecondQueryExpression
                    .FirstTokenIndex,
                baseIndent,
                "SetOperatorLayoutPolicy",
                context);
        }

        private static int GetSetBaseIndent(
            BinaryQueryExpression binaryQuery,
            LayoutContext layoutContext)
        {
            LayoutInstruction established =
                layoutContext.Plan.GetInstruction(
                    binaryQuery
                        .FirstQueryExpression
                        .FirstTokenIndex);

            if (established != null &&
                established.Action ==
                LayoutAction.NewLine)
            {
                return
                    established.IndentLevel;
            }

            return 0;
        }
    }
}
