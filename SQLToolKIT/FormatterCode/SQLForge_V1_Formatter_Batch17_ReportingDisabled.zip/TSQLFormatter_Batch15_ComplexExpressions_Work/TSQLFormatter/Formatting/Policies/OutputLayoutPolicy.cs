using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class OutputLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            string nodeType =
                context.Node.GetType().Name;

            if (nodeType.IndexOf(
                    "OutputClause",
                    StringComparison.Ordinal) >= 0)
            {
                int indent =
                    StatementIndentResolver.GetStatementIndent(
                        context.Node,
                        layoutContext);

                int outputIndex =
                    layoutContext.TokenNavigator
                        .FindMeaningfulTokenByTextBetween(
                            context.Node.FirstTokenIndex,
                            context.Node.LastTokenIndex,
                            "OUTPUT");

                if (outputIndex < 0)
                {
                    outputIndex =
                        context.Node.FirstTokenIndex;
                }

                layoutContext.AddInstruction(
                    outputIndex,
                    indent,
                    "OutputLayoutPolicy",
                    context);

                return;
            }

            if (!TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "SelectColumns") &&
                !TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "OutputColumns"))
            {
                return;
            }

            if (context.Parent == null ||
                context.Parent.GetType().Name.IndexOf(
                    "Output",
                    StringComparison.Ordinal) < 0)
            {
                return;
            }

            int itemIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Parent,
                    layoutContext) + 1;

            int itemIndex =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (itemIndex <= 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    itemIndent,
                    "OutputLayoutPolicy",
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    itemIndent,
                    "OutputLayoutPolicy",
                    context);
            }
        }
    }
}
