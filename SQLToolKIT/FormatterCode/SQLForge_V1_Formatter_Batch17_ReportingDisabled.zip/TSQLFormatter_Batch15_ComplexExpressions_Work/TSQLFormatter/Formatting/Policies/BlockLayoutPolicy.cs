using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class BlockLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            BeginEndBlockStatement block =
                context.Node as BeginEndBlockStatement;

            if (block == null)
            {
                return;
            }

            int indent =
                StatementIndentResolver
                    .GetStatementIndent(
                        block,
                        layoutContext);

            /*
             * BEGIN is the first meaningful token of the block.
             */
            layoutContext.AddInstruction(
                block.FirstTokenIndex,
                indent,
                "BlockLayoutPolicy",
                context);

            /*
             * Do not assume LastTokenIndex == END.
             * ScriptDom may include the trailing semicolon in the
             * BeginEndBlockStatement token range.
             */
            int endIndex =
                layoutContext.TokenNavigator
                    .FindLastMeaningfulTokenByTextBetween(
                        block.FirstTokenIndex,
                        block.LastTokenIndex,
                        "END");

            if (endIndex < 0)
            {
                return;
            }

            layoutContext.AddInstruction(
                endIndex,
                indent,
                "BlockLayoutPolicy",
                context);

            /*
             * Repair both fresh and previously formatted SQL:
             *
             *     END
             *     ;
             *
             * becomes:
             *
             *     END;
             */
            int nextIndex =
                layoutContext.TokenNavigator
                    .FindNextMeaningfulToken(
                        endIndex + 1,
                        block.LastTokenIndex);

            if (nextIndex >= 0 &&
                layoutContext.TokenNavigator
                    .GetTokenText(nextIndex) == ";")
            {
                layoutContext.AddTightInstruction(
                    nextIndex,
                    "BlockLayoutPolicy",
                    context);
            }
        }
    }
}
