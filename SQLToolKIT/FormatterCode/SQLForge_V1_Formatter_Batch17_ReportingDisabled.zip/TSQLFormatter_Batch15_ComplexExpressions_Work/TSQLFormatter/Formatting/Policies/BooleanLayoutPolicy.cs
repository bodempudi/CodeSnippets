using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class BooleanLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            BooleanParenthesisExpression group =
                context.Node as BooleanParenthesisExpression;

            if (group != null)
            {
                ApplyBooleanGroup(
                    group,
                    context,
                    layoutContext);

                return;
            }

            BooleanBinaryExpression booleanNode =
                context.Node as BooleanBinaryExpression;

            if (booleanNode == null ||
                booleanNode.FirstExpression == null ||
                booleanNode.SecondExpression == null)
            {
                return;
            }

            int operatorTokenIndex =
                layoutContext.TokenNavigator
                    .FindBooleanOperatorBetween(
                        booleanNode
                            .FirstExpression
                            .LastTokenIndex,
                        booleanNode
                            .SecondExpression
                            .FirstTokenIndex);

            if (operatorTokenIndex < 0)
            {
                return;
            }

            int operatorIndent =
                GetBooleanIndent(
                    booleanNode,
                    layoutContext);

            layoutContext.AddInstruction(
                operatorTokenIndex,
                operatorIndent,
                "BooleanLayoutPolicy",
                context);
        }

        /*
         * ==========================================================
         * BOOLEAN PARENTHESIS GROUP
         * ==========================================================
         *
         * Example:
         *
         *     and
         *     (
         *         A=1
         *         or exists
         *         (
         *             ...
         *         )
         *     )
         */

        private static void ApplyBooleanGroup(
            BooleanParenthesisExpression group,
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (group == null ||
                group.Expression == null ||
                context == null ||
                context.Node == null)
            {
                return;
            }

            int groupIndent =
                GetBooleanIndent(
                    group,
                    layoutContext);

            /*
             * Opening (
             */

            layoutContext.AddInstruction(
                group.FirstTokenIndex,
                groupIndent,
                "BooleanLayoutPolicy",
                context);

            /*
             * ======================================================
             * FIRST VISIBLE TOKEN INSIDE THE GROUP
             * ======================================================
             *
             * Do NOT blindly use:
             *
             *     group.Expression.FirstTokenIndex
             *
             * ScriptDom can report an ExistsPredicate as starting
             * at "(" rather than at EXISTS.
             *
             * Resolve the actual visual beginning of the first
             * Boolean branch.
             */

            int expressionStartIndex =
                GetBooleanExpressionStartTokenIndex(
                    group.Expression,
                    layoutContext);

            if (expressionStartIndex >= 0)
            {
                layoutContext.AddInstruction(
                    expressionStartIndex,
                    groupIndent + 1,
                    "BooleanLayoutPolicy",
                    context);
            }

            /*
             * Closing )
             */

            layoutContext.AddInstruction(
                group.LastTokenIndex,
                groupIndent,
                "BooleanLayoutPolicy",
                context);
        }

        /*
         * ==========================================================
         * BOOLEAN EXPRESSION START
         * ==========================================================
         *
         * Walk down the FIRST branch of the Boolean tree until
         * reaching the structural expression that actually starts
         * the group.
         *
         * This avoids using a parent BooleanBinaryExpression's
         * inherited FirstTokenIndex when ScriptDom's child range
         * starts later than the visible SQL.
         */

        private static int GetBooleanExpressionStartTokenIndex(
            BooleanExpression expression,
            LayoutContext layoutContext)
        {
            if (expression == null ||
                layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            /*
             * A AND B / A OR B
             *
             * The visual beginning is the beginning of A.
             */

            BooleanBinaryExpression binary =
                expression as BooleanBinaryExpression;

            if (binary != null &&
                binary.FirstExpression != null)
            {
                return
                    GetBooleanExpressionStartTokenIndex(
                        binary.FirstExpression,
                        layoutContext);
            }

            /*
             * Parenthesized Boolean expression.
             *
             * The '(' really is the visible start.
             */

            BooleanParenthesisExpression parenthesis =
                expression as BooleanParenthesisExpression;

            if (parenthesis != null)
            {
                return
                    parenthesis.FirstTokenIndex;
            }

            /*
             * EXISTS is the important ScriptDom special shape:
             *
             *     exists
             *     (
             *         select ...
             *     )
             *
             * ExistsPredicate.FirstTokenIndex points at '('.
             *
             * Therefore walk backward to the preceding EXISTS
             * keyword. For NOT EXISTS, also include NOT.
             */

            ExistsPredicate existsPredicate =
                expression as ExistsPredicate;

            if (existsPredicate != null)
            {
                return
                    FindExistsStartTokenIndex(
                        existsPredicate,
                        layoutContext);
            }

            /*
             * Normal Boolean expression.
             */

            return
                expression.FirstTokenIndex;
        }

        /*
         * ==========================================================
         * EXISTS START TOKEN
         * ==========================================================
         */

        private static int FindExistsStartTokenIndex(
            ExistsPredicate existsPredicate,
            LayoutContext layoutContext)
        {
            int existsIndex =
                FindPreviousMeaningfulToken(
                    existsPredicate.FirstTokenIndex,
                    layoutContext);

            if (existsIndex < 0)
            {
                return
                    existsPredicate.FirstTokenIndex;
            }

            if (layoutContext
                    .Tokens[existsIndex]
                    .TokenType !=
                TSqlTokenType.Exists)
            {
                return
                    existsPredicate.FirstTokenIndex;
            }

            /*
             * Check for:
             *
             *     NOT EXISTS
             */

            int previousIndex =
                FindPreviousMeaningfulToken(
                    existsIndex,
                    layoutContext);

            if (previousIndex >= 0 &&
                layoutContext
                    .Tokens[previousIndex]
                    .TokenType ==
                TSqlTokenType.Not)
            {
                return
                    previousIndex;
            }

            return
                existsIndex;
        }

        /*
         * ==========================================================
         * PREVIOUS MEANINGFUL TOKEN
         * ==========================================================
         */

        private static int FindPreviousMeaningfulToken(
            int tokenIndex,
            LayoutContext layoutContext)
        {
            if (layoutContext == null ||
                layoutContext.Tokens == null)
            {
                return -1;
            }

            for (int i = tokenIndex - 1;
                 i >= 0;
                 i--)
            {
                TSqlParserToken token =
                    layoutContext.Tokens[i];

                if (token.TokenType ==
                        TSqlTokenType.WhiteSpace ||
                    token.TokenType ==
                        TSqlTokenType.SingleLineComment ||
                    token.TokenType ==
                        TSqlTokenType.MultilineComment)
                {
                    continue;
                }

                return i;
            }

            return -1;
        }

        /*
         * ==========================================================
         * BOOLEAN INDENT
         * ==========================================================
         */

        private static int GetBooleanIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            int caseWhenIndent =
                GetCaseWhenBooleanIndent(
                    node,
                    layoutContext);

            if (caseWhenIndent >= 0)
            {
                return caseWhenIndent;
            }

            int queryBaseIndent =
                QueryIndentResolver
                    .GetQueryBaseIndent(
                        node,
                        layoutContext);

            int indent =
                queryBaseIndent + 1;

            bool isJoinCondition =
                false;

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    node);

            while (current != null)
            {
                /*
                 * Boolean indentation is scoped to the nearest query.
                 * Parentheses belonging to an OUTER query must not leak
                 * into a nested subquery's WHERE clause.
                 */
                if (current is QuerySpecification)
                {
                    break;
                }

                if (current is QualifiedJoin)
                {
                    isJoinCondition =
                        true;
                }

                if (current is
                    BooleanParenthesisExpression)
                {
                    indent++;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            /*
             * JOIN predicates live one level deeper than WHERE predicates:
             *
             *     JOIN ...
             *         ON A=B
             *         AND C=D
             */
            if (isJoinCondition)
            {
                indent =
                    queryBaseIndent + 2 +
                    CountBooleanParenthesesToNearestQuery(
                        node,
                        layoutContext);
            }

            return indent;
        }

        private static int GetCaseWhenBooleanIndent(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            if (node == null ||
                layoutContext == null ||
                layoutContext.Walker == null)
            {
                return -1;
            }

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    node);

            int parenthesisDepth = 0;

            while (current != null)
            {
                if (current is BooleanParenthesisExpression)
                {
                    parenthesisDepth++;
                }

                SearchedWhenClause whenClause =
                    current as SearchedWhenClause;

                if (whenClause != null)
                {
                    TSqlFragment owner =
                        layoutContext.Walker.GetParent(
                            whenClause);

                    SearchedCaseExpression caseExpression =
                        owner as SearchedCaseExpression;

                    if (caseExpression == null)
                    {
                        return -1;
                    }

                    int caseIndent =
                        ExpressionIndentResolver
                            .GetExpressionBaseIndent(
                                caseExpression,
                                layoutContext);

                    // WHEN is case + 1. A multiline boolean
                    // continuation inside WHEN is one level deeper,
                    // matching the THEN continuation level.
                    return
                        caseIndent +
                        2 +
                        parenthesisDepth;
                }

                if (current is QuerySpecification)
                {
                    break;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return -1;
        }

        private static int CountBooleanParenthesesToNearestQuery(
            TSqlFragment node,
            LayoutContext layoutContext)
        {
            int count =
                0;

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    node);

            while (current != null)
            {
                if (current is QuerySpecification)
                {
                    break;
                }

                if (current is BooleanParenthesisExpression)
                {
                    count++;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }

            return count;
        }
    }
}