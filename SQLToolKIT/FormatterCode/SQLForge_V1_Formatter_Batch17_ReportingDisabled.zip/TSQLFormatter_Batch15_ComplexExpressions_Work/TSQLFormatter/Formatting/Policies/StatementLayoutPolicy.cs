using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class StatementLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            /*
             * Generic statement boundary rule:
             *
             * StatementList
             *     -> Statements[n]
             *
             * We do not care whether the statement is:
             *
             * SELECT
             * INSERT
             * UPDATE
             * DELETE
             * SET
             * DECLARE
             * IF
             * WHILE
             * TRY/CATCH
             * etc.
             */

            if (!TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Statements"))
            {
                return;
            }

            if (!(context.Parent is StatementList))
            {
                return;
            }

            /*
             * Important:
             *
             * Do not use EmptyStatement here.
             *
             * Some ScriptDom versions do not expose
             * an EmptyStatement type.
             *
             * Semicolon placement will be handled
             * using token/layout logic separately.
             */

            int indent =
                StatementIndentResolver
                    .GetStatementIndent(
                        context.Node,
                        layoutContext);

            layoutContext.AddInstruction(
                context.Node.FirstTokenIndex,
                indent,
                "StatementLayoutPolicy",
                context);
        }
    }
}
