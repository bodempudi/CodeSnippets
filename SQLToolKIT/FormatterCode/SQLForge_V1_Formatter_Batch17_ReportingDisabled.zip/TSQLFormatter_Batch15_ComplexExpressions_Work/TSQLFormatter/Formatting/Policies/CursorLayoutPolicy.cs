using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class CursorLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            QuerySpecification query =
                context.Node as QuerySpecification;

            if (query == null)
            {
                return;
            }

            TSqlFragment current =
                layoutContext.Walker.GetParent(
                    query);

            while (current != null)
            {
                string typeName =
                    current.GetType().Name;

                if (typeName.IndexOf(
                        "Cursor",
                        StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    int indent =
                        StatementIndentResolver.GetStatementIndent(
                            current,
                            layoutContext) + 1;

                    layoutContext.AddInstruction(
                        query.FirstTokenIndex,
                        indent,
                        "CursorLayoutPolicy",
                        context);

                    return;
                }

                current =
                    layoutContext.Walker.GetParent(
                        current);
            }
        }
    }
}
