using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NotepadPlusPlusPlugin.Formatting.Emission
{
    public sealed class TokenPreservingEmitter
    {
        private const string IndentText =
            "    ";

        private static readonly string SectionSeparatorText =
            new string('-', 135);

        public string Emit(
            IList<TSqlParserToken> tokens,
            LayoutPlan plan)
        {
            if (tokens == null)
            {
                throw new ArgumentNullException(
                    "tokens");
            }

            if (plan == null)
            {
                throw new ArgumentNullException(
                    "plan");
            }

            Dictionary<int, LayoutInstruction> instructions =
                plan.Instructions
                    .GroupBy(
                        x => x.TokenIndex)
                    .ToDictionary(
                        x => x.Key,
                        x => x.Last());

            StringBuilder output =
                new StringBuilder();

            for (int i = 0;
                 i < tokens.Count;
                 i++)
            {
                TSqlParserToken token =
                    tokens[i];

                LayoutInstruction instruction;

                if (instructions.TryGetValue(
                        i,
                        out instruction))
                {
                    ApplyInstruction(
                        output,
                        instruction);
                }

                if (token.TokenType ==
                    TSqlTokenType.EndOfFile)
                {
                    continue;
                }

                /*
                 * If upcoming token owns its whitespace through
                 * NewLine or Space, ignore existing whitespace.
                 */
                if (token.TokenType ==
                    TSqlTokenType.WhiteSpace)
                {
                    int next =
                        FindNextNonWhitespaceToken(
                            tokens,
                            i + 1);

                    if (next >= 0 &&
                        instructions.ContainsKey(
                            next))
                    {
                        continue;
                    }
                }

                output.Append(
                    token.Text);
            }

            return
                output.ToString();
        }

        /*
         * ==========================================================
         * APPLY LAYOUT ACTION
         * ==========================================================
         */

        private static void ApplyInstruction(
            StringBuilder output,
            LayoutInstruction instruction)
        {
            if (instruction == null)
            {
                return;
            }

            if (instruction.Action == LayoutAction.Tight)
            {
                ApplyTight(
                    output);

                return;
            }

            if (instruction.Action == LayoutAction.Space)
            {
                ApplySpace(
                    output);

                return;
            }

            if (instruction.Action == LayoutAction.BlankLine)
            {
                ApplyBlankLine(
                    output,
                    instruction.IndentLevel);

                return;
            }

            if (instruction.Action == LayoutAction.SectionSeparator)
            {
                ApplySectionSeparator(
                    output,
                    instruction.IndentLevel);

                return;
            }

            if (instruction.Action == LayoutAction.NewLine) 
            {
                ApplyNewLine(
                    output,
                    instruction.IndentLevel);
            }
        }

        /*
         * ==========================================================
         * NEW LINE
         * ==========================================================
         */

        private static void ApplyNewLine(
            StringBuilder output,
            int indentLevel)
        {
            RemoveTrailingWhitespace(
                output);

            if (!EndsWithNewLine(
                    output))
            {
                output.AppendLine();
            }

            output.Append(
                RepeatIndent(
                    indentLevel));
        }

        /*
         * ==========================================================
         * BLANK LINE
         * ==========================================================
         *
         * Normalize to exactly one empty line before the token.
         */

        private static void ApplyBlankLine(
            StringBuilder output,
            int indentLevel)
        {
            RemoveTrailingWhitespaceIncludingNewLines(
                output);

            if (output.Length > 0)
            {
                output.AppendLine();
                output.AppendLine();
            }

            output.Append(
                RepeatIndent(
                    indentLevel));
        }

        /*
         * ==========================================================
         * SECTION SEPARATOR
         * ==========================================================
         *
         * Normalize to exactly one 135-hyphen separator line before
         * the target token. The separator starts at the same indentation
         * level as the logical group it separates.
         *
         * On a second formatting pass, the generated separator already
         * exists in the token stream. Remove that trailing generated line
         * from the emitted prefix and write one normalized copy. This is
         * what makes the rule idempotent.
         */

        private static void ApplySectionSeparator(
            StringBuilder output,
            int indentLevel)
        {
            RemoveTrailingWhitespaceIncludingNewLines(
                output);

            RemoveTrailingGeneratedSectionSeparator(
                output);

            RemoveTrailingWhitespaceIncludingNewLines(
                output);

            if (output.Length > 0)
            {
                output.AppendLine();
            }

            output.Append(
                RepeatIndent(
                    indentLevel));

            output.Append(
                SectionSeparatorText);

            output.AppendLine();

            output.Append(
                RepeatIndent(
                    indentLevel));
        }

        private static void RemoveTrailingGeneratedSectionSeparator(
            StringBuilder output)
        {
            if (output == null ||
                output.Length == 0)
            {
                return;
            }

            int lineStart =
                output.Length - 1;

            while (lineStart >= 0 &&
                   output[lineStart] != '\r' &&
                   output[lineStart] != '\n')
            {
                lineStart--;
            }

            lineStart++;

            string lastLine =
                output.ToString(
                    lineStart,
                    output.Length - lineStart);

            if (!string.Equals(
                    lastLine.Trim(),
                    SectionSeparatorText,
                    StringComparison.Ordinal))
            {
                return;
            }

            output.Length =
                lineStart;
        }

        /*
         * ==========================================================
         * TIGHT
         * ==========================================================
         *
         * Remove all existing whitespace immediately before the token
         * and insert nothing.
         *
         * Examples:
         *
         *     ,NextColumn
         *     ;WITH
         */
        private static void ApplyTight(
            StringBuilder output)
        {
            RemoveTrailingWhitespaceIncludingNewLines(
                output);
        }

        /*
         * ==========================================================
         * SPACE
         * ==========================================================
         *
         * Remove any existing newline / spaces before the token,
         * then place exactly one normal space.
         */

        private static void ApplySpace(
            StringBuilder output)
        {
            RemoveTrailingWhitespaceIncludingNewLines(
                output);

            if (output.Length > 0)
            {
                output.Append(
                    ' ');
            }
        }

        /*
         * ==========================================================
         * NEXT NON-WHITESPACE TOKEN
         * ==========================================================
         */

        private static int FindNextNonWhitespaceToken(
            IList<TSqlParserToken> tokens,
            int start)
        {
            for (int i = start;
                 i < tokens.Count;
                 i++)
            {
                if (tokens[i].TokenType !=
                    TSqlTokenType.WhiteSpace)
                {
                    return i;
                }
            }

            return -1;
        }

        /*
         * ==========================================================
         * INDENT
         * ==========================================================
         */

        private static string RepeatIndent(
            int indentLevel)
        {
            if (indentLevel <= 0)
            {
                return
                    string.Empty;
            }

            return
                string.Concat(
                    Enumerable.Repeat(
                        IndentText,
                        indentLevel));
        }

        /*
         * ==========================================================
         * REMOVE HORIZONTAL WHITESPACE
         * ==========================================================
         */

        private static void RemoveTrailingWhitespace(
            StringBuilder builder)
        {
            while (builder.Length > 0)
            {
                char value =
                    builder[
                        builder.Length - 1];

                if (value != ' ' &&
                    value != '\t')
                {
                    break;
                }

                builder.Length--;
            }
        }

        /*
         * ==========================================================
         * REMOVE ALL TRAILING WHITESPACE
         * ==========================================================
         *
         * Used by Space action.
         *
         * Converts:
         *
         * where
         *     (
         *
         * into:
         *
         * where (
         */

        private static void RemoveTrailingWhitespaceIncludingNewLines(
            StringBuilder builder)
        {
            while (builder.Length > 0)
            {
                char value =
                    builder[
                        builder.Length - 1];

                if (value != ' ' &&
                    value != '\t' &&
                    value != '\r' &&
                    value != '\n')
                {
                    break;
                }

                builder.Length--;
            }
        }

        private static bool EndsWithNewLine(
            StringBuilder builder)
        {
            if (builder.Length == 0)
            {
                return false;
            }

            char last =
                builder[
                    builder.Length - 1];

            return
                last == '\r' ||
                last == '\n';
        }
    }
}