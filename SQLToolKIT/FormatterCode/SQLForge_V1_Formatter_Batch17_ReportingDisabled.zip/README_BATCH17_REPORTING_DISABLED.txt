SQLForge V1 Formatter - Batch 17
Reporting defaults changed:
- EnableLogFile = false
- EnablePdfReport = false

Formatter validation and safety checks remain enabled.
No reporting/logging source code was removed; hosts can explicitly enable either option later.
