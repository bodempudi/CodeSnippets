using System.Windows.Forms;
using NotepadPlusPlusPlugin.PluginInfrastructure;

namespace NotepadPlusPlusPlugin
{
    internal static class Main
    {
        internal const string PluginName = "$safeprojectname$";

        internal static void CommandMenuInit()
        {
            PluginBase.SetCommand(
                0,
                "Hello World",
                HelloWorld,
                new ShortcutKey(false, false, false, Keys.None));
        }

        public static void OnNotification(ScNotification notification)
        {
            // Intentionally empty.
            // Add only the Notepad++ / Scintilla notifications the plugin needs.
        }

        internal static void SetToolBarIcon()
        {
            // No toolbar in the minimal starter.
        }

        internal static void PluginCleanUp()
        {
            // Nothing to clean up in the minimal starter.
        }

        private static void HelloWorld()
        {
            MessageBox.Show(
                "Hello from " + PluginName + "!",
                PluginName,
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}
