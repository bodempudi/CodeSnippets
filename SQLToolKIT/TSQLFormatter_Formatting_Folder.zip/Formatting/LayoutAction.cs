namespace NotepadPlusPlusPlugin.Formatting
{
    public enum LayoutAction
    {
        NewLine,
        BlankLine,
        Space,
        Tight
    }
}
