using System.Collections.Generic;
using System.Linq;

namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class LayoutPlan
    {
        private readonly List<LayoutInstruction>
            _instructions;

        public LayoutPlan()
        {
            _instructions =
                new List<LayoutInstruction>();
        }
        public int Count
        {
            get
            {
                return _instructions.Count;
            }
        }
        public IReadOnlyList<LayoutInstruction>
            Instructions
        {
            get
            {
                return _instructions;
            }
        }

        /*
         * ==========================================================
         * NEW LINE
         * ==========================================================
         */

        public void NewLineBefore(
            int tokenIndex,
            int indentLevel,
            string policyName,
            string nodeType,
            string parentType,
            string relationship)
        {
            AddOrReplace(
                tokenIndex,
                indentLevel,
                LayoutAction.NewLine,
                policyName,
                nodeType,
                parentType,
                relationship);
        }

        /*
         * ==========================================================
         * BLANK LINE
         * ==========================================================
         *
         * Exactly one empty line before the token.
         */

        public void BlankLineBefore(
            int tokenIndex,
            int indentLevel,
            string policyName,
            string nodeType,
            string parentType,
            string relationship)
        {
            AddOrReplace(
                tokenIndex,
                indentLevel,
                LayoutAction.BlankLine,
                policyName,
                nodeType,
                parentType,
                relationship);
        }

        /*
         * ==========================================================
         * SPACE
         * ==========================================================
         */

        public void SpaceBefore(
            int tokenIndex,
            string policyName,
            string nodeType,
            string parentType,
            string relationship)
        {
            AddOrReplace(
                tokenIndex,
                0,
                LayoutAction.Space,
                policyName,
                nodeType,
                parentType,
                relationship);
        }

        /*
         * ==========================================================
         * TIGHT
         * ==========================================================
         *
         * No whitespace before the token.
         *
         * Example:
         *
         *     c.Balance>(
         */

        public void TightBefore(
            int tokenIndex,
            string policyName,
            string nodeType,
            string parentType,
            string relationship)
        {
            AddOrReplace(
                tokenIndex,
                0,
                LayoutAction.Tight,
                policyName,
                nodeType,
                parentType,
                relationship);
        }

        /*
         * ==========================================================
         * GENERIC ADD / REPLACE
         * ==========================================================
         *
         * One token should have one final placement instruction.
         *
         * If another policy already produced an instruction for
         * the same token, the latest structural decision replaces it.
         */

        private void AddOrReplace(
            int tokenIndex,
            int indentLevel,
            LayoutAction action,
            string policyName,
            string nodeType,
            string parentType,
            string relationship)
        {
            LayoutInstruction existing =
                FindInstruction(
                    tokenIndex);

            if (existing != null)
            {
                /*
                 * A logical BlankLine is stronger than a normal NewLine.
                 * Later structural policies may refine indentation, but they
                 * must not accidentally remove an already-established blank
                 * line for the same token.
                 */
                if (existing.Action == LayoutAction.BlankLine &&
                    action == LayoutAction.NewLine)
                {
                    existing.IndentLevel =
                        indentLevel;

                    return;
                }

                existing.IndentLevel =
                    indentLevel;

                existing.Action =
                    action;

                existing.PolicyName =
                    policyName;

                existing.NodeType =
                    nodeType;

                existing.ParentType =
                    parentType;

                existing.Relationship =
                    relationship;

                return;
            }

            LayoutInstruction instruction =
                new LayoutInstruction
                {
                    TokenIndex =
                        tokenIndex,

                    IndentLevel =
                        indentLevel,

                    Action =
                        action,

                    PolicyName =
                        policyName,

                    NodeType =
                        nodeType,

                    ParentType =
                        parentType,

                    Relationship =
                        relationship
                };

            _instructions.Add(
                instruction);
        }

        /*
         * ==========================================================
         * FIND
         * ==========================================================
         */

        private LayoutInstruction FindInstruction(
            int tokenIndex)
        {
            return _instructions
                .FirstOrDefault(
                    x =>
                        x.TokenIndex ==
                        tokenIndex);
        }

        /*
         * ==========================================================
         * ORDERED INSTRUCTIONS
         * ==========================================================
         */

        public IList<LayoutInstruction>
            GetOrderedInstructions()
        {
            return _instructions
                .OrderBy(
                    x => x.TokenIndex)
                .ToList();
        }

        /*
         * ==========================================================
         * LOOKUP
         * ==========================================================
         */

        public LayoutInstruction GetInstruction(
            int tokenIndex)
        {
            return FindInstruction(
                tokenIndex);
        }

        public bool HasInstruction(
            int tokenIndex)
        {
            return FindInstruction(
                tokenIndex) != null;
        }
    }
}