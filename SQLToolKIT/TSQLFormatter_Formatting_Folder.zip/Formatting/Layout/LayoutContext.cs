using Microsoft.SqlServer.TransactSql.ScriptDom;
using NotepadPlusPlusPlugin.Formatting.Diagnostics;
using System.Collections.Generic;

namespace NotepadPlusPlusPlugin.Formatting
{
    public sealed class LayoutContext
    {
        public LayoutContext(
    IList<TSqlParserToken> tokens,
    GenericAstWalker walker,
    LayoutPlan plan,
    FormatterDiagnostics diagnostics)
        {
            Tokens =
                tokens;

            Walker =
                walker;

            Plan =
                plan;

            Diagnostics =
                diagnostics;

            TokenNavigator =
                new TokenNavigator(
                    tokens);
        }

        public IList<TSqlParserToken> Tokens
        {
            get;
            private set;
        }

        public LayoutPlan Plan
        {
            get;
            private set;
        }

        public FormatterDiagnostics Diagnostics
        {
            get;
            private set;
        }

        public GenericAstWalker Walker
        {
            get;
            private set;
        }

        public TokenNavigator TokenNavigator
        {
            get;
            private set;
        }

        /*
         * ==========================================================
         * NEW LINE
         * ==========================================================
         */

        public void AddInstruction(
            int tokenIndex,
            int indentLevel,
            string policyName,
            AstNodeContext context)
        {
            if (!IsValidTokenIndex(
                    tokenIndex))
            {
                return;
            }

            Plan.NewLineBefore(
                tokenIndex,
                indentLevel,
                policyName,
                GetNodeType(
                    context),
                GetParentType(
                    context),
                GetRelationship(
                    context));

            Diagnostics.Add(
                "LAYOUT_RULE",
                "Policy=" +
                policyName +
                ", TokenIndex=" +
                tokenIndex +
                ", Token=[" +
                TokenNavigator.GetTokenText(
                    tokenIndex) +
                "]" +
                ", Action=NewLine" +
                ", Node=" +
                GetNodeType(
                    context) +
                ", Parent=" +
                GetParentType(
                    context) +
                ", Relationship=" +
                GetRelationship(
                    context) +
                ", Indent=" +
                indentLevel +
                ".");
        }

        /*
         * ==========================================================
         * BLANK LINE
         * ==========================================================
         *
         * Exactly one empty line before a new logical statement group.
         */

        public void AddBlankLineInstruction(
            int tokenIndex,
            int indentLevel,
            string policyName,
            AstNodeContext context)
        {
            if (!IsValidTokenIndex(
                    tokenIndex))
            {
                return;
            }

            Plan.BlankLineBefore(
                tokenIndex,
                indentLevel,
                policyName,
                GetNodeType(
                    context),
                GetParentType(
                    context),
                GetRelationship(
                    context));

            Diagnostics.Add(
                "LAYOUT_RULE",
                "Policy=" +
                policyName +
                ", TokenIndex=" +
                tokenIndex +
                ", Token=[" +
                TokenNavigator.GetTokenText(
                    tokenIndex) +
                "]" +
                ", Action=BlankLine" +
                ", Node=" +
                GetNodeType(
                    context) +
                ", Parent=" +
                GetParentType(
                    context) +
                ", Relationship=" +
                GetRelationship(
                    context) +
                ", Indent=" +
                indentLevel +
                ".");
        }

        /*
         * ==========================================================
         * SPACE
         * ==========================================================
         *
         * Exactly one space before the token.
         *
         * Example:
         *
         *     where (
         */

        public void AddSpaceInstruction(
            int tokenIndex,
            string policyName,
            AstNodeContext context)
        {
            if (!IsValidTokenIndex(
                    tokenIndex))
            {
                return;
            }

            Plan.SpaceBefore(
                tokenIndex,
                policyName,
                GetNodeType(
                    context),
                GetParentType(
                    context),
                GetRelationship(
                    context));

            Diagnostics.Add(
                "LAYOUT_RULE",
                "Policy=" +
                policyName +
                ", TokenIndex=" +
                tokenIndex +
                ", Token=[" +
                TokenNavigator.GetTokenText(
                    tokenIndex) +
                "]" +
                ", Action=Space" +
                ", Node=" +
                GetNodeType(
                    context) +
                ", Parent=" +
                GetParentType(
                    context) +
                ", Relationship=" +
                GetRelationship(
                    context) +
                ".");
        }

        /*
         * ==========================================================
         * TIGHT
         * ==========================================================
         *
         * No whitespace before the token.
         *
         * Example:
         *
         *     c.Balance>(
         */

        public void AddTightInstruction(
            int tokenIndex,
            string policyName,
            AstNodeContext context)
        {
            if (!IsValidTokenIndex(
                    tokenIndex))
            {
                return;
            }

            Plan.TightBefore(
                tokenIndex,
                policyName,
                GetNodeType(
                    context),
                GetParentType(
                    context),
                GetRelationship(
                    context));

            Diagnostics.Add(
                "LAYOUT_RULE",
                "Policy=" +
                policyName +
                ", TokenIndex=" +
                tokenIndex +
                ", Token=[" +
                TokenNavigator.GetTokenText(
                    tokenIndex) +
                "]" +
                ", Action=Tight" +
                ", Node=" +
                GetNodeType(
                    context) +
                ", Parent=" +
                GetParentType(
                    context) +
                ", Relationship=" +
                GetRelationship(
                    context) +
                ".");
        }

        /*
         * ==========================================================
         * VALIDATION
         * ==========================================================
         */

        private bool IsValidTokenIndex(
            int tokenIndex)
        {
            if (Tokens == null)
            {
                return false;
            }

            return
                tokenIndex >= 0 &&
                tokenIndex <
                    Tokens.Count;
        }

        /*
         * ==========================================================
         * CONTEXT HELPERS
         * ==========================================================
         */

        private static string GetNodeType(
            AstNodeContext context)
        {
            if (context == null ||
                context.Node == null)
            {
                return "<NULL>";
            }

            return
                context.Node
                    .GetType()
                    .Name;
        }

        private static string GetParentType(
            AstNodeContext context)
        {
            if (context == null ||
                context.Parent == null)
            {
                return "<NULL>";
            }

            return
                context.Parent
                    .GetType()
                    .Name;
        }

        private static string GetRelationship(
            AstNodeContext context)
        {
            if (context == null ||
                string.IsNullOrEmpty(
                    context.Relationship))
            {
                return "<NULL>";
            }

            return
                context.Relationship;
        }
    }
}