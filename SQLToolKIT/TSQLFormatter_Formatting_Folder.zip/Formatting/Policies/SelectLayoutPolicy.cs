using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class SelectLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            if (!TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "SelectElements"))
            {
                return;
            }

            int queryBaseIndent =
                QueryIndentResolver.GetQueryBaseIndent(
                    context.Node,
                    layoutContext);

            int elementIndent =
                queryBaseIndent + 1;

            int index =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            /*
             * First SELECT element.
             */
            if (index == 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    elementIndent,
                    "SelectLayoutPolicy",
                    context);

                return;
            }

            /*
             * Leading-comma SELECT style.
             *
             * The comma is the visual start of each subsequent
             * SELECT element.
             */
            int commaIndex =
                layoutContext.TokenNavigator
                    .FindPreviousToken(
                        context.Node.FirstTokenIndex,
                        TSqlTokenType.Comma);

            if (commaIndex < 0)
            {
                return;
            }

            layoutContext.AddInstruction(
                commaIndex,
                elementIndent,
                "SelectLayoutPolicy",
                context);

            /*
             * Comments are transparent to structural formatting.
             *
             * When no comment exists between the comma and the next
             * SELECT element, force the element to stay attached to
             * its leading comma:
             *
             *     ,RowNumber=...
             *
             * If a comment is physically between the comma and the
             * element, do not move or rewrite the comment. Token order
             * remains exactly as supplied by the developer.
             */
            if (!layoutContext.TokenNavigator
                    .HasCommentBetween(
                        commaIndex + 1,
                        context.Node.FirstTokenIndex - 1))
            {
                layoutContext.AddTightInstruction(
                    context.Node.FirstTokenIndex,
                    "SelectLayoutPolicy",
                    context);
            }
        }
    }
}
