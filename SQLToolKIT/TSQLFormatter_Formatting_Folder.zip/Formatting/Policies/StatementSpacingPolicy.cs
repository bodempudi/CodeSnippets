using Microsoft.SqlServer.TransactSql.ScriptDom;
using System.Linq;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    /*
     * Adds one empty line between different logical statement groups.
     *
     * The rule is family based, not keyword-by-keyword. Consecutive
     * statements in the same family remain together.
     */
    public sealed class StatementSpacingPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                context.Parent == null ||
                layoutContext == null)
            {
                return;
            }

            if (!(context.Parent is StatementList) ||
                !TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Statements"))
            {
                return;
            }

            int statementIndex =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (statementIndex <= 0)
            {
                return;
            }

            AstNodeContext previous =
                GetStatementSibling(
                    context.Parent,
                    statementIndex - 1,
                    layoutContext);

            if (previous == null ||
                previous.Node == null)
            {
                return;
            }

            StatementFamily previousFamily =
                GetFamily(
                    previous.Node);

            StatementFamily currentFamily =
                GetFamily(
                    context.Node);

            if (!ShouldSeparate(
                    previousFamily,
                    currentFamily))
            {
                return;
            }

            int indent =
                StatementIndentResolver
                    .GetStatementIndent(
                        context.Node,
                        layoutContext);

            layoutContext.AddBlankLineInstruction(
                context.Node.FirstTokenIndex,
                indent,
                "StatementSpacingPolicy",
                context);
        }

        private static AstNodeContext GetStatementSibling(
            TSqlFragment statementList,
            int statementIndex,
            LayoutContext layoutContext)
        {
            string relationship =
                "Statements[" +
                statementIndex +
                "]";

            return
                layoutContext.Walker
                    .GetChildren(
                        statementList)
                    .FirstOrDefault(
                        x =>
                            x != null &&
                            x.Node != null &&
                            x.Relationship == relationship);
        }

        private static bool ShouldSeparate(
            StatementFamily previous,
            StatementFamily current)
        {
            if (previous == StatementFamily.Unknown ||
                current == StatementFamily.Unknown ||
                previous == current)
            {
                return false;
            }

            /*
             * DECLARE is a clear logical section boundary.
             */
            if (previous == StatementFamily.Declaration ||
                current == StatementFamily.Declaration)
            {
                return true;
            }

            /*
             * SET/configuration statements remain grouped with other SETs,
             * but a transition to/from actual work is visually separated.
             */
            if (previous == StatementFamily.Set &&
                IsMajorWorkFamily(current))
            {
                return true;
            }

            if (IsMajorWorkFamily(previous) &&
                current == StatementFamily.Set)
            {
                return true;
            }

            /*
             * Query / DML / control-flow transitions are separate groups.
             */
            if (IsMajorWorkFamily(previous) &&
                IsMajorWorkFamily(current))
            {
                return true;
            }

            /*
             * Transaction-control statements form their own logical group.
             *
             * Examples:
             *
             *     BEGIN TRANSACTION;
             *
             *     ;WITH ...
             *
             * and:
             *
             *     SET @Result = 'SUCCESS';
             *
             *     COMMIT TRANSACTION;
             */
            if (previous == StatementFamily.Transaction &&
                IsWorkOrSetFamily(current))
            {
                return true;
            }

            if (IsWorkOrSetFamily(previous) &&
                current == StatementFamily.Transaction)
            {
                return true;
            }

            /*
             * Terminal propagation statements (THROW/RETURN) should be
             * isolated from the work that prepares their result/state.
             *
             *     SET @Result = @ErrorMessage;
             *
             *     THROW;
             */
            if (current == StatementFamily.Terminal &&
                previous != StatementFamily.Terminal)
            {
                return true;
            }

            if (previous == StatementFamily.Terminal &&
                current != StatementFamily.Terminal)
            {
                return true;
            }

            return false;
        }

        private static bool IsMajorWorkFamily(
            StatementFamily family)
        {
            return
                family == StatementFamily.Query ||
                family == StatementFamily.Dml ||
                family == StatementFamily.ControlFlow;
        }

        private static bool IsWorkOrSetFamily(
            StatementFamily family)
        {
            return
                IsMajorWorkFamily(family) ||
                family == StatementFamily.Set ||
                family == StatementFamily.Declaration;
        }

        private static StatementFamily GetFamily(
            TSqlFragment node)
        {
            string typeName =
                node.GetType().Name;

            switch (typeName)
            {
                case "DeclareVariableStatement":
                    return StatementFamily.Declaration;

                case "SetVariableStatement":
                case "PredicateSetStatement":
                    return StatementFamily.Set;

                case "SelectStatement":
                    return StatementFamily.Query;

                case "InsertStatement":
                case "UpdateStatement":
                case "DeleteStatement":
                case "MergeStatement":
                    return StatementFamily.Dml;

                case "IfStatement":
                case "WhileStatement":
                case "TryCatchStatement":
                    return StatementFamily.ControlFlow;

                case "BeginTransactionStatement":
                case "CommitTransactionStatement":
                case "RollbackTransactionStatement":
                    return StatementFamily.Transaction;

                case "ThrowStatement":
                case "ReturnStatement":
                    return StatementFamily.Terminal;

                default:
                    return StatementFamily.Unknown;
            }
        }

        private enum StatementFamily
        {
            Unknown,
            Set,
            Declaration,
            Query,
            Dml,
            ControlFlow,
            Transaction,
            Terminal
        }
    }
}
