using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class WindowLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            string parentType =
                context.Parent == null
                    ? string.Empty
                    : context.Parent.GetType().Name;

            if (TokenNavigator.IsIndexedRelationship(
                    context.Relationship,
                    "Partitions") &&
                string.Equals(
                    parentType,
                    "OverClause",
                    StringComparison.Ordinal))
            {
                ApplyPartitionItem(
                    context,
                    layoutContext);

                return;
            }

            if (context.Relationship ==
                    "OrderByClause" &&
                string.Equals(
                    parentType,
                    "OverClause",
                    StringComparison.Ordinal))
            {
                int indent =
                    ExpressionIndentResolver.GetExpressionBaseIndent(
                        context.Parent,
                        layoutContext) + 1;

                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    indent,
                    "WindowLayoutPolicy",
                    context);
            }
        }

        private static void ApplyPartitionItem(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int baseIndent =
                ExpressionIndentResolver.GetExpressionBaseIndent(
                    context.Parent,
                    layoutContext) + 1;

            int index =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (index <= 0)
            {
                int partitionIndex =
                    layoutContext.TokenNavigator
                        .FindTokenSequenceByTextBetween(
                            context.Parent.FirstTokenIndex,
                            context.Node.FirstTokenIndex,
                            "PARTITION",
                            "BY");

                if (partitionIndex >= 0)
                {
                    layoutContext.AddInstruction(
                        partitionIndex,
                        baseIndent,
                        "WindowLayoutPolicy",
                        context);
                }

                /*
                 * Keep the first PARTITION BY expression inline:
                 *
                 *     PARTITION BY a.CustomerId
                 *
                 * Do not create a newline before the first item.
                 */
                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    baseIndent + 1,
                    "WindowLayoutPolicy",
                    context);
            }
        }
    }
}
