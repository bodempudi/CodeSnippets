using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;

namespace NotepadPlusPlusPlugin.Formatting.Policies
{
    public sealed class IndexLayoutPolicy :
        ILayoutPolicy
    {
        public void Apply(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            if (context == null ||
                context.Node == null ||
                layoutContext == null)
            {
                return;
            }

            if (context.Parent != null &&
                IsIndexOwner(
                    context.Parent.GetType().Name))
            {
                if (TokenNavigator.IsIndexedRelationship(
                        context.Relationship,
                        "Columns") ||
                    TokenNavigator.IsIndexedRelationship(
                        context.Relationship,
                        "IncludeColumns"))
                {
                    ApplyCommaLeadingItem(
                        context,
                        layoutContext);

                    return;
                }
            }

            string nodeType =
                context.Node.GetType().Name;

            if (!IsIndexOwner(nodeType))
            {
                return;
            }

            int baseIndent =
                StatementIndentResolver.GetStatementIndent(
                    context.Node,
                    layoutContext);

            AddKeywordIfPresent(
                context,
                layoutContext,
                "INCLUDE",
                baseIndent);

            AddKeywordIfPresent(
                context,
                layoutContext,
                "WHERE",
                baseIndent);

            AddKeywordIfPresent(
                context,
                layoutContext,
                "WITH",
                baseIndent);
        }

        private static bool IsIndexOwner(
            string typeName)
        {
            if (string.IsNullOrEmpty(typeName))
            {
                return false;
            }

            return
                typeName.IndexOf(
                    "Index",
                    StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void ApplyCommaLeadingItem(
            AstNodeContext context,
            LayoutContext layoutContext)
        {
            int indent =
                StatementIndentResolver.GetStatementIndent(
                    context.Parent,
                    layoutContext) + 1;

            int index =
                TokenNavigator.GetRelationshipIndex(
                    context.Relationship);

            if (index <= 0)
            {
                layoutContext.AddInstruction(
                    context.Node.FirstTokenIndex,
                    indent,
                    "IndexLayoutPolicy",
                    context);

                return;
            }

            int commaIndex =
                layoutContext.TokenNavigator.FindPreviousToken(
                    context.Node.FirstTokenIndex,
                    TSqlTokenType.Comma);

            if (commaIndex >= 0)
            {
                layoutContext.AddInstruction(
                    commaIndex,
                    indent,
                    "IndexLayoutPolicy",
                    context);
            }
        }

        private static void AddKeywordIfPresent(
            AstNodeContext context,
            LayoutContext layoutContext,
            string keyword,
            int indent)
        {
            int index =
                layoutContext.TokenNavigator
                    .FindMeaningfulTokenByTextBetween(
                        context.Node.FirstTokenIndex,
                        context.Node.LastTokenIndex,
                        keyword);

            if (index >= 0)
            {
                layoutContext.AddInstruction(
                    index,
                    indent,
                    "IndexLayoutPolicy",
                    context);
            }
        }
    }
}
