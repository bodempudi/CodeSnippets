@echo off
setlocal

set "DLL=%~dp0bin\Release\OurNppPlugin.dll"
if not exist "%DLL%" (
    echo Plugin DLL not found:
    echo %DLL%
    echo Build Release x64 first.
    exit /b 1
)

set /p "NPPDIR=Enter Notepad++ installation folder (example C:\Program Files\Notepad++): "
if not exist "%NPPDIR%\notepad++.exe" (
    echo notepad++.exe was not found in that folder.
    exit /b 1
)

set "PLUGINDIR=%NPPDIR%\plugins\OurNppPlugin"
if not exist "%PLUGINDIR%" mkdir "%PLUGINDIR%"
copy /Y "%DLL%" "%PLUGINDIR%\OurNppPlugin.dll" >nul
if errorlevel 1 (
    echo Copy failed. Try running this file as Administrator if Notepad++ is under Program Files.
    exit /b 1
)

echo.
echo Installed to:
echo %PLUGINDIR%\OurNppPlugin.dll
echo.
echo Restart Notepad++ and open Plugins ^> Our NPP Plugin ^> Hello World.
endlocal
