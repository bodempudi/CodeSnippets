@echo off
setlocal

where msbuild >nul 2>&1
if errorlevel 1 (
    echo MSBuild was not found in PATH.
    echo Open "Developer Command Prompt for VS 2019" and run this file again.
    exit /b 1
)

msbuild OurNppPlugin.sln /t:Rebuild /p:Configuration=Release /p:Platform=x64 /m
if errorlevel 1 exit /b 1

echo.
echo Build succeeded.
echo DLL: %~dp0bin\Release\OurNppPlugin.dll
endlocal
