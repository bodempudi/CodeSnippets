OUR NPP PLUGIN - V0.1 HELLO WORLD
=================================

Goal
----
Prove that our own x64 Notepad++ plugin DLL loads and executes a command.
No NuGet packages. No ScriptDom. No downloaded Notepad++ plugin framework.

Requirements on the development machine
---------------------------------------
1. Visual Studio 2019
2. "Desktop development with C++" workload installed
3. Windows 10 SDK available through Visual Studio
4. 64-bit Notepad++

Build
-----
1. Open OurNppPlugin.sln in Visual Studio 2019.
2. Select: Release | x64
3. Build -> Build Solution

Output
------
bin\Release\OurNppPlugin.dll

Install manually
----------------
Close Notepad++.
Create this folder under your Notepad++ installation:

    plugins\OurNppPlugin\

Copy:

    bin\Release\OurNppPlugin.dll

to:

    plugins\OurNppPlugin\OurNppPlugin.dll

The folder name and DLL base name intentionally match.

Test
----
1. Start Notepad++.
2. Open Plugins.
3. Find "Our NPP Plugin".
4. Click "Hello World".
5. Expected message:

   Hello World from our own Notepad++ plugin!

What V0.1 proves
----------------
- x64 DLL is accepted by Notepad++.
- Required plugin exports are present.
- Plugin menu registration works.
- Notepad++ can invoke our command callback.

Intentionally NOT included yet
------------------------------
- ScriptDom
- SQL parsing
- SQL formatter
- SQL review
- editor text reading/writing
- C# managed core

Why start this small?
---------------------
If this version fails to appear in Plugins, the problem is purely plugin loading/build/deployment.
There is no ScriptDom or managed dependency involved, so troubleshooting stays simple.

Next milestone
--------------
After V0.1 works, add editor access (read selected/current SQL text). Then add our C# .NET Framework 4.7.2 SQL core as a separate layer and only after that introduce ScriptDom.
