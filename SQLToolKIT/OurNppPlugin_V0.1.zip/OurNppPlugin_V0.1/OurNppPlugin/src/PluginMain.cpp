#include "PluginMain.h"

#include <cwchar>

namespace
{
    constexpr wchar_t PLUGIN_NAME[] = L"Our NPP Plugin";

    NppData g_nppData{};
    FuncItem g_commands[OurNppPlugin::CommandCount]{};

    void SetCommand(
        const int index,
        const wchar_t* commandName,
        const PFUNCPLUGINCMD function,
        ShortcutKey* shortcut = nullptr,
        const bool initiallyChecked = false)
    {
        if (index < 0 || index >= OurNppPlugin::CommandCount || commandName == nullptr)
        {
            return;
        }

        wcsncpy_s(
            g_commands[index]._itemName,
            NPP_PLUGIN_MENU_ITEM_LENGTH,
            commandName,
            _TRUNCATE);

        g_commands[index]._pFunc = function;
        g_commands[index]._cmdID = 0; // Notepad++ fills this after loading the plugin.
        g_commands[index]._init2Check = initiallyChecked;
        g_commands[index]._pShKey = shortcut;
    }
}

namespace OurNppPlugin
{
    void InitializeCommands()
    {
        SetCommand(0, L"Hello World", HelloWorld);
    }

    void HelloWorld()
    {
        MessageBoxW(
            g_nppData._nppHandle,
            L"Hello World from our own Notepad++ plugin!",
            L"Our NPP Plugin",
            MB_OK | MB_ICONINFORMATION);
    }
}

BOOL APIENTRY DllMain(HMODULE, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        OurNppPlugin::InitializeCommands();
    }

    return TRUE;
}

extern "C" __declspec(dllexport) void setInfo(NppData notepadPlusData)
{
    g_nppData = notepadPlusData;
}

extern "C" __declspec(dllexport) const wchar_t* getName()
{
    return PLUGIN_NAME;
}

extern "C" __declspec(dllexport) FuncItem* getFuncsArray(int* numberOfFunctions)
{
    if (numberOfFunctions != nullptr)
    {
        *numberOfFunctions = OurNppPlugin::CommandCount;
    }

    return g_commands;
}

extern "C" __declspec(dllexport) void beNotified(SCNotification*)
{
    // V0.1 does not process Notepad++/Scintilla notifications.
}

extern "C" __declspec(dllexport) LRESULT messageProc(UINT, WPARAM, LPARAM)
{
    return TRUE;
}

extern "C" __declspec(dllexport) BOOL isUnicode()
{
    return TRUE;
}
