#pragma once

#include "PluginInterface.h"

namespace OurNppPlugin
{
    constexpr int CommandCount = 1;

    void InitializeCommands();
    void HelloWorld();
}
