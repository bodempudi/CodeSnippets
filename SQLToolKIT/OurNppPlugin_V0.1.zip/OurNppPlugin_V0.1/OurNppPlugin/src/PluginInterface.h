#pragma once

#include <windows.h>

// Minimal subset of the Notepad++ plugin interface required for V0.1.
// We intentionally keep this file small; no Scintilla SDK is required yet.

constexpr int NPP_PLUGIN_MENU_ITEM_LENGTH = 64;

typedef void(__cdecl* PFUNCPLUGINCMD)();

struct NppData
{
    HWND _nppHandle;
    HWND _scintillaMainHandle;
    HWND _scintillaSecondHandle;
};

struct ShortcutKey
{
    bool _isCtrl;
    bool _isAlt;
    bool _isShift;
    UCHAR _key;
};

struct FuncItem
{
    wchar_t _itemName[NPP_PLUGIN_MENU_ITEM_LENGTH];
    PFUNCPLUGINCMD _pFunc;
    int _cmdID;
    bool _init2Check;
    ShortcutKey* _pShKey;
};

// We do not inspect notifications in V0.1, so an opaque declaration is enough.
struct SCNotification;
