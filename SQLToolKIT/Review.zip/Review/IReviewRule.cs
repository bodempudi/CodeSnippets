﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScriptFormatter.Core.Review
{
    namespace ScriptFormatter.Core.Review
    {
        public interface IReviewRule
        {
            string RuleId { get; }

            ReviewSeverity Severity { get; }

            IEnumerable<ReviewFinding> Review(
                SqlReviewContext context);
        }
    }
}
