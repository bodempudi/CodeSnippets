﻿namespace ScriptFormatter.Core.Review.Models
{
    public sealed class SqlResultInfo
    {
        public string Source { get; set; }

        public string Severity { get; set; }

        public int Line { get; set; }

        public int Column { get; set; }

        public string Message { get; set; }

        public int StartOffset { get; set; }

        public int Length { get; set; }
    }
}