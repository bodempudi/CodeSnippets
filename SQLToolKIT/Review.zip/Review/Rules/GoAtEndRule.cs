﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class GoAtEndRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0032"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var findings =
                new List<ReviewFinding>();

            if (context == null ||
                context.Fragment == null)
            {
                return findings;
            }

            IList<TSqlParserToken> tokens =
                context.Fragment.ScriptTokenStream;

            if (tokens == null ||
                tokens.Count == 0)
            {
                return findings;
            }

            TSqlParserToken lastToken =
                GetLastMeaningfulToken(
                    tokens);

            if (lastToken == null)
            {
                return findings;
            }

            if (lastToken.TokenType ==
                TSqlTokenType.Go)
            {
                return findings;
            }

            findings.Add(
                CreateFinding(
                    lastToken,
                    "SQL script should end with GO."));

            return findings;
        }

        private static TSqlParserToken GetLastMeaningfulToken(
            IList<TSqlParserToken> tokens)
        {
            for (int i = tokens.Count - 1;
                i >= 0;
                i--)
            {
                TSqlParserToken token =
                    tokens[i];

                if (token == null)
                {
                    continue;
                }

                if (token.TokenType ==
                    TSqlTokenType.EndOfFile)
                {
                    continue;
                }

                if (token.TokenType ==
                    TSqlTokenType.WhiteSpace)
                {
                    continue;
                }

                if (token.TokenType ==
                    TSqlTokenType.SingleLineComment)
                {
                    continue;
                }

                if (token.TokenType ==
                    TSqlTokenType.MultilineComment)
                {
                    continue;
                }

                return token;
            }

            return null;
        }
    }
}