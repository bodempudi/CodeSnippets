﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.Analysis;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class ColumnQualificationRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0012"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Error; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly ColumnQualificationRule _rule;
            private int _joinedQueryDepth;

            public Visitor(
                ColumnQualificationRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void ExplicitVisit(
                QuerySpecification node)
            {
                bool hasJoin =
                    FragmentHelper.ContainsJoin(
                        node.FromClause);

                if (hasJoin)
                {
                    _joinedQueryDepth++;
                }

                node.AcceptChildren(this);

                if (hasJoin)
                {
                    _joinedQueryDepth--;
                }
            }

            public override void Visit(
                ColumnReferenceExpression node)
            {
                if (_joinedQueryDepth == 0 ||
                    node.MultiPartIdentifier == null)
                {
                    return;
                }

                if (node.MultiPartIdentifier
                        .Identifiers.Count > 1)
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Column should be qualified with table alias when JOIN is used."));
            }
        }
    }
}