﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class BeginTryAfterAsRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0031"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor =
                new Visitor(this);

            context.Fragment.Accept(
                visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly BeginTryAfterAsRule _rule;

            public Visitor(
                BeginTryAfterAsRule rule)
            {
                _rule =
                    rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                CreateProcedureStatement node)
            {
                ReviewProcedure(
                    node.StatementList,
                    node);
            }

            public override void Visit(
                AlterProcedureStatement node)
            {
                ReviewProcedure(
                    node.StatementList,
                    node);
            }

            private void ReviewProcedure(
                StatementList statementList,
                TSqlFragment procedure)
            {
                if (statementList == null ||
                    statementList.Statements == null ||
                    statementList.Statements.Count == 0)
                {
                    Findings.Add(
                        _rule.CreateFinding(
                            procedure,
                            "Stored procedure should start with BEGIN TRY after AS."));

                    return;
                }

                TSqlStatement firstStatement =
                    statementList.Statements[0];

                if (firstStatement
                    is TryCatchStatement)
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        firstStatement,
                        "Stored procedure should start with BEGIN TRY after AS."));
            }
        }
    }
}