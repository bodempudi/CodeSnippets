﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.Analysis;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class NoLockRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0001"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            //
            // PASS 1:
            // Collect all CTE names first.
            //
            var cteCollector =
                new CteNameCollector();

            context.Fragment.Accept(
                cteCollector);

            //
            // PASS 2:
            // Validate physical read tables.
            //
            var visitor =
                new Visitor(
                    this,
                    cteCollector.CteNames);

            context.Fragment.Accept(
                visitor);

            return visitor.Findings;
        }

        private sealed class CteNameCollector
            : TSqlFragmentVisitor
        {
            public CteNameCollector()
            {
                CteNames =
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);
            }

            public HashSet<string> CteNames
            {
                get;
                private set;
            }

            public override void Visit(
                WithCtesAndXmlNamespaces node)
            {
                if (node == null ||
                    node.CommonTableExpressions == null)
                {
                    return;
                }

                foreach (
                    CommonTableExpression cte
                    in node.CommonTableExpressions)
                {
                    if (cte == null ||
                        cte.ExpressionName == null)
                    {
                        continue;
                    }

                    string cteName =
                        cte.ExpressionName.Value;

                    if (string.IsNullOrWhiteSpace(
                            cteName))
                    {
                        continue;
                    }

                    CteNames.Add(
                        cteName);
                }
            }
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly NoLockRule _rule;

            private readonly HashSet<string>
                _cteNames;

            public Visitor(
                NoLockRule rule,
                HashSet<string> cteNames)
            {
                _rule =
                    rule;

                _cteNames =
                    cteNames ??
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            //
            // SELECT
            //
            public override void Visit(
                QuerySpecification node)
            {
                if (node == null)
                {
                    return;
                }

                CheckReadTables(
                    node.FromClause,
                    null);
            }

            //
            // UPDATE
            //
            public override void Visit(
                UpdateSpecification node)
            {
                if (node == null)
                {
                    return;
                }

                CheckReadTables(
                    node.FromClause,
                    node.Target);
            }

            //
            // DELETE
            //
            public override void Visit(
                DeleteSpecification node)
            {
                if (node == null)
                {
                    return;
                }

                CheckReadTables(
                    node.FromClause,
                    node.Target);
            }

            //
            // MERGE
            //
            // Target does not require NOLOCK.
            // USING source does.
            //
            public override void Visit(
                MergeSpecification node)
            {
                if (node == null)
                {
                    return;
                }

                CheckMergeSource(
                    node.TableReference);
            }

            private void CheckReadTables(
                FromClause fromClause,
                TableReference modificationTarget)
            {
                if (fromClause == null)
                {
                    return;
                }

                foreach (
                    NamedTableReference table
                    in TableReferenceAnalyzer
                        .GetNamedTables(
                            fromClause))
                {
                    if (ShouldIgnoreTable(
                            table))
                    {
                        continue;
                    }

                    if (TableReferenceAnalyzer
                        .IsModificationTarget(
                            modificationTarget,
                            table))
                    {
                        continue;
                    }

                    AddFindingIfNoLockMissing(
                        table);
                }
            }

            private void CheckMergeSource(
                TableReference source)
            {
                if (source == null)
                {
                    return;
                }

                foreach (
                    NamedTableReference table
                    in TableReferenceAnalyzer
                        .GetNamedTables(
                            source))
                {
                    if (ShouldIgnoreTable(
                            table))
                    {
                        continue;
                    }

                    AddFindingIfNoLockMissing(
                        table);
                }
            }

            private void AddFindingIfNoLockMissing(
                NamedTableReference table)
            {
                if (table == null)
                {
                    return;
                }

                if (TableReferenceAnalyzer
                    .HasNoLock(
                        table))
                {
                    return;
                }

                string tableName =
                    TableReferenceAnalyzer
                        .GetFullName(
                            table);

                Findings.Add(
                    _rule.CreateFinding(
                        table,
                        "NOLOCK missing: " +
                        tableName));
            }

            private bool ShouldIgnoreTable(
                NamedTableReference table)
            {
                if (table == null)
                {
                    return true;
                }

                if (IsCteReference(
                        table))
                {
                    return true;
                }

                if (IsTemporaryTable(
                        table))
                {
                    return true;
                }

                return false;
            }

            private bool IsCteReference(
                NamedTableReference table)
            {
                if (table == null ||
                    table.SchemaObject == null)
                {
                    return false;
                }

                if (table.SchemaObject
                        .Identifiers.Count != 1)
                {
                    return false;
                }

                string tableName =
                    table.SchemaObject
                        .Identifiers[0]
                        .Value;

                if (string.IsNullOrWhiteSpace(
                        tableName))
                {
                    return false;
                }

                return _cteNames.Contains(
                    tableName);
            }

            private static bool IsTemporaryTable(
                NamedTableReference table)
            {
                if (table == null ||
                    table.SchemaObject == null ||
                    table.SchemaObject
                        .BaseIdentifier == null)
                {
                    return false;
                }

                string tableName =
                    table.SchemaObject
                        .BaseIdentifier
                        .Value;

                if (string.IsNullOrWhiteSpace(
                        tableName))
                {
                    return false;
                }

                return tableName.StartsWith(
                    "#",
                    StringComparison.Ordinal);
            }
        }
    }
}