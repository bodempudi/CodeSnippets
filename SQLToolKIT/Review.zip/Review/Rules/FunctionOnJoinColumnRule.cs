﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class FunctionOnJoinColumnRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0024"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly FunctionOnJoinColumnRule _rule;

            public Visitor(
                FunctionOnJoinColumnRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                QualifiedJoin node)
            {
                if (node.SearchCondition == null)
                {
                    return;
                }

                var functionVisitor =
                    new FunctionVisitor();

                node.SearchCondition.Accept(
                    functionVisitor);

                foreach (FunctionCall function
                    in functionVisitor.Functions)
                {
                    if (!ContainsColumn(function))
                    {
                        continue;
                    }

                    Findings.Add(
                        _rule.CreateFinding(
                            function,
                            "Function applied to a column in JOIN predicate may prevent efficient index usage."));
                }
            }

            private static bool ContainsColumn(
                TSqlFragment fragment)
            {
                var visitor =
                    new ColumnVisitor();

                fragment.Accept(visitor);

                return visitor.Found;
            }
        }

        private sealed class FunctionVisitor
            : TSqlFragmentVisitor
        {
            public FunctionVisitor()
            {
                Functions =
                    new List<FunctionCall>();
            }

            public IList<FunctionCall> Functions
            {
                get;
                private set;
            }

            public override void Visit(
                FunctionCall node)
            {
                Functions.Add(node);
            }
        }

        private sealed class ColumnVisitor
            : TSqlFragmentVisitor
        {
            public bool Found
            {
                get;
                private set;
            }

            public override void Visit(
                ColumnReferenceExpression node)
            {
                Found = true;
            }
        }
    }
}