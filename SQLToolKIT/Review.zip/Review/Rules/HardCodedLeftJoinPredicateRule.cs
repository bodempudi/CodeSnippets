﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class LeftJoinFilterPredicateRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0023"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly LeftJoinFilterPredicateRule _rule;

            public Visitor(
                LeftJoinFilterPredicateRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                QuerySpecification node)
            {
                var leftJoinVisitor =
                    new LeftJoinVisitor();

                if (node.FromClause != null)
                {
                    node.FromClause.Accept(
                        leftJoinVisitor);
                }

                //
                // PART 1
                // Filter predicates inside LEFT JOIN ON.
                //
                foreach (QualifiedJoin join
                    in leftJoinVisitor.LeftJoins)
                {
                    ReviewJoinOnClause(join);
                }

                //
                // PART 2
                // WHERE predicates referencing
                // right-side LEFT JOIN aliases.
                //
                if (node.WhereClause == null)
                {
                    return;
                }

                var rightAliases =
                    leftJoinVisitor.LeftJoins
                        .Select(GetRightSideAlias)
                        .Where(x =>
                            !string.IsNullOrWhiteSpace(x))
                        .ToList();

                if (rightAliases.Count == 0)
                {
                    return;
                }

                var whereVisitor =
                    new WherePredicateVisitor(
                        rightAliases);

                node.WhereClause.SearchCondition.Accept(
                    whereVisitor);

                foreach (TSqlFragment predicate
                    in whereVisitor.Predicates)
                {
                    Findings.Add(
                        _rule.CreateFinding(
                            predicate,
                            "WHERE condition references a LEFT JOIN table and may change LEFT JOIN behavior. Review whether the condition belongs in ON or whether INNER JOIN was intended."));
                }
            }

            private void ReviewJoinOnClause(
                QualifiedJoin join)
            {
                if (join.SearchCondition == null)
                {
                    return;
                }

                var predicateVisitor =
                    new OnFilterPredicateVisitor();

                join.SearchCondition.Accept(
                    predicateVisitor);

                foreach (BooleanComparisonExpression predicate
                    in predicateVisitor.Predicates)
                {
                    Findings.Add(
                        _rule.CreateFinding(
                            predicate,
                            "LEFT JOIN ON contains a filter predicate. Review whether the condition belongs in ON or WHERE."));
                }
            }

            private static string GetRightSideAlias(
                QualifiedJoin join)
            {
                var tableWithAlias =
                    join.SecondTableReference
                        as TableReferenceWithAlias;

                if (tableWithAlias == null ||
                    tableWithAlias.Alias == null)
                {
                    return null;
                }

                return tableWithAlias.Alias.Value;
            }
        }

        private sealed class LeftJoinVisitor
            : TSqlFragmentVisitor
        {
            public LeftJoinVisitor()
            {
                LeftJoins =
                    new List<QualifiedJoin>();
            }

            public IList<QualifiedJoin> LeftJoins
            {
                get;
                private set;
            }

            public override void Visit(
                QualifiedJoin node)
            {
                if (node.QualifiedJoinType ==
                    QualifiedJoinType.LeftOuter)
                {
                    LeftJoins.Add(node);
                }
            }
        }

        private sealed class OnFilterPredicateVisitor
            : TSqlFragmentVisitor
        {
            public OnFilterPredicateVisitor()
            {
                Predicates =
                    new List<BooleanComparisonExpression>();
            }

            public IList<BooleanComparisonExpression> Predicates
            {
                get;
                private set;
            }

            public override void Visit(
                BooleanComparisonExpression node)
            {
                bool firstIsColumn =
                    node.FirstExpression
                        is ColumnReferenceExpression;

                bool secondIsColumn =
                    node.SecondExpression
                        is ColumnReferenceExpression;

                //
                // column = column
                // Normal JOIN relationship.
                //
                if (firstIsColumn &&
                    secondIsColumn)
                {
                    return;
                }

                //
                // column = literal
                // column = variable
                // column = expression
                //
                if (firstIsColumn ||
                    secondIsColumn)
                {
                    Predicates.Add(node);
                }
            }
        }

        private sealed class WherePredicateVisitor
            : TSqlFragmentVisitor
        {
            private readonly IList<string> _rightAliases;

            public WherePredicateVisitor(
                IList<string> rightAliases)
            {
                _rightAliases = rightAliases;

                Predicates =
                    new List<TSqlFragment>();
            }

            public IList<TSqlFragment> Predicates
            {
                get;
                private set;
            }

            public override void Visit(
                BooleanComparisonExpression node)
            {
                if (ReferencesRightAlias(
                    node))
                {
                    Predicates.Add(node);
                }
            }

            public override void Visit(
                BooleanIsNullExpression node)
            {
                //
                // WHERE a.Id IS NULL
                //
                // This is often intentional anti-join logic,
                // so do not flag it.
                //
                if (!node.IsNot)
                {
                    return;
                }

                //
                // WHERE a.Id IS NOT NULL
                // removes unmatched LEFT JOIN rows.
                //
                if (ReferencesRightAlias(
                    node))
                {
                    Predicates.Add(node);
                }
            }

            private bool ReferencesRightAlias(
                TSqlFragment fragment)
            {
                var visitor =
                    new ColumnAliasVisitor(
                        _rightAliases);

                fragment.Accept(visitor);

                return visitor.Found;
            }
        }

        private sealed class ColumnAliasVisitor
            : TSqlFragmentVisitor
        {
            private readonly IList<string> _aliases;

            public ColumnAliasVisitor(
                IList<string> aliases)
            {
                _aliases = aliases;
            }

            public bool Found
            {
                get;
                private set;
            }

            public override void Visit(
                ColumnReferenceExpression node)
            {
                if (node.MultiPartIdentifier == null ||
                    node.MultiPartIdentifier.Identifiers.Count < 2)
                {
                    return;
                }

                string alias =
                    node.MultiPartIdentifier
                        .Identifiers[
                            node.MultiPartIdentifier
                                .Identifiers.Count - 2]
                        .Value;

                if (_aliases.Any(
                    x => string.Equals(
                        x,
                        alias,
                        StringComparison.OrdinalIgnoreCase)))
                {
                    Found = true;
                }
            }
        }
    }
}