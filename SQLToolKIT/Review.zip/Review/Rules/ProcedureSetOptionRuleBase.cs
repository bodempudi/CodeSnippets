﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public abstract class ProcedureSetOptionRuleBase
        : ReviewRuleBase
    {
        protected abstract SetOptions RequiredOption
        {
            get;
        }

        protected abstract string ErrorMessage
        {
            get;
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor =
                new Visitor(this);

            context.Fragment.Accept(
                visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly ProcedureSetOptionRuleBase _rule;

            public Visitor(
                ProcedureSetOptionRuleBase rule)
            {
                _rule =
                    rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                CreateProcedureStatement node)
            {
                CheckProcedure(
                    node);
            }

            public override void Visit(
                AlterProcedureStatement node)
            {
                CheckProcedure(
                    node);
            }

            public override void Visit(
                CreateOrAlterProcedureStatement node)
            {
                CheckProcedure(
                    node);
            }

            private void CheckProcedure(
                ProcedureStatementBodyBase procedure)
            {
                if (procedure == null ||
                    procedure.StatementList == null)
                {
                    return;
                }

                StatementList statementsToCheck =
                    GetStatementsToCheck(
                        procedure.StatementList);

                if (HasRequiredOption(
                        statementsToCheck))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        procedure,
                        _rule.ErrorMessage));
            }

            private static StatementList GetStatementsToCheck(
                StatementList procedureStatements)
            {
                if (procedureStatements == null ||
                    procedureStatements.Statements == null ||
                    procedureStatements.Statements.Count == 0)
                {
                    return null;
                }

                //
                // Team standard:
                //
                // AS
                // BEGIN TRY
                //     SET NOCOUNT ON;
                //     SET XACT_ABORT ON;
                //     ...
                // END TRY
                // BEGIN CATCH
                //     ...
                // END CATCH
                //
                TryCatchStatement tryCatch =
                    procedureStatements.Statements[0]
                        as TryCatchStatement;

                if (tryCatch != null &&
                    tryCatch.TryStatements != null)
                {
                    return tryCatch.TryStatements;
                }

                //
                // Fallback:
                // keep checking the procedure body.
                //
                // SQLR0030 separately reports when
                // BEGIN TRY does not immediately follow AS.
                //
                return procedureStatements;
            }

            private bool HasRequiredOption(
                StatementList statements)
            {
                if (statements == null)
                {
                    return false;
                }

                bool isOn =
                    false;

                foreach (
                    TSqlStatement statement
                    in statements.Statements)
                {
                    PredicateSetStatement setStatement =
                        statement as PredicateSetStatement;

                    if (setStatement == null)
                    {
                        continue;
                    }

                    if ((setStatement.Options &
                         _rule.RequiredOption) !=
                        _rule.RequiredOption)
                    {
                        continue;
                    }

                    //
                    // If the same option appears more than once,
                    // respect its final state.
                    //
                    isOn =
                        setStatement.IsOn;
                }

                return isOn;
            }
        }
    }
}