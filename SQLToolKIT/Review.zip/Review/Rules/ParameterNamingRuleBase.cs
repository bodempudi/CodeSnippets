﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public abstract class ParameterNamingRuleBase
        : ReviewRuleBase
    {
        protected abstract string Prefix
        {
            get;
        }

        protected abstract bool IsApplicable(
            ProcedureParameter parameter);

        protected abstract string ErrorMessage
        {
            get;
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor =
                new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly ParameterNamingRuleBase _rule;

            public Visitor(
                ParameterNamingRuleBase rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                ProcedureParameter node)
            {
                if (!_rule.IsApplicable(node) ||
                    node.VariableName == null)
                {
                    return;
                }

                string name =
                    node.VariableName.Value;

                if (name.StartsWith(
                        "@" + _rule.Prefix,
                        StringComparison.Ordinal))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node.VariableName,
                        _rule.ErrorMessage));
            }
        }
    }
}