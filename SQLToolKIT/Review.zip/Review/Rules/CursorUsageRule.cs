﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class CursorUsageRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0021"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly CursorUsageRule _rule;

            public Visitor(
                CursorUsageRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                DeclareCursorStatement node)
            {
                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Cursor usage detected. Review whether set-based processing can be used."));
            }
        }
    }
}