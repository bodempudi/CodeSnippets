﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class DataTypeCaseRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0010"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly DataTypeCaseRule _rule;

            public Visitor(
                DataTypeCaseRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                SqlDataTypeReference node)
            {
                if (node.ScriptTokenStream == null ||
                    node.FirstTokenIndex < 0)
                {
                    return;
                }

                TSqlParserToken token =
                    node.ScriptTokenStream[
                        node.FirstTokenIndex];

                string text =
                    token.Text;

                if (text ==
                    text.ToUpperInvariant())
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Datatype should be uppercase: " +
                        text));
            }
        }
    }
}