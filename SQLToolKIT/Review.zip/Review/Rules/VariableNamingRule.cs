﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class VariableNamingRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0016"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor =
                new Visitor(this);

            context.Fragment.Accept(
                visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly VariableNamingRule _rule;

            public Visitor(
                VariableNamingRule rule)
            {
                _rule =
                    rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                DeclareVariableElement node)
            {
                if (node == null ||
                    node.VariableName == null)
                {
                    return;
                }

                //
                // ProcedureParameter inherits from
                // DeclareVariableElement in ScriptDom.
                //
                // Procedure parameters are handled by:
                //
                // SQLR0017 - Input parameter naming
                // SQLR0018 - Output parameter naming
                //
                if (node is ProcedureParameter)
                {
                    return;
                }

                string variableName =
                    node.VariableName.Value;

                if (string.IsNullOrWhiteSpace(
                        variableName))
                {
                    return;
                }

                if (variableName.StartsWith(
                        "@V_",
                        StringComparison.Ordinal))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node.VariableName,
                        "Local variable must start with V_."));
            }
        }
    }
}