﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class NullComparisonRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0004"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Error; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly NullComparisonRule _rule;

            public Visitor(
                NullComparisonRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                BooleanComparisonExpression node)
            {
                if (!(node.FirstExpression
                        is NullLiteral) &&
                    !(node.SecondExpression
                        is NullLiteral))
                {
                    return;
                }

                if (node.ComparisonType !=
                        BooleanComparisonType.Equals &&
                    node.ComparisonType !=
                        BooleanComparisonType.NotEqualToBrackets &&
                    node.ComparisonType !=
                        BooleanComparisonType.NotEqualToExclamation)
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Use IS NULL or IS NOT NULL instead of comparing with NULL."));
            }
        }
    }
}