﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class ImplicitJoinRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0011"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly ImplicitJoinRule _rule;

            public Visitor(
                ImplicitJoinRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                FromClause node)
            {
                if (node.TableReferences.Count <= 1)
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Avoid implicit comma joins. Use explicit JOIN syntax."));
            }
        }
    }
}