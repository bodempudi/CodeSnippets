﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class OrderByOrdinalRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0014"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly OrderByOrdinalRule _rule;

            public Visitor(
                OrderByOrdinalRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                ExpressionWithSortOrder node)
            {
                if (!(node.Expression
                        is IntegerLiteral))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Avoid ordinal position in ORDER BY."));
            }
        }
    }
}