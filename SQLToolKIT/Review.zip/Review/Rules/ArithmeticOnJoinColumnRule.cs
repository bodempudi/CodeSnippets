﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class ArithmeticOnJoinColumnRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0025"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly ArithmeticOnJoinColumnRule _rule;

            public Visitor(
                ArithmeticOnJoinColumnRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                QualifiedJoin node)
            {
                if (node.SearchCondition == null)
                {
                    return;
                }

                var arithmeticVisitor =
                    new ArithmeticVisitor();

                node.SearchCondition.Accept(
                    arithmeticVisitor);

                foreach (BinaryExpression expression
                    in arithmeticVisitor.Expressions)
                {
                    Findings.Add(
                        _rule.CreateFinding(
                            expression,
                            "Arithmetic operation on a column in JOIN predicate may prevent efficient index usage."));
                }
            }
        }

        private sealed class ArithmeticVisitor
            : TSqlFragmentVisitor
        {
            public ArithmeticVisitor()
            {
                Expressions =
                    new List<BinaryExpression>();
            }

            public IList<BinaryExpression> Expressions
            {
                get;
                private set;
            }

            public override void Visit(
                BinaryExpression node)
            {
                if (!IsArithmetic(node.BinaryExpressionType))
                {
                    return;
                }

                if (!ContainsColumn(node))
                {
                    return;
                }

                Expressions.Add(node);
            }

            private static bool IsArithmetic(
                BinaryExpressionType type)
            {
                return
                    type == BinaryExpressionType.Add ||
                    type == BinaryExpressionType.Subtract ||
                    type == BinaryExpressionType.Multiply ||
                    type == BinaryExpressionType.Divide ||
                    type == BinaryExpressionType.Modulo;
            }

            private static bool ContainsColumn(
                TSqlFragment fragment)
            {
                var visitor =
                    new ColumnVisitor();

                fragment.Accept(visitor);

                return visitor.Found;
            }
        }

        private sealed class ColumnVisitor
            : TSqlFragmentVisitor
        {
            public bool Found
            {
                get;
                private set;
            }

            public override void Visit(
                ColumnReferenceExpression node)
            {
                Found = true;
            }
        }
    }
}