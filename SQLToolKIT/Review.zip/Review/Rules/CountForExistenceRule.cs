﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class CountForExistenceRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0026"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly CountForExistenceRule _rule;

            public Visitor(
                CountForExistenceRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                BooleanComparisonExpression node)
            {
                if (IsCountGreaterThanZero(node) ||
                    IsCountAtLeastOne(node))
                {
                    Findings.Add(
                        _rule.CreateFinding(
                            node,
                            "COUNT used for existence check. Consider EXISTS."));
                }
            }

            private static bool IsCountGreaterThanZero(
                BooleanComparisonExpression node)
            {
                return
                    node.ComparisonType ==
                        BooleanComparisonType.GreaterThan &&
                    IsCountExpression(node.FirstExpression) &&
                    IsIntegerLiteral(
                        node.SecondExpression,
                        "0");
            }

            private static bool IsCountAtLeastOne(
                BooleanComparisonExpression node)
            {
                return
                    node.ComparisonType ==
                        BooleanComparisonType.GreaterThanOrEqualTo &&
                    IsCountExpression(node.FirstExpression) &&
                    IsIntegerLiteral(
                        node.SecondExpression,
                        "1");
            }

            private static bool IsCountExpression(
                ScalarExpression expression)
            {
                var scalarSubquery =
                    expression as ScalarSubquery;

                if (scalarSubquery == null)
                {
                    return false;
                }

                var querySpecification =
                    scalarSubquery.QueryExpression
                        as QuerySpecification;

                if (querySpecification == null ||
                    querySpecification.SelectElements.Count != 1)
                {
                    return false;
                }

                var selectScalar =
                    querySpecification.SelectElements[0]
                        as SelectScalarExpression;

                if (selectScalar == null)
                {
                    return false;
                }

                var functionCall =
                    selectScalar.Expression
                        as FunctionCall;

                if (functionCall == null ||
                    functionCall.FunctionName == null)
                {
                    return false;
                }

                string functionName =
                    functionCall.FunctionName.Value;

                return
                    string.Equals(
                        functionName,
                        "COUNT",
                        System.StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(
                        functionName,
                        "COUNT_BIG",
                        System.StringComparison.OrdinalIgnoreCase);
            }

            private static bool IsIntegerLiteral(
                ScalarExpression expression,
                string expectedValue)
            {
                var literal =
                    expression as IntegerLiteral;

                return
                    literal != null &&
                    literal.Value == expectedValue;
            }
        }
    }
}