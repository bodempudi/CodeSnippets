﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class SelectStarRule : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0002"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor =
                new SelectStarVisitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class SelectStarVisitor
            : TSqlFragmentVisitor
        {
            private readonly SelectStarRule _rule;

            public SelectStarVisitor(
                SelectStarRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                SelectStarExpression node)
            {
                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Avoid writing SELECT *, Specify required columns always!."));
            }
        }
    }
}