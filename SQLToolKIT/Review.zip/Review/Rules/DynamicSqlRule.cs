﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class DynamicSqlRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0033"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var findings =
                new List<ReviewFinding>();

            if (context == null ||
                context.Fragment == null)
            {
                return findings;
            }

            var visitor =
                new Visitor(
                    this);

            context.Fragment.Accept(
                visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly DynamicSqlRule _rule;

            public Visitor(
                DynamicSqlRule rule)
            {
                _rule =
                    rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                ExecuteStatement node)
            {
                if (node == null ||
                    node.ExecuteSpecification == null ||
                    node.ExecuteSpecification.ExecutableEntity == null)
                {
                    return;
                }

                ExecutableEntity executableEntity =
                    node.ExecuteSpecification.ExecutableEntity;

                if (!IsDynamicExecution(
                        executableEntity))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Dynamic SQL detected. Review parameterization, object qualification, injection, and generated query logic."));
            }

            private static bool IsDynamicExecution(
                ExecutableEntity executableEntity)
            {
                if (executableEntity == null)
                {
                    return false;
                }

                //
                // Examples:
                //
                // EXEC(@V_Sql)
                // EXEC(N'SELECT ...')
                // EXEC(@V_Sql) AT LinkedServer
                //
                if (executableEntity
                    is ExecutableStringList)
                {
                    return true;
                }

                //
                // Examples:
                //
                // EXEC @V_ProcedureName
                // EXEC sp_executesql @V_Sql
                // EXEC sys.sp_executesql @V_Sql
                //
                var procedureReference =
                    executableEntity
                        as ExecutableProcedureReference;

                if (procedureReference == null)
                {
                    return false;
                }

                if (IsProcedureVariable(
                        procedureReference))
                {
                    return true;
                }

                return IsSpExecuteSql(
                    procedureReference);
            }

            private static bool IsProcedureVariable(
                ExecutableProcedureReference procedureReference)
            {
                if (procedureReference == null ||
                    procedureReference.ProcedureReference == null)
                {
                    return false;
                }

                return procedureReference
                           .ProcedureReference
                           .ProcedureVariable != null;
            }

            private static bool IsSpExecuteSql(
                ExecutableProcedureReference procedureReference)
            {
                string procedureName =
                    GetProcedureName(
                        procedureReference);

                return string.Equals(
                    procedureName,
                    "sp_executesql",
                    StringComparison.OrdinalIgnoreCase);
            }

            private static string GetProcedureName(
                ExecutableProcedureReference procedureReference)
            {
                if (procedureReference == null ||
                    procedureReference.ProcedureReference == null ||
                    procedureReference
                        .ProcedureReference
                        .ProcedureReference == null ||
                    procedureReference
                        .ProcedureReference
                        .ProcedureReference
                        .Name == null)
                {
                    return null;
                }

                SchemaObjectName objectName =
                    procedureReference
                        .ProcedureReference
                        .ProcedureReference
                        .Name;

                if (objectName.Identifiers == null ||
                    objectName.Identifiers.Count == 0)
                {
                    return null;
                }

                return objectName
                    .Identifiers
                    .Last()
                    .Value;
            }
        }
    }
}