﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class OutputParameterNamingRule
        : ParameterNamingRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0018"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        protected override string Prefix
        {
            get { return "O_"; }
        }

        protected override string ErrorMessage
        {
            get
            {
                return "Output parameter must start with O_.";
            }
        }

        protected override bool IsApplicable(
            ProcedureParameter parameter)
        {
            return parameter.Modifier ==
                   ParameterModifier.Output;
        }
    }
}