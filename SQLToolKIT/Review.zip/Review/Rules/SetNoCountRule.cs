﻿using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class SetNoCountRule
        : ProcedureSetOptionRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0019"; }
        }

        protected override SetOptions RequiredOption
        {
            get { return SetOptions.NoCount; }
        }

        protected override string ErrorMessage
        {
            get
            {
                return
                    "Stored procedure should contain SET NOCOUNT ON.";
            }
        }
    }
}