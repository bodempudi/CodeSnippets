﻿using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class SetXactAbortRule
        : ProcedureSetOptionRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0020"; }
        }

        protected override SetOptions RequiredOption
        {
            get { return SetOptions.XactAbort; }
        }

        protected override string ErrorMessage
        {
            get
            {
                return
                    "Stored procedure should contain SET XACT_ABORT ON.";
            }
        }
    }
}