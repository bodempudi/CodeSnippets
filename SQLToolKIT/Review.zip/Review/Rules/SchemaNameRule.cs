﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.Analysis;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class SchemaNameRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0013"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var cteCollector =
                new CteNameCollector();

            context.Fragment.Accept(
                cteCollector);

            var visitor =
                new Visitor(
                    this,
                    cteCollector.CteNames);

            context.Fragment.Accept(
                visitor);

            return visitor.Findings;
        }

        private sealed class CteNameCollector
            : TSqlFragmentVisitor
        {
            public CteNameCollector()
            {
                CteNames =
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);
            }

            public HashSet<string> CteNames
            {
                get;
                private set;
            }

            public override void Visit(
                WithCtesAndXmlNamespaces node)
            {
                if (node == null ||
                    node.CommonTableExpressions == null)
                {
                    return;
                }

                foreach (
                    CommonTableExpression cte
                    in node.CommonTableExpressions)
                {
                    if (cte == null ||
                        cte.ExpressionName == null ||
                        string.IsNullOrWhiteSpace(
                            cte.ExpressionName.Value))
                    {
                        continue;
                    }

                    CteNames.Add(
                        cte.ExpressionName.Value);
                }
            }
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly SchemaNameRule _rule;

            private readonly HashSet<string>
                _cteNames;

            private readonly HashSet<NamedTableReference>
                _aliasOnlyTargets =
                    new HashSet<NamedTableReference>();

            public Visitor(
                SchemaNameRule rule,
                HashSet<string> cteNames)
            {
                _rule =
                    rule;

                _cteNames =
                    cteNames ??
                    new HashSet<string>(
                        StringComparer.OrdinalIgnoreCase);

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void ExplicitVisit(
                UpdateSpecification node)
            {
                TrackAliasTarget(
                    node.Target,
                    node.FromClause);

                node.AcceptChildren(
                    this);

                UntrackAliasTarget(
                    node.Target);
            }

            public override void ExplicitVisit(
                DeleteSpecification node)
            {
                TrackAliasTarget(
                    node.Target,
                    node.FromClause);

                node.AcceptChildren(
                    this);

                UntrackAliasTarget(
                    node.Target);
            }

            public override void Visit(
                NamedTableReference node)
            {
                if (node == null ||
                    node.SchemaObject == null)
                {
                    return;
                }

                if (_aliasOnlyTargets.Contains(
                        node))
                {
                    return;
                }

                if (TableReferenceAnalyzer
                    .IsCteReference(
                        node,
                        _cteNames))
                {
                    return;
                }

                if (TableReferenceAnalyzer
                    .IsTemporaryTable(
                        node))
                {
                    return;
                }

                if (TableReferenceAnalyzer
                    .HasSchema(
                        node))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Schema name missing from table reference."));
            }

            private void TrackAliasTarget(
                TableReference target,
                FromClause fromClause)
            {
                var targetTable =
                    target as NamedTableReference;

                if (targetTable == null ||
                    fromClause == null ||
                    targetTable.SchemaObject == null ||
                    targetTable.SchemaObject
                        .Identifiers.Count != 1)
                {
                    return;
                }

                string targetName =
                    targetTable.SchemaObject
                        .Identifiers[0]
                        .Value;

                foreach (
                    NamedTableReference table
                    in TableReferenceAnalyzer
                        .GetNamedTables(
                            fromClause))
                {
                    if (table.Alias == null)
                    {
                        continue;
                    }

                    if (string.Equals(
                        targetName,
                        table.Alias.Value,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        _aliasOnlyTargets.Add(
                            targetTable);

                        return;
                    }
                }
            }

            private void UntrackAliasTarget(
                TableReference target)
            {
                var targetTable =
                    target as NamedTableReference;

                if (targetTable != null)
                {
                    _aliasOnlyTargets.Remove(
                        targetTable);
                }
            }
        }
    }
}