﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class OperatorSpacingRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0029"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor =
                new Visitor(
                    this,
                    context.Fragment.ScriptTokenStream);

            context.Fragment.Accept(
                visitor);

            visitor.ReviewStandaloneAssignmentOperators();

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly OperatorSpacingRule _rule;

            private readonly IList<TSqlParserToken> _tokens;

            //
            // Operator token indexes already handled through AST.
            // Prevents '=' in >=, <=, <> etc. being reported again.
            //
            private readonly HashSet<int> _handledTokenIndexes;

            public Visitor(
                OperatorSpacingRule rule,
                IList<TSqlParserToken> tokens)
            {
                _rule =
                    rule;

                _tokens =
                    tokens;

                _handledTokenIndexes =
                    new HashSet<int>();

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            //
            // Comparisons:
            //
            // A=1
            // A>=1
            // A<>B
            // A!=B
            //
            public override void Visit(
                BooleanComparisonExpression node)
            {
                if (node.FirstExpression == null ||
                    node.SecondExpression == null)
                {
                    return;
                }

                ReviewOperatorBetween(
                    node.FirstExpression.LastTokenIndex,
                    node.SecondExpression.FirstTokenIndex);
            }

            //
            // Binary expressions:
            //
            // A+B
            // A-B
            // A*B
            // A/B
            // A%B
            //
            // ScriptDom represents true binary arithmetic
            // separately from unary +/- and SELECT *.
            //
            public override void Visit(
                BinaryExpression node)
            {
                if (node.FirstExpression == null ||
                    node.SecondExpression == null)
                {
                    return;
                }

                ReviewOperatorBetween(
                    node.FirstExpression.LastTokenIndex,
                    node.SecondExpression.FirstTokenIndex);
            }

            private void ReviewOperatorBetween(
                int leftTokenIndex,
                int rightTokenIndex)
            {
                if (_tokens == null)
                {
                    return;
                }

                int start =
                    leftTokenIndex + 1;

                int end =
                    rightTokenIndex - 1;

                if (start > end ||
                    start < 0 ||
                    end >= _tokens.Count)
                {
                    return;
                }

                int firstOperatorIndex =
                    -1;

                int lastOperatorIndex =
                    -1;

                for (int i = start;
                    i <= end;
                    i++)
                {
                    TSqlParserToken token =
                        _tokens[i];

                    if (IsTrivia(token))
                    {
                        continue;
                    }

                    if (!IsOperatorToken(
                        token.TokenType))
                    {
                        continue;
                    }

                    if (firstOperatorIndex < 0)
                    {
                        firstOperatorIndex =
                            i;
                    }

                    lastOperatorIndex =
                        i;

                    _handledTokenIndexes.Add(
                        i);
                }

                if (firstOperatorIndex < 0 ||
                    lastOperatorIndex < 0)
                {
                    return;
                }

                ReviewSpacing(
                    firstOperatorIndex,
                    lastOperatorIndex);
            }

            private void ReviewSpacing(
                int firstOperatorIndex,
                int lastOperatorIndex)
            {
                bool hasSpaceBefore =
                    firstOperatorIndex > 0 &&
                    IsWhiteSpace(
                        _tokens[
                            firstOperatorIndex - 1]);

                bool hasSpaceAfter =
                    lastOperatorIndex + 1 <
                        _tokens.Count &&
                    IsWhiteSpace(
                        _tokens[
                            lastOperatorIndex + 1]);

                if (hasSpaceBefore &&
                    hasSpaceAfter)
                {
                    return;
                }

                string operatorText =
                    GetOperatorText(
                        firstOperatorIndex,
                        lastOperatorIndex);

                Findings.Add(
                    _rule.CreateFinding(
                        _tokens[firstOperatorIndex],
                        "Space required around operator '" +
                        operatorText +
                        "'."));
            }

            private string GetOperatorText(
                int firstOperatorIndex,
                int lastOperatorIndex)
            {
                string text =
                    string.Empty;

                for (int i = firstOperatorIndex;
                    i <= lastOperatorIndex;
                    i++)
                {
                    TSqlParserToken token =
                        _tokens[i];

                    if (IsTrivia(token))
                    {
                        continue;
                    }

                    text +=
                        token.Text;
                }

                return text;
            }

            //
            // Handles assignment operators that are not represented
            // by BooleanComparisonExpression/BinaryExpression.
            //
            // Examples:
            //
            // SET @V_X=1
            // SELECT @V_X=Column1
            // @Parameter=Value
            // SET @V_X+=1
            //
            public void ReviewStandaloneAssignmentOperators()
            {
                if (_tokens == null)
                {
                    return;
                }

                for (int i = 0;
                    i < _tokens.Count;
                    i++)
                {
                    if (_handledTokenIndexes.Contains(
                        i))
                    {
                        continue;
                    }

                    TSqlParserToken token =
                        _tokens[i];

                    if (!IsAssignmentOperator(
                        token.TokenType))
                    {
                        continue;
                    }

                    bool hasSpaceBefore =
                        i > 0 &&
                        IsWhiteSpace(
                            _tokens[i - 1]);

                    bool hasSpaceAfter =
                        i + 1 < _tokens.Count &&
                        IsWhiteSpace(
                            _tokens[i + 1]);

                    if (hasSpaceBefore &&
                        hasSpaceAfter)
                    {
                        continue;
                    }

                    Findings.Add(
                        _rule.CreateFinding(
                            token,
                            "Space required around operator '" +
                            token.Text +
                            "'."));
                }
            }

            private static bool IsAssignmentOperator(
                TSqlTokenType type)
            {
                return
                    type ==
                        TSqlTokenType.EqualsSign ||
                    type ==
                        TSqlTokenType.AddEquals ||
                    type ==
                        TSqlTokenType.SubtractEquals ||
                    type ==
                        TSqlTokenType.MultiplyEquals ||
                    type ==
                        TSqlTokenType.DivideEquals ||
                    type ==
                        TSqlTokenType.ModEquals ||
                    type ==
                        TSqlTokenType.BitwiseAndEquals ||
                    type ==
                        TSqlTokenType.BitwiseOrEquals ||
                    type ==
                        TSqlTokenType.BitwiseXorEquals;
            }

            private static bool IsOperatorToken(
                TSqlTokenType type)
            {
                switch (type)
                {
                    case TSqlTokenType.EqualsSign:
                    case TSqlTokenType.LessThan:
                    case TSqlTokenType.GreaterThan:
                    case TSqlTokenType.Bang:

                    case TSqlTokenType.Plus:
                    case TSqlTokenType.Minus:
                    case TSqlTokenType.Star:
                    case TSqlTokenType.Divide:
                    case TSqlTokenType.PercentSign:

                    case TSqlTokenType.Ampersand:
                    case TSqlTokenType.VerticalLine:
                    case TSqlTokenType.Circumflex:

                    case TSqlTokenType.LeftShift:
                    case TSqlTokenType.RightShift:

                    case TSqlTokenType.Concat:

                        return true;

                    default:

                        return false;
                }
            }

            private static bool IsTrivia(
                TSqlParserToken token)
            {
                if (token == null)
                {
                    return true;
                }

                return
                    token.TokenType ==
                        TSqlTokenType.WhiteSpace ||
                    token.TokenType ==
                        TSqlTokenType.SingleLineComment ||
                    token.TokenType ==
                        TSqlTokenType.MultilineComment;
            }

            private static bool IsWhiteSpace(
                TSqlParserToken token)
            {
                return
                    token != null &&
                    token.TokenType ==
                        TSqlTokenType.WhiteSpace;
            }
        }
    }
}