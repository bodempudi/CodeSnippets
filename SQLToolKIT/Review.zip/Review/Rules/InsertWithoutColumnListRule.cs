﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class InsertWithoutColumnListRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0022"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly InsertWithoutColumnListRule _rule;

            public Visitor(
                InsertWithoutColumnListRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                InsertSpecification node)
            {
                if (node.Columns != null &&
                    node.Columns.Count > 0)
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "INSERT should specify an explicit target column list."));
            }
        }
    }
}