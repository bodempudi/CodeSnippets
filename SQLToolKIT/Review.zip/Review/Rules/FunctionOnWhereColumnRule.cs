﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class FunctionOnWhereColumnRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0007"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor =
                new Visitor(this);

            context.Fragment.Accept(
                visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly FunctionOnWhereColumnRule _rule;

            private int _whereDepth;

            public Visitor(
                FunctionOnWhereColumnRule rule)
            {
                _rule =
                    rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void ExplicitVisit(
                WhereClause node)
            {
                if (node == null ||
                    node.SearchCondition == null)
                {
                    return;
                }

                _whereDepth++;

                node.SearchCondition.Accept(
                    this);

                _whereDepth--;
            }

            //
            // Examples:
            //
            // YEAR(C.CreatedDate)
            // ISNULL(C.Status, '')
            // UPPER(C.CustomerName)
            //
            public override void Visit(
                FunctionCall node)
            {
                if (_whereDepth == 0 ||
                    node == null)
                {
                    return;
                }

                if (!ContainsColumn(
                        node))
                {
                    return;
                }

                AddFinding(
                    node);
            }

            //
            // Example:
            //
            // CONVERT(DATE, C.CreatedDate)
            //
            public override void Visit(
                ConvertCall node)
            {
                if (_whereDepth == 0 ||
                    node == null ||
                    node.Parameter == null)
                {
                    return;
                }

                if (!ContainsColumn(
                        node.Parameter))
                {
                    return;
                }

                AddFinding(
                    node);
            }

            //
            // Example:
            //
            // CAST(C.CreatedDate AS DATE)
            //
            public override void Visit(
                CastCall node)
            {
                if (_whereDepth == 0 ||
                    node == null ||
                    node.Parameter == null)
                {
                    return;
                }

                if (!ContainsColumn(
                        node.Parameter))
                {
                    return;
                }

                AddFinding(
                    node);
            }

            private void AddFinding(
                TSqlFragment fragment)
            {
                Findings.Add(
                    _rule.CreateFinding(
                        fragment,
                        "Function applied to a column in WHERE clause."));
            }

            private static bool ContainsColumn(
                TSqlFragment fragment)
            {
                if (fragment == null)
                {
                    return false;
                }

                var columnVisitor =
                    new ColumnVisitor();

                fragment.Accept(
                    columnVisitor);

                return columnVisitor.HasColumn;
            }

            private sealed class ColumnVisitor
                : TSqlFragmentVisitor
            {
                public bool HasColumn
                {
                    get;
                    private set;
                }

                public override void Visit(
                    ColumnReferenceExpression node)
                {
                    HasColumn =
                        true;
                }
            }
        }
    }
}