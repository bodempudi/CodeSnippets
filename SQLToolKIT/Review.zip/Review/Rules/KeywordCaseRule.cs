﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class KeywordCaseRule
        : ReviewRuleBase
    {
        private static readonly HashSet<string>
            AdditionalSqlKeywords =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase)
                {
                    "NOLOCK",
                    "ROWLOCK",
                    "PAGLOCK",
                    "TABLOCK",
                    "TABLOCKX",
                    "UPDLOCK",
                    "XLOCK",
                    "HOLDLOCK",
                    "READPAST",
                    "NOWAIT",
                    "READCOMMITTED",
                    "READCOMMITTEDLOCK",
                    "REPEATABLEREAD",
                    "SERIALIZABLE",
                    "SNAPSHOT",
                    "FORCESEEK",
                    "FORCESCAN",
                    "OUTPUT",
                    "OUT",
                    "GO"
                };

        public override string RuleId
        {
            get { return "SQLR0009"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var findings =
                new List<ReviewFinding>();

            if (context == null ||
                context.Fragment == null ||
                context.Fragment.ScriptTokenStream == null)
            {
                return findings;
            }

            foreach (
                TSqlParserToken token
                in context.Fragment.ScriptTokenStream)
            {
                if (token == null ||
                    string.IsNullOrWhiteSpace(
                        token.Text))
                {
                    continue;
                }

                if (!IsSqlKeyword(token))
                {
                    continue;
                }

                string text =
                    token.Text;

                if (text ==
                    text.ToUpperInvariant())
                {
                    continue;
                }

                findings.Add(
                    new ReviewFinding
                    {
                        RuleId =
                            RuleId,

                        Severity =
                            Severity,

                        Line =
                            token.Line,

                        Column =
                            token.Column,

                        StartOffset =
                            token.Offset,

                        Length =
                            text.Length,

                        Message =
                            "SQL keyword should be uppercase: " +
                            text
                    });
            }

            return findings;
        }

        private static bool IsSqlKeyword(
            TSqlParserToken token)
        {
            if (token.IsKeyword())
            {
                return true;
            }

            return AdditionalSqlKeywords.Contains(
                token.Text);
        }
    }
}