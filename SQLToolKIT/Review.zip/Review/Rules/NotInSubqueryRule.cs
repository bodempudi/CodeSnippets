﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class NotInSubqueryRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0015"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly NotInSubqueryRule _rule;

            public Visitor(
                NotInSubqueryRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                InPredicate node)
            {
                if (!node.NotDefined ||
                    node.Subquery == null)
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Review NOT IN subquery for NULL semantics. Consider NOT EXISTS where appropriate."));
            }
        }
    }
}