﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class InputParameterNamingRule
        : ParameterNamingRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0017"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        protected override string Prefix
        {
            get { return "I_"; }
        }

        protected override string ErrorMessage
        {
            get
            {
                return "Input parameter must start with I_.";
            }
        }

        protected override bool IsApplicable(
            ProcedureParameter parameter)
        {
            return parameter.Modifier !=
                   ParameterModifier.Output;
        }
    }
}