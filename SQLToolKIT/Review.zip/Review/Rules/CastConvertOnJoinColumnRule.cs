﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class CastConvertOnJoinColumnRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0027"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly CastConvertOnJoinColumnRule _rule;

            public Visitor(
                CastConvertOnJoinColumnRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                QualifiedJoin node)
            {
                if (node.SearchCondition == null)
                {
                    return;
                }

                var conversionVisitor =
                    new ConversionVisitor();

                node.SearchCondition.Accept(
                    conversionVisitor);

                foreach (TSqlFragment conversion
                    in conversionVisitor.Conversions)
                {
                    if (!ContainsColumn(conversion))
                    {
                        continue;
                    }

                    Findings.Add(
                        _rule.CreateFinding(
                            conversion,
                            "CAST/CONVERT applied to a column in JOIN predicate."));
                }
            }

            private static bool ContainsColumn(
                TSqlFragment fragment)
            {
                var visitor =
                    new ColumnVisitor();

                fragment.Accept(visitor);

                return visitor.Found;
            }
        }

        private sealed class ConversionVisitor
            : TSqlFragmentVisitor
        {
            public ConversionVisitor()
            {
                Conversions =
                    new List<TSqlFragment>();
            }

            public IList<TSqlFragment> Conversions
            {
                get;
                private set;
            }

            public override void Visit(
                CastCall node)
            {
                Conversions.Add(node);
            }

            public override void Visit(
                ConvertCall node)
            {
                Conversions.Add(node);
            }
        }

        private sealed class ColumnVisitor
            : TSqlFragmentVisitor
        {
            public bool Found
            {
                get;
                private set;
            }

            public override void Visit(
                ColumnReferenceExpression node)
            {
                Found = true;
            }
        }
    }
}