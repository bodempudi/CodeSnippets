﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.Analysis;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;
using System.Linq;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class JoinAliasRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0003"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Error; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly JoinAliasRule _rule;

            public Visitor(
                JoinAliasRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                QuerySpecification node)
            {
                if (!FragmentHelper.ContainsJoin(
                        node.FromClause))
                {
                    return;
                }

                foreach (
                    TableReference reference
                    in node.FromClause.TableReferences)
                {
                    foreach (
                        NamedTableReference table
                        in FragmentHelper.GetNamedTables(
                            reference))
                    {
                        if (table.Alias != null)
                        {
                            continue;
                        }

                        Findings.Add(
                            _rule.CreateFinding(
                                table,
                                "Alias missing: " +
                                FragmentHelper.GetTableName(
                                    table)));
                    }
                }
            }
        }
    }
}