﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class ArithmeticOnWhereColumnRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0022"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Warning; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly ArithmeticOnWhereColumnRule _rule;
            private int _whereDepth;

            public Visitor(
                ArithmeticOnWhereColumnRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void ExplicitVisit(
                WhereClause node)
            {
                _whereDepth++;

                base.ExplicitVisit(node);

                _whereDepth--;
            }

            public override void Visit(
                BinaryExpression node)
            {
                if (_whereDepth == 0)
                {
                    return;
                }

                if (!ContainsColumn(node.FirstExpression) &&
                    !ContainsColumn(node.SecondExpression))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "Arithmetic operation on a column in WHERE predicate may prevent efficient index usage."));
            }

            private static bool ContainsColumn(
                ScalarExpression expression)
            {
                if (expression == null)
                {
                    return false;
                }

                var visitor =
                    new ColumnReferenceVisitor();

                expression.Accept(visitor);

                return visitor.Found;
            }

            private sealed class ColumnReferenceVisitor
                : TSqlFragmentVisitor
            {
                public bool Found
                {
                    get;
                    private set;
                }

                public override void Visit(
                    ColumnReferenceExpression node)
                {
                    Found = true;
                }
            }
        }
    }
}