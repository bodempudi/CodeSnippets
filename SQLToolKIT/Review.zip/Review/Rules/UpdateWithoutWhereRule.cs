﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class UpdateWithoutWhereRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0008"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly UpdateWithoutWhereRule _rule;

            public Visitor(
                UpdateWithoutWhereRule rule)
            {
                _rule = rule;
                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                UpdateSpecification node)
            {
                if (node.WhereClause != null)
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        "UPDATE without WHERE clause."));
            }
        }
    }
}