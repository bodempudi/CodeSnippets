﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review.Rules
{
    public sealed class ObjectNamingRule
        : ReviewRuleBase
    {
        public override string RuleId
        {
            get { return "SQLR0028"; }
        }

        public override ReviewSeverity Severity
        {
            get { return ReviewSeverity.Information; }
        }

        public override IEnumerable<ReviewFinding> Review(
            SqlReviewContext context)
        {
            var visitor = new Visitor(this);

            context.Fragment.Accept(visitor);

            return visitor.Findings;
        }

        private sealed class Visitor
            : TSqlFragmentVisitor
        {
            private readonly ObjectNamingRule _rule;

            public Visitor(
                ObjectNamingRule rule)
            {
                _rule = rule;

                Findings =
                    new List<ReviewFinding>();
            }

            public IList<ReviewFinding> Findings
            {
                get;
                private set;
            }

            public override void Visit(
                CreateProcedureStatement node)
            {
                ValidateName(
                    node,
                    GetObjectName(node.ProcedureReference),
                    "USP_",
                    "Stored procedure");
            }

            public override void Visit(
                AlterProcedureStatement node)
            {
                ValidateName(
                    node,
                    GetObjectName(node.ProcedureReference),
                    "USP_",
                    "Stored procedure");
            }

            public override void Visit(
                CreateFunctionStatement node)
            {
                ValidateName(
                    node,
                    GetObjectName(node.Name),
                    "UDF_",
                    "Function");
            }

            public override void Visit(
                AlterFunctionStatement node)
            {
                ValidateName(
                    node,
                    GetObjectName(node.Name),
                    "UDF_",
                    "Function");
            }

            public override void Visit(
                CreateViewStatement node)
            {
                ValidateName(
                    node,
                    GetObjectName(node.SchemaObjectName),
                    "VW_",
                    "View");
            }

            public override void Visit(
                AlterViewStatement node)
            {
                ValidateName(
                    node,
                    GetObjectName(node.SchemaObjectName),
                    "VW_",
                    "View");
            }

            private void ValidateName(
                TSqlFragment node,
                string objectName,
                string requiredPrefix,
                string objectType)
            {
                if (string.IsNullOrWhiteSpace(objectName))
                {
                    return;
                }

                if (objectName.StartsWith(
                    requiredPrefix,
                    StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }

                Findings.Add(
                    _rule.CreateFinding(
                        node,
                        objectType +
                        " name should start with '" +
                        requiredPrefix +
                        "'."));
            }

            private static string GetObjectName(
                ProcedureReference procedureReference)
            {
                if (procedureReference == null ||
                    procedureReference.Name == null ||
                    procedureReference.Name.BaseIdentifier == null)
                {
                    return null;
                }

                return procedureReference.Name
                    .BaseIdentifier.Value;
            }

            private static string GetObjectName(
                SchemaObjectName name)
            {
                if (name == null ||
                    name.BaseIdentifier == null)
                {
                    return null;
                }

                return name.BaseIdentifier.Value;
            }
        }
    }
}