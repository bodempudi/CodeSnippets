﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScriptFormatter.Core.Review
{
    namespace ScriptFormatter.Core.Review
    {
        public enum ReviewSeverity
        {
            Error,
            Warning,
            Information
        }

        public sealed class ReviewFinding
        {
            public string RuleId { get; set; }

            public ReviewSeverity Severity { get; set; }

            public int Line { get; set; }

            public int Column { get; set; }

            public int StartOffset { get; set; }

            public int Length { get; set; }

            public string Message { get; set; }
        }
    }
}
