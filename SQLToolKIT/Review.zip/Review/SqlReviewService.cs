﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ScriptFormatter.Core.Review
{
    public sealed class SqlReviewService
    {
        private readonly IList<IReviewRule> _rules;

        public SqlReviewService()
        {
            _rules = new List<IReviewRule>
            {
                new Rules.NoLockRule(),
                new Rules.SelectStarRule(),
                new Rules.JoinAliasRule(),
                new Rules.NullComparisonRule(),
                new Rules.TruncateTableRule(),
                new Rules.DeleteWithoutWhereRule(),
                new Rules.FunctionOnWhereColumnRule(),
                new Rules.UpdateWithoutWhereRule(),
                new Rules.KeywordCaseRule(),
                new Rules.DataTypeCaseRule(),
                new Rules.ImplicitJoinRule(),
                new Rules.ColumnQualificationRule(),
                new Rules.SchemaNameRule(),
                new Rules.OrderByOrdinalRule(),
                new Rules.NotInSubqueryRule(),
                new Rules.VariableNamingRule(),
                new Rules.InputParameterNamingRule(),
                new Rules.OutputParameterNamingRule(),
                new Rules.SetNoCountRule(),
                new Rules.SetXactAbortRule(),
                new Rules.CursorUsageRule(),
                new Rules.InsertWithoutColumnListRule(),
                new Rules.ArithmeticOnWhereColumnRule(),
                new Rules.LeftJoinFilterPredicateRule(),
                new Rules.FunctionOnJoinColumnRule(),
                new Rules.ArithmeticOnJoinColumnRule(),
                new Rules.CountForExistenceRule(),
                new Rules.CastConvertOnJoinColumnRule(),
                new Rules.ObjectNamingRule(),
                new Rules.OperatorSpacingRule(),
                new Rules.BeginTryAfterAsRule(), 
                new Rules.GoAtEndRule(),
                new Rules.DynamicSqlRule()
            };
        }

        public IList<ReviewFinding> Review(
            string sql,
            out IList<ParseError> parseErrors)
        {
            parseErrors = null;

            if (string.IsNullOrWhiteSpace(sql))
            {
                return new List<ReviewFinding>();
            }

            TSqlFragment fragment;

            var parser =
                new TSql160Parser(false);

            using (var reader =
                new StringReader(sql))
            {
                fragment =
                    parser.Parse(
                        reader,
                        out parseErrors);
            }

            if (parseErrors != null &&
                parseErrors.Count > 0)
            {
                return new List<ReviewFinding>();
            }

            var context =
                new SqlReviewContext(
                    sql,
                    fragment);

            var findings =
                new List<ReviewFinding>();

            foreach (IReviewRule rule in _rules)
            {
                IEnumerable<ReviewFinding> ruleFindings =
                    rule.Review(context);

                if (ruleFindings == null)
                {
                    continue;
                }

                findings.AddRange(
                    ruleFindings);
            }

            return findings
                .OrderBy(x => x.Line)
                .ThenBy(x => x.Column)
                .ThenBy(x => x.RuleId)
                .ToList();
        }
    }
}