﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using ScriptFormatter.Core.Review.ScriptFormatter.Core.Review;
using System.Collections.Generic;

namespace ScriptFormatter.Core.Review
{
    public abstract class ReviewRuleBase : IReviewRule
    {
        public abstract string RuleId { get; }

        public abstract ReviewSeverity Severity { get; }

        public abstract IEnumerable<ReviewFinding> Review(
            SqlReviewContext context);
        protected ReviewFinding CreateFinding(
    TSqlParserToken token,
    string message)
        {
            return new ReviewFinding
            {
                RuleId = RuleId,
                Severity = Severity,
                Line = token.Line,
                Column = token.Column,
                StartOffset = token.Offset,
                Length = token.Text == null
                    ? 0
                    : token.Text.Length,
                Message = message
            };
        }
        protected ReviewFinding CreateFinding(
            TSqlFragment fragment,
            string message)
        {
            return new ReviewFinding
            {
                RuleId = RuleId,
                Severity = Severity,
                Line = fragment.StartLine,
                Column = fragment.StartColumn,
                StartOffset = fragment.StartOffset,
                Length = fragment.FragmentLength,
                Message = message
            };
        }
    }
}