﻿using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace ScriptFormatter.Core.Review
{
    public sealed class SqlReviewContext
    {
        public SqlReviewContext(
            string sourceSql,
            TSqlFragment fragment)
        {
            SourceSql = sourceSql;
            Fragment = fragment;
        }

        public string SourceSql { get; }

        public TSqlFragment Fragment { get; }
    }
}