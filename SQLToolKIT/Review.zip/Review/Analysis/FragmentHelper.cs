﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ScriptFormatter.Core.Review.Analysis
{
    internal static class FragmentHelper
    {
        public static string GetIdentifier(
            Identifier identifier)
        {
            return identifier == null
                ? string.Empty
                : identifier.Value;
        }

        public static string GetTableName(
            NamedTableReference table)
        {
            if (table == null ||
                table.SchemaObject == null)
            {
                return string.Empty;
            }

            return string.Join(
                ".",
                table.SchemaObject.Identifiers
                    .Select(x => x.Value));
        }

        public static bool HasAlias(
            TableReference table)
        {
            var named =
                table as NamedTableReference;

            if (named != null)
            {
                return named.Alias != null &&
                       !string.IsNullOrWhiteSpace(
                           named.Alias.Value);
            }

            return true;
        }

        public static bool HasNoLock(
            NamedTableReference table)
        {
            if (table == null ||
                table.TableHints == null)
            {
                return false;
            }

            return table.TableHints.Any(
                x => x.HintKind ==
                     TableHintKind.NoLock);
        }

        public static IEnumerable<NamedTableReference>
            GetNamedTables(
                TableReference reference)
        {
            if (reference == null)
            {
                yield break;
            }

            var named =
                reference as NamedTableReference;

            if (named != null)
            {
                yield return named;
                yield break;
            }

            var qualifiedJoin =
                reference as QualifiedJoin;

            if (qualifiedJoin != null)
            {
                foreach (
                    NamedTableReference table
                    in GetNamedTables(
                        qualifiedJoin.FirstTableReference))
                {
                    yield return table;
                }

                foreach (
                    NamedTableReference table
                    in GetNamedTables(
                        qualifiedJoin.SecondTableReference))
                {
                    yield return table;
                }

                yield break;
            }

            var unqualifiedJoin =
                reference as UnqualifiedJoin;

            if (unqualifiedJoin != null)
            {
                foreach (
                    NamedTableReference table
                    in GetNamedTables(
                        unqualifiedJoin.FirstTableReference))
                {
                    yield return table;
                }

                foreach (
                    NamedTableReference table
                    in GetNamedTables(
                        unqualifiedJoin.SecondTableReference))
                {
                    yield return table;
                }
            }
        }

        public static bool ContainsJoin(
            FromClause fromClause)
        {
            if (fromClause == null)
            {
                return false;
            }

            foreach (
                TableReference reference
                in fromClause.TableReferences)
            {
                if (ContainsJoin(reference))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool ContainsJoin(
            TableReference reference)
        {
            if (reference == null)
            {
                return false;
            }

            if (reference is JoinTableReference)
            {
                return true;
            }

            return false;
        }
    }
}