﻿using Microsoft.SqlServer.TransactSql.ScriptDom;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ScriptFormatter.Core.Review.Analysis
{
    internal static class TableReferenceAnalyzer
    {
        public static IEnumerable<NamedTableReference> GetNamedTables(
            FromClause fromClause)
        {
            if (fromClause == null)
            {
                yield break;
            }

            foreach (TableReference tableReference
                     in fromClause.TableReferences)
            {
                foreach (NamedTableReference table
                         in GetNamedTables(tableReference))
                {
                    yield return table;
                }
            }
        }

        public static IEnumerable<NamedTableReference> GetNamedTables(
            TableReference tableReference)
        {
            if (tableReference == null)
            {
                yield break;
            }

            var namedTable =
                tableReference as NamedTableReference;

            if (namedTable != null)
            {
                yield return namedTable;
                yield break;
            }

            var qualifiedJoin =
                tableReference as QualifiedJoin;

            if (qualifiedJoin != null)
            {
                foreach (NamedTableReference table
                         in GetNamedTables(
                             qualifiedJoin.FirstTableReference))
                {
                    yield return table;
                }

                foreach (NamedTableReference table
                         in GetNamedTables(
                             qualifiedJoin.SecondTableReference))
                {
                    yield return table;
                }

                yield break;
            }

            var unqualifiedJoin =
                tableReference as UnqualifiedJoin;

            if (unqualifiedJoin != null)
            {
                foreach (NamedTableReference table
                         in GetNamedTables(
                             unqualifiedJoin.FirstTableReference))
                {
                    yield return table;
                }

                foreach (NamedTableReference table
                         in GetNamedTables(
                             unqualifiedJoin.SecondTableReference))
                {
                    yield return table;
                }

                yield break;
            }

            var parenthesisJoin =
                tableReference as JoinParenthesisTableReference;

            if (parenthesisJoin != null)
            {
                foreach (NamedTableReference table
                         in GetNamedTables(
                             parenthesisJoin.Join))
                {
                    yield return table;
                }
            }
        }

        public static bool HasNoLock(
            NamedTableReference table)
        {
            return table != null &&
                   table.TableHints != null &&
                   table.TableHints.Any(
                       x => x.HintKind ==
                            TableHintKind.NoLock);
        }

        public static bool IsTemporaryTable(
            NamedTableReference table)
        {
            if (table == null ||
                table.SchemaObject == null ||
                table.SchemaObject.BaseIdentifier == null)
            {
                return false;
            }

            string name =
                table.SchemaObject.BaseIdentifier.Value;

            return !string.IsNullOrWhiteSpace(name) &&
                   name.StartsWith(
                       "#",
                       StringComparison.Ordinal);
        }

        public static bool IsCteReference(
            NamedTableReference table,
            ISet<string> cteNames)
        {
            if (table == null ||
                table.SchemaObject == null ||
                cteNames == null ||
                table.SchemaObject.Identifiers.Count != 1)
            {
                return false;
            }

            string name =
                table.SchemaObject
                    .Identifiers[0]
                    .Value;

            return cteNames.Contains(name);
        }

        public static bool HasSchema(
            NamedTableReference table)
        {
            return table != null &&
                   table.SchemaObject != null &&
                   table.SchemaObject.SchemaIdentifier != null;
        }

        public static bool IsModificationTarget(
            TableReference target,
            NamedTableReference candidate)
        {
            if (target == null ||
                candidate == null)
            {
                return false;
            }

            var targetTable =
                target as NamedTableReference;

            if (targetTable == null)
            {
                return false;
            }

            string targetName =
                GetLastIdentifier(
                    targetTable);

            string candidateAlias =
                candidate.Alias == null
                    ? string.Empty
                    : candidate.Alias.Value;

            if (!string.IsNullOrWhiteSpace(
                    candidateAlias) &&
                string.Equals(
                    targetName,
                    candidateAlias,
                    StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            string targetFullName =
                GetFullName(
                    targetTable);

            string candidateFullName =
                GetFullName(
                    candidate);

            return
                !string.IsNullOrWhiteSpace(
                    targetFullName) &&
                string.Equals(
                    targetFullName,
                    candidateFullName,
                    StringComparison.OrdinalIgnoreCase);
        }

        public static string GetFullName(
            NamedTableReference table)
        {
            if (table == null ||
                table.SchemaObject == null)
            {
                return string.Empty;
            }

            return string.Join(
                ".",
                table.SchemaObject
                    .Identifiers
                    .Select(x => x.Value));
        }

        private static string GetLastIdentifier(
            NamedTableReference table)
        {
            if (table == null ||
                table.SchemaObject == null ||
                table.SchemaObject.Identifiers.Count == 0)
            {
                return string.Empty;
            }

            return table.SchemaObject
                .Identifiers[
                    table.SchemaObject
                        .Identifiers.Count - 1]
                .Value;
        }
    }
}